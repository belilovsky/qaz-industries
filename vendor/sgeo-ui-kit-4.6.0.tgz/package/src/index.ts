/**
 * @sgeo/ui-kit – поверхность пакета AVDS 4
 *
 * Подключение CSS (обязательно):
 *   import '@sgeo/ui-kit/tokens/variables.css';
 *   import '@sgeo/ui-kit/animations/animations.css';
 *
 * Готовый набор Tailwind:
 *   import { sgeoPreset } from '@sgeo/ui-kit/tokens/tailwind-preset';
 */

// Утилиты
export { cn } from "./utils/cn";
export {
  rankSearchItems,
  type RankedSearchItem,
  type RankedSearchOptions,
  type RankedSearchResult,
  type RankedSearchTier,
} from "./utils/rankedSearch";

// Компоненты
export { InfoTooltip, type InfoTooltipProps } from "./components/InfoTooltip";
export { PillTabs, type PillTabsProps, type PillTab } from "./components/PillTabs";
export { AccentCard, type AccentCardProps, type AccentVariant } from "./components/AccentCard";
export { DataTable, type DataTableProps, type DataTableColumn } from "./components/DataTable";
export { PaginatedList, type PaginatedListProps, type PaginatedListStatus } from "./components/PaginatedList";
export { SearchField, type SearchFieldProps } from "./components/SearchField";
export { ReportToolbar, type ReportToolbarProps, type ReportToolbarDensity } from "./components/ReportToolbar";
export {
  AdminShell,
  AdminLoginShell,
  type AdminShellProps,
  type AdminLoginShellProps,
  type AdminNavItem,
} from "./components/AdminShell";
export { AdminBulkActionBar, type AdminBulkActionBarProps } from "./components/AdminBulkActionBar";
export {
  AdminContentQueue,
  type AdminContentQueueProps,
  type AdminContentQueueItem,
  type AdminQueueTone,
} from "./components/AdminContentQueue";
export {
  AdminEditorRail,
  type AdminEditorRailProps,
  type AdminChecklistItem,
  type AdminChecklistStatus,
} from "./components/AdminEditorRail";
export {
  AdminRoleMatrix,
  type AdminRoleMatrixProps,
  type AdminRoleColumn,
  type AdminPermissionGroup,
  type AdminPermissionItem,
} from "./components/AdminRoleMatrix";
export {
  AdminAuditTrail,
  type AdminAuditTrailProps,
  type AdminAuditEntry,
  type AdminAuditTone,
} from "./components/AdminAuditTrail";
export {
  AdminSettingsGroup,
  type AdminSettingsGroupProps,
  type AdminSettingItem,
} from "./components/AdminSettingsGroup";
export {
  AdminMediaPicker,
  type AdminMediaPickerProps,
  type AdminMediaItem,
} from "./components/AdminMediaPicker";
export {
  ChartInsightTooltip,
  type ChartInsightTooltipProps,
  type ChartInsightItem,
  type ChartInsightTone,
} from "./components/ChartInsightTooltip";
export {
  DecisionFeed,
  type DecisionFeedProps,
  type DecisionFeedItem,
  type DecisionFeedPriority,
} from "./components/DecisionFeed";
export { PageHeader, type PageHeaderProps } from "./components/PageHeader";
export { StatusBadge, type StatusBadgeProps, type StatusType } from "./components/StatusBadge";
export { RadialGauge, type RadialGaugeProps } from "./components/RadialGauge";
export { MiniMetric, type MiniMetricProps } from "./components/MiniMetric";
export {
  TrendSparkline,
  type TrendSparklineProps,
  type TrendSparklineTone,
} from "./components/TrendSparkline";
export { MetricCard, type MetricCardProps, type MetricCardDensity } from "./components/MetricCard";
export { DocumentCard, type DocumentCardProps, type DocumentCardMetaItem } from "./components/DocumentCard";
export { FilterChipRow, type FilterChipRowProps, type FilterChipItem } from "./components/FilterChipRow";
export { ScoreBar, type ScoreBarProps } from "./components/ScoreBar";
export { StatePanel, type StatePanelProps, type StatePanelTone, type StatePanelAction } from "./components/StatePanel";
export { Toast, ToastProvider, useToast, type ToastType, type ToastOptions } from "./components/Toast";
export { CopyButton, type CopyButtonProps } from "./components/CopyButton";
export { LoadingSkeleton, type LoadingSkeletonProps } from "./components/LoadingSkeleton";
export { ModelVariantList, type ModelVariantListProps, type ModelVariantListItem } from "./components/ModelVariantList";
export { PanelActionRail, type PanelActionRailProps } from "./components/PanelActionRail";
export { BarChart, type BarChartProps, type BarChartItem } from "./components/BarChart";
export { SourceBadge, SOURCE_COLORS, type SourceBadgeProps } from "./components/SourceBadge";
export { SourceHealthBadge, type SourceHealthBadgeProps, type SourceHealthStatus } from "./components/SourceHealthBadge";
export { SourcePolicyBadge, type SourcePolicyBadgeProps, type SourcePolicyKind } from "./components/SourcePolicyBadge";
export { SourceCard, type SourceCardProps, type SourceCardMetaItem } from "./components/SourceCard";
export { ServiceStatusCard, type ServiceStatusCardProps, type ServiceStatusMetric } from "./components/ServiceStatusCard";
export {
  PublishPreflightPanel,
  type PublishPreflightPanelProps,
  type PublishPreflightStatus,
  type PublishPreflightCheck,
  type PublishPreflightMetric,
} from "./components/PublishPreflightPanel";
export {
  EvidencePairReviewCard,
  type EvidencePairReviewCardProps,
  type EvidencePairReviewStatus,
  type EvidencePairReviewSide,
} from "./components/EvidencePairReviewCard";
export {
  EvidenceUsePolicyPanel,
  type EvidenceUsePolicyPanelProps,
  type EvidenceUsePolicyStatus,
} from "./components/EvidenceUsePolicyPanel";
export { ProvenanceCard, type ProvenanceCardProps, type ProvenanceItem, type ProvenanceStatus } from "./components/ProvenanceCard";
export { RangeWithFlags, type RangeWithFlagsProps, type RangeFlag } from "./components/RangeWithFlags";
export { PublicSummaryStrip, type PublicSummaryStripProps, type PublicSummaryItem } from "./components/PublicSummaryStrip";
export { QuickLinksRail, type QuickLinksRailProps, type QuickLinksRailItem } from "./components/QuickLinksRail";
export { CompactCompareCard, type CompactCompareCardProps, type CompactCompareRow } from "./components/CompactCompareCard";
export { ComparisonBarRow, type ComparisonBarRowProps } from "./components/ComparisonBarRow";
export {
  WorkflowPath,
  type WorkflowPathProps,
  type WorkflowPathStatus,
  type WorkflowPathStep,
} from "./components/WorkflowPath";
export { ProvenanceFoot, type ProvenanceFootProps, type ProvenanceFootSource } from "./components/ProvenanceFoot";
export { ProvenanceTable, type ProvenanceTableProps, type ProvenanceTableRow } from "./components/ProvenanceTable";
export {
  OperatorPageShell,
  type OperatorPageShellProps,
  type OperatorPageShellNavItem,
} from "./components/OperatorPageShell";
export {
  ProjectPassportDialog,
  type ProjectPassportDialogProps,
  type ProjectPassportMetric,
  type ProjectPassportDetail,
  type ProjectPassportLink,
} from "./components/ProjectPassportDialog";
export {
  CommandPalette,
  type CommandPaletteProps,
  type CommandPaletteGroup,
  type CommandPaletteItem,
} from "./components/CommandPalette";
export {
  LiveLinkReleaseGate,
  type LiveLinkReleaseGateProps,
  type LiveLinkReleaseCheck,
} from "./components/LiveLinkReleaseGate";
export {
  EcosystemMap,
  type EcosystemMapProps,
  type EcosystemMapNode,
  type EcosystemMapLink,
} from "./components/EcosystemMap";
export {
  ReadinessBoard,
  type ReadinessBoardProps,
  type ReadinessBoardItem,
  type ReadinessState,
} from "./components/ReadinessBoard";
export {
  RuntimeProjection,
  type RuntimeProjectionProps,
  type RuntimeProjectionItem,
} from "./components/RuntimeProjection";
export {
  QazLakeOpsList,
  type QazLakeOpsListProps,
  type QazLakeOpsRun,
} from "./components/QazLakeOpsList";
export {
  SpeakerOverviewCard,
  type SpeakerOverviewCardProps,
  type SpeakerOverviewMetric,
  type SpeakerOverviewLink,
} from "./components/SpeakerOverviewCard";
export {
  ThemeCoverageCard,
  type ThemeCoverageCardProps,
  type ThemeCoverageLink,
} from "./components/ThemeCoverageCard";
export {
  TrustFactsPanel,
  type TrustFactsPanelProps,
  type TrustFactItem,
  type TrustFactLink,
} from "./components/TrustFactsPanel";
export {
  InlineDocumentAssistantPanel,
  type InlineDocumentAssistantPanelProps,
  type InlineAssistantPrompt,
} from "./components/InlineDocumentAssistantPanel";
export {
  OperatorReviewSurface,
  EvidenceSummarySurface,
  ContentDigestSurface,
  type OperatorReviewSurfaceProps,
  type EvidenceSummarySurfaceProps,
  type ContentDigestSurfaceProps,
} from "./components/SurfacePresets";
export {
  AdminWorkspaceSurface,
  GeoEvidenceSurface,
  MediaMonitoringSurface,
  IncidentResponseSurface,
  PublicExplainerSurface,
  type AdminWorkspaceSurfaceProps,
  type GeoEvidenceSurfaceProps,
  type MediaMonitoringSurfaceProps,
  type IncidentResponseSurfaceProps,
  type PublicExplainerSurfaceProps,
} from "./components/AdvancedSurfacePresets";
export {
  DataFreshness,
  getDataFreshnessState,
  type DataFreshnessProps,
  type DataFreshnessState,
} from "./components/DataFreshness";
export {
  DataQualityFlag,
  type DataQualityFlagProps,
  type DataQualitySeverity,
} from "./components/DataQualityFlag";
export {
  ContractStatus,
  type ContractStatusProps,
  type ContractConnectivity,
  type ContractAdoption,
} from "./components/ContractStatus";
export {
  EvidenceTrail,
  type EvidenceTrailProps,
  type EvidenceTrailStep,
  type EvidenceTrailStatus,
} from "./components/EvidenceTrail";
export { ExportReceipt, type ExportReceiptProps } from "./components/ExportReceipt";
export {
  CollectorRun,
  type CollectorRunProps,
  type CollectorRunStatus,
} from "./components/CollectorRun";
export {
  CoverageMatrix,
  DataQualityScorecard,
  EvidenceCoverageState,
  FreshnessLedger,
  InspectionPrioritySummary,
  MapLayerToggleGroup,
  MethodDisclosure,
  PolicyChangeReceipt,
  ReleaseProof,
  RuleStatusStrip,
  type CoverageMatrixCell,
  type CoverageMatrixProps,
  type CoverageMatrixRow,
  type DataQualityDimension,
  type DataQualityScorecardProps,
  type EvidenceCoverageStateProps,
  type EvidenceCoverageStatus,
  type FreshnessLedgerItem,
  type FreshnessLedgerProps,
  type FreshnessLedgerState,
  type InspectionPriority,
  type InspectionPrioritySummaryProps,
  type MapLayerToggle,
  type MapLayerToggleGroupProps,
  type MethodDisclosureItem,
  type MethodDisclosureProps,
  type PolicyChangeReceiptProps,
  type ReleaseProofProps,
  type RuleStatus,
  type RuleStatusItem,
  type RuleStatusStripProps,
} from "./components/OperationalEvidence";
export {
  qazStackPresentationSchemas,
  qazStackConsumerToContractStatus,
  qazStackAssetEvidenceToProvenance,
  qazStackAssetQualityToFlags,
  qazStackAssetResolutionToTrail,
  qazStackAssetTimelineToTrail,
  qazStackEvidenceManifestToTrail,
  qazStackMediaArtifactToProvenance,
  qazStackSourceOccurrenceToProvenance,
  type QazStackConsumerAdapterOptions,
  type QazStackAssetEvidenceViewInput,
  type QazStackAssetQualityViewInput,
  type QazStackAssetResolutionViewInput,
  type QazStackAssetTimelineViewInput,
  type QazStackConsumerLifecycle,
  type QazStackConsumerViewInput,
  type QazStackEvidenceManifestViewInput,
  type QazStackIntegrationMode,
  type QazStackMediaArtifactViewInput,
  type QazStackSourceOccurrenceViewInput,
} from "./adapters/qazstack";

// Charts (3.8.0)
export { RangeBar, type RangeBarProps } from "./components/charts/RangeBar";
export { DemographyHeatmap, type DemographyHeatmapProps, type DemographyCell } from "./components/charts/DemographyHeatmap";
