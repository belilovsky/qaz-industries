import type { ContractConnectivity, ContractStatusProps } from "../components/ContractStatus";
import type { DataQualityFlagProps, DataQualitySeverity } from "../components/DataQualityFlag";
import type { EvidenceTrailStatus, EvidenceTrailStep } from "../components/EvidenceTrail";
import type { ProvenanceItem } from "../components/ProvenanceCard";

/**
 * Narrow presentation ports for QazStack's portable contracts.
 * QazStack owns validation and schema evolution; AV DS only maps validated
 * payloads into existing presentation primitives.
 */
export const qazStackPresentationSchemas = {
  consumer: "qazstack-consumer-v1",
  sourceOccurrence: "qazstack-source-occurrence-v1",
  mediaArtifact: "qazstack-media-artifact-v1",
  evidenceManifest: "qazstack-evidence-manifest-v1",
  assetEvidence: "qazstack-asset-evidence-v1",
  assetResolution: "qazstack-asset-resolution-v1",
  assetTimeline: "qazstack-asset-timeline-v1",
  assetQuality: "qazstack-asset-quality-v1",
} as const;

export type QazStackConsumerLifecycle = "planned" | "pilot" | "beta" | "production" | "archived";
export type QazStackIntegrationMode =
  | "python-package"
  | "http-contract"
  | "typescript-contract"
  | "vendored-temporary"
  | "vendored-release"
  | "documented-only";

export interface QazStackConsumerViewInput {
  schema_version: typeof qazStackPresentationSchemas.consumer;
  product_name: string;
  lifecycle: QazStackConsumerLifecycle;
  integration_mode: QazStackIntegrationMode;
  qazstack_version: string;
  evidence: {
    runtime_urls: readonly string[];
    test_commands: readonly string[];
    verified_at?: string;
    environment?: "local" | "staging" | "production" | "private-runtime";
  };
}

export interface QazStackSourceOccurrenceViewInput {
  schema_version: typeof qazStackPresentationSchemas.sourceOccurrence;
  occurrence_id: string;
  source_id: string;
  subject_refs: readonly string[];
  channel: "web" | "social" | "messaging" | "broadcast" | "document" | "dataset" | "other";
  observed_at: string;
  source_url: string | null;
  source_locator: string | null;
  author: string | null;
  language: string | null;
  content_digest: `sha256:${string}` | null;
  capture_id: string | null;
}

export interface QazStackMediaArtifactViewInput {
  schema_version: typeof qazStackPresentationSchemas.mediaArtifact;
  artifact_id: string;
  kind: "image" | "video" | "audio" | "document" | "other";
  content_ref: string;
  digest: `sha256:${string}`;
  registered_at: string;
  metadata: {
    mime_type: string;
    size_bytes: number;
    width: number | null;
    height: number | null;
  };
  fingerprints: ReadonlyArray<{ algorithm: string; provider: string }>;
  occurrence_ids: readonly string[];
}

export interface QazStackEvidenceManifestViewInput {
  schema_version: typeof qazStackPresentationSchemas.evidenceManifest;
  capture_id: string;
  source_url: string;
  status: "pending" | "completed" | "failed";
  provider: string;
  requested_at: string;
  completed_at: string | null;
  http_status: number | null;
  retention_class: string;
  retention_until: string | null;
  legal_hold: boolean;
  error_code: string | null;
  artifacts: ReadonlyArray<{
    artifact_id: string;
    role: "payload" | "screenshot" | "warc" | "wacz" | "metadata" | "thumbnail" | "transcript" | "other";
    availability: "available" | "purged" | "missing";
  }>;
}

export interface QazStackAssetEvidenceViewInput {
  schema_version: typeof qazStackPresentationSchemas.assetEvidence;
  evidence_id: string;
  asset_id: string;
  kind: "media" | "document" | "catalog" | "operator" | "compute";
  source_ref: string;
  observed_at: string;
  provenance_status: "unknown" | "candidate" | "verified" | "rejected";
  rights_status: "unknown" | "allow" | "deny" | "review";
  checksum: `sha256:${string}` | null;
  content_type: string | null;
  provider: string | null;
  model: string | null;
  model_version: string | null;
  metadata: ReadonlyArray<{ key: string; value: string }>;
}

export interface QazStackAssetResolutionViewInput {
  schema_version: typeof qazStackPresentationSchemas.assetResolution;
  asset_id: string;
  decision: "separate" | "link" | "merge" | "review";
  candidates: ReadonlyArray<{
    candidate_id: string;
    label: string;
    confidence: number;
    evidence_ids: readonly string[];
    signals: ReadonlyArray<{ key: string; score: number; evidence_ids: readonly string[] }>;
  }>;
  chosen_candidate_id: string | null;
  decided_by: string;
  decided_at: string;
  reason: string;
}

export interface QazStackAssetTimelineViewInput {
  schema_version: typeof qazStackPresentationSchemas.assetTimeline;
  event_id: string;
  asset_id: string;
  event_type: "acquired" | "valued" | "moved" | "lent" | "returned" | "maintenance" | "sold" | "disposed" | "note";
  title: string;
  occurred_at: string;
  evidence_ids: readonly string[];
  location: string | null;
  counterparty: string | null;
  note: string | null;
}

export interface QazStackAssetQualityViewInput {
  schema_version: typeof qazStackPresentationSchemas.assetQuality;
  asset_id: string;
  status: "unknown" | "complete" | "degraded";
  score: number;
  checks: ReadonlyArray<{
    key: string;
    status: "pass" | "fail" | "unknown";
    reason: string;
    observed_at: string;
    evidence_updated_at: string | null;
    stale_after_seconds: number;
    freshness: "fresh" | "stale" | "unknown";
    evidence_ids: readonly string[];
  }>;
}

export interface QazStackConsumerAdapterOptions {
  connectivity?: ContractConnectivity;
  runtimeProven?: boolean;
  issues?: readonly string[];
}

function compactTimestamp(value: string | null | undefined): string | undefined {
  if (!value) return undefined;
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp)) return value;
  return `${new Date(timestamp).toISOString().slice(0, 16).replace("T", " ")} UTC`;
}

function compactDigest(value: `sha256:${string}`): string {
  return `${value.slice(0, 19)}...`;
}

function formatBytes(value: number): string {
  if (value < 1_024) return `${value} B`;
  if (value < 1_048_576) return `${(value / 1_024).toFixed(1)} KB`;
  return `${(value / 1_048_576).toFixed(1)} MB`;
}

function sourceHost(sourceUrl: string): string {
  try {
    return new URL(sourceUrl).host;
  } catch {
    return sourceUrl;
  }
}

function sourceHref(sourceRef: string): string | undefined {
  try {
    const url = new URL(sourceRef);
    return url.protocol === "http:" || url.protocol === "https:" ? url.href : undefined;
  } catch {
    return undefined;
  }
}

function formatPercent(value: number): string {
  return `${Math.round(value * 100)}%`;
}

function formatCount(value: number, one: string, few: string, many: string): string {
  const mod100 = value % 100;
  const mod10 = value % 10;
  const noun = mod10 === 1 && mod100 !== 11
    ? one
    : mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)
      ? few
      : many;
  return `${value} ${noun}`;
}

export function qazStackConsumerToContractStatus(
  contract: QazStackConsumerViewInput,
  options: QazStackConsumerAdapterOptions = {},
): ContractStatusProps {
  const runtimeProven = options.runtimeProven ?? false;
  const adoption = contract.integration_mode === "documented-only" || contract.lifecycle === "planned"
    ? "documented"
    : contract.lifecycle === "production" && runtimeProven
      ? "live"
      : contract.lifecycle === "archived"
        ? "unknown"
        : "staging";
  const issues = [
    ...(contract.lifecycle === "production" && !runtimeProven
      ? ["Проверка среды выполнения не передана адаптеру; манифест рабочей среды показан как испытательный"]
      : []),
    ...(contract.integration_mode === "documented-only"
      ? ["Интеграция описана без подключения к рабочей среде"]
      : []),
    ...(contract.evidence.runtime_urls.length === 0 ? ["Адрес рабочей среды не опубликован"] : []),
    ...(!contract.evidence.verified_at ? ["Время проверки не опубликовано"] : []),
    ...(options.issues ?? []),
  ];

  return {
    name: contract.product_name,
    connectivity: options.connectivity ?? "unknown",
    adoption,
    version: contract.qazstack_version,
    schemaVersion: contract.schema_version,
    updatedAt: contract.evidence.verified_at ?? null,
    issues: Array.from(new Set(issues)),
  };
}

export function qazStackEvidenceManifestToTrail(
  manifest: QazStackEvidenceManifestViewInput,
): EvidenceTrailStep[] {
  const available = manifest.artifacts.filter((artifact) => artifact.availability === "available").length;
  const purged = manifest.artifacts.filter((artifact) => artifact.availability === "purged").length;
  const missing = manifest.artifacts.filter((artifact) => artifact.availability === "missing").length;
  const captureStatus: EvidenceTrailStatus = manifest.status === "completed"
    ? "verified"
    : manifest.status === "failed"
      ? "failed"
      : "current";
  const artifactStatus: EvidenceTrailStatus = manifest.status === "pending"
    ? "pending"
    : manifest.status === "failed" || missing > 0
      ? "failed"
      : purged > 0 || available === 0
        ? "warning"
        : "verified";

  return [
    {
      id: `${manifest.capture_id}:requested`,
      label: "Запрос захвата принят",
      detail: `${manifest.provider} · ${sourceHost(manifest.source_url)}`,
      meta: compactTimestamp(manifest.requested_at),
      status: "verified",
    },
    {
      id: `${manifest.capture_id}:capture`,
      label: manifest.status === "completed"
        ? "Источник зафиксирован"
        : manifest.status === "failed"
          ? "Захват не завершён"
          : "Источник фиксируется",
      detail: manifest.error_code
        ? `Код ошибки: ${manifest.error_code}`
        : manifest.http_status
          ? `HTTP ${manifest.http_status}`
          : "Ожидается итоговый ответ",
      meta: compactTimestamp(manifest.completed_at),
      status: captureStatus,
    },
    {
      id: `${manifest.capture_id}:artifacts`,
      label: "Артефакты и целостность",
      detail: `${available} доступны · ${purged} удалены по политике · ${missing} отсутствуют`,
      meta: `${manifest.artifacts.length} шт.`,
      status: artifactStatus,
    },
    {
      id: `${manifest.capture_id}:retention`,
      label: "Политика хранения",
      detail: manifest.legal_hold
        ? `${manifest.retention_class} · действует запрет на удаление`
        : manifest.retention_until
          ? `${manifest.retention_class} · до ${compactTimestamp(manifest.retention_until)}`
          : manifest.retention_class,
      status: manifest.legal_hold ? "current" : "verified",
    },
  ];
}

export function qazStackSourceOccurrenceToProvenance(
  occurrence: QazStackSourceOccurrenceViewInput,
): ProvenanceItem[] {
  const context = [occurrence.channel, occurrence.language, occurrence.author].filter(Boolean).join(" · ");
  return [
    {
      label: "Источник",
      value: occurrence.source_id,
      href: occurrence.source_url ?? undefined,
      note: occurrence.source_locator ?? undefined,
    },
    {
      label: "Наблюдение",
      value: compactTimestamp(occurrence.observed_at),
      note: context || undefined,
    },
    {
      label: "Связанные объекты",
      value: occurrence.subject_refs.join(", "),
      confidence: `${occurrence.subject_refs.length}`,
    },
    {
      label: "Целостность",
      value: occurrence.content_digest ? compactDigest(occurrence.content_digest) : "контрольная сумма не опубликована",
      source: occurrence.capture_id ?? undefined,
      confidence: occurrence.content_digest ? "sha256" : "unknown",
    },
  ];
}

export function qazStackMediaArtifactToProvenance(
  artifact: QazStackMediaArtifactViewInput,
): ProvenanceItem[] {
  const dimensions = artifact.metadata.width && artifact.metadata.height
    ? `${artifact.metadata.width}x${artifact.metadata.height}`
    : null;
  return [
    {
      label: "Артефакт",
      value: artifact.artifact_id,
      note: `${artifact.kind} · ${artifact.metadata.mime_type}`,
    },
    {
      label: "Объект",
      value: artifact.content_ref,
      note: [formatBytes(artifact.metadata.size_bytes), dimensions].filter(Boolean).join(" · "),
    },
    {
      label: "Целостность",
      value: compactDigest(artifact.digest),
      note: `${artifact.fingerprints.length} цифровых отпечатков`,
      confidence: "sha256",
    },
    {
      label: "Происхождение",
      value: artifact.occurrence_ids.length > 0 ? artifact.occurrence_ids.join(", ") : "наблюдение не указано",
      note: compactTimestamp(artifact.registered_at),
      confidence: `${artifact.occurrence_ids.length}`,
    },
  ];
}

export function qazStackAssetEvidenceToProvenance(
  evidence: QazStackAssetEvidenceViewInput,
): ProvenanceItem[] {
  const provenanceLabels: Record<QazStackAssetEvidenceViewInput["provenance_status"], string> = {
    unknown: "не определено",
    candidate: "кандидат",
    verified: "подтверждено",
    rejected: "отклонено",
  };
  const rightsLabels: Record<QazStackAssetEvidenceViewInput["rights_status"], string> = {
    unknown: "не определены",
    allow: "разрешено",
    deny: "запрещено",
    review: "нужна проверка",
  };
  const kindLabels: Record<QazStackAssetEvidenceViewInput["kind"], string> = {
    media: "медиа",
    document: "документ",
    catalog: "каталог",
    operator: "оператор",
    compute: "вычисление",
  };
  const runtime = [evidence.provider, evidence.model, evidence.model_version].filter(Boolean).join(" · ");
  const metadata = evidence.metadata.map((item) => `${item.key}: ${item.value}`).join(" · ");
  return [
    {
      label: "Доказательство",
      value: evidence.evidence_id,
      note: [kindLabels[evidence.kind], evidence.content_type].filter(Boolean).join(" · "),
    },
    {
      label: "Объект",
      value: evidence.asset_id,
      href: sourceHref(evidence.source_ref),
      note: evidence.source_ref,
    },
    {
      label: "Происхождение",
      value: provenanceLabels[evidence.provenance_status],
      note: `Права: ${rightsLabels[evidence.rights_status]}`,
      source: compactTimestamp(evidence.observed_at),
    },
    {
      label: "Целостность и вычисление",
      value: evidence.checksum ? compactDigest(evidence.checksum) : "контрольная сумма не опубликована",
      note: [runtime, metadata].filter(Boolean).join(" · ") || undefined,
      confidence: evidence.checksum ? "sha256" : "unknown",
    },
  ];
}

export function qazStackAssetResolutionToTrail(
  resolution: QazStackAssetResolutionViewInput,
): EvidenceTrailStep[] {
  const decisionLabels: Record<QazStackAssetResolutionViewInput["decision"], string> = {
    separate: "Объекты оставлены раздельно",
    link: "Объекты связаны",
    merge: "Объекты объединены",
    review: "Решение ожидает проверки",
  };
  return [
    {
      id: `${resolution.asset_id}:decision`,
      label: decisionLabels[resolution.decision],
      detail: `${resolution.reason} · ${resolution.decided_by}`,
      meta: compactTimestamp(resolution.decided_at),
      status: resolution.decision === "review" ? "current" : "verified",
    },
    ...resolution.candidates.map((candidate) => ({
      id: `${resolution.asset_id}:candidate:${candidate.candidate_id}`,
      label: `${candidate.label} · ${formatPercent(candidate.confidence)}`,
      detail: [
        formatCount(candidate.evidence_ids.length, "доказательство", "доказательства", "доказательств"),
        ...candidate.signals.map((signal) => `${signal.key} ${formatPercent(signal.score)}`),
      ].join(" · "),
      meta: candidate.candidate_id,
      status: candidate.candidate_id === resolution.chosen_candidate_id ? "verified" as const : "pending" as const,
    })),
  ];
}

export function qazStackAssetTimelineToTrail(
  events: readonly QazStackAssetTimelineViewInput[],
): EvidenceTrailStep[] {
  const eventTypeLabels: Record<QazStackAssetTimelineViewInput["event_type"], string> = {
    acquired: "приобретение",
    valued: "оценка",
    moved: "перемещение",
    lent: "передача",
    returned: "возврат",
    maintenance: "обслуживание",
    sold: "продажа",
    disposed: "выбытие",
    note: "примечание",
  };
  return [...events]
    .sort((left, right) => Date.parse(left.occurred_at) - Date.parse(right.occurred_at))
    .map((event) => ({
      id: event.event_id,
      label: event.title,
      detail: [eventTypeLabels[event.event_type], event.location, event.counterparty, event.note].filter(Boolean).join(" · "),
      meta: compactTimestamp(event.occurred_at),
      status: "verified" as const,
    }));
}

export function qazStackAssetQualityToFlags(
  quality: QazStackAssetQualityViewInput,
): DataQualityFlagProps[] {
  const overallSeverity: Record<QazStackAssetQualityViewInput["status"], DataQualitySeverity> = {
    complete: "verified",
    degraded: "warning",
    unknown: "unknown",
  };
  const qualityLabels: Record<QazStackAssetQualityViewInput["status"], string> = {
    complete: "качество подтверждено",
    degraded: "качество ограничено",
    unknown: "качество не определено",
  };
  const freshnessLabels: Record<QazStackAssetQualityViewInput["checks"][number]["freshness"], string> = {
    fresh: "свежие данные",
    stale: "данные устарели",
    unknown: "свежесть не определена",
  };
  const flags: DataQualityFlagProps[] = [
    {
      severity: overallSeverity[quality.status],
      label: `${quality.asset_id}: ${qualityLabels[quality.status]}`,
      detail: `Оценка ${formatPercent(quality.score)} · ${formatCount(quality.checks.length, "проверка", "проверки", "проверок")}`,
    },
  ];
  for (const check of quality.checks) {
    const severity: DataQualitySeverity = check.status === "pass" && check.freshness === "fresh"
      ? "verified"
      : check.status === "fail" || check.freshness === "stale"
        ? "warning"
        : "unknown";
    const statusLabel = check.status === "pass" ? "пройдено" : check.status === "fail" ? "не пройдено" : "не проверено";
    flags.push({
      severity,
      label: `${check.key}: ${statusLabel}`,
      detail: [
        check.reason || undefined,
        freshnessLabels[check.freshness],
        formatCount(check.evidence_ids.length, "доказательство", "доказательства", "доказательств"),
      ].filter(Boolean).join(" · "),
      compact: true,
    });
  }
  return flags;
}
