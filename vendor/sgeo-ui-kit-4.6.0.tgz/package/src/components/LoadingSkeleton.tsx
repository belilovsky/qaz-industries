import { Loader2 } from "lucide-react";
import { cn } from "../utils/cn";

/**
 * Каркас загрузки с анимацией мерцания.
 */

export interface LoadingSkeletonProps {
  /** Количество линий */
  lines?: number;
  /** Сообщение над каркасом загрузки (с иконкой загрузки) */
  message?: string;
  /** Высота каждой линии (px) */
  lineHeight?: number;
  /** Отступ между линиями (px) */
  lineGap?: number;
  className?: string;
}

function getLineWidth(index: number): string {
  const widths = [85, 75, 65, 55, 45];
  return `${widths[index] ?? widths[widths.length - 1]}%`;
}

export function LoadingSkeleton({
  lines = 3,
  message,
  lineHeight = 16,
  lineGap = 12,
  className,
}: LoadingSkeletonProps) {
  return (
    <div className={cn("space-y-0", className)}>
      {message && (
        <div className="mb-3 flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
          <span>{message}</span>
        </div>
      )}
      <div className="flex flex-col" style={{ gap: lineGap }}>
        {Array.from({ length: lines }, (_, i) => (
          <div
            key={i}
            className="animate-shimmer rounded"
            style={{
              width: getLineWidth(i),
              height: lineHeight,
              background:
                "linear-gradient(90deg, hsl(var(--muted)) 0%, hsl(var(--border)) 50%, hsl(var(--muted)) 100%)",
              backgroundSize: "200% 100%",
            }}
          />
        ))}
      </div>
    </div>
  );
}
