import { useState } from "react";
import { cn } from "../utils/cn";

/**
 * Простая столбчатая диаграмма с анимацией и всплывающими подсказками.
 */

export interface BarChartItem {
  label: string;
  value: number;
}

export interface BarChartProps {
  data: BarChartItem[];
  /** Высота области диаграммы (px) */
  height?: number;
  /** Цвет столбцов (CSS) */
  color?: string;
  /** Анимация роста столбцов */
  animate?: boolean;
  /** Показывать всплывающую подсказку при наведении */
  showTooltip?: boolean;
  /** Форматирование значения */
  valueFormatter?: (v: number) => string;
  className?: string;
}

export function BarChart({
  data,
  height = 140,
  color = "hsl(var(--primary))",
  animate = true,
  showTooltip = true,
  valueFormatter = (v) => String(v),
  className,
}: BarChartProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const maxValue = Math.max(...data.map((item) => Number.isFinite(item.value) ? Math.max(item.value, 0) : 0), 1);

  return (
    <div className={cn("w-full", className)}>
      <div className="relative flex items-end gap-2 border-b border-border/80" style={{ height }}>
        <span className="pointer-events-none absolute inset-x-0 top-1/3 border-t border-dashed border-border/45" aria-hidden="true" />
        <span className="pointer-events-none absolute inset-x-0 top-2/3 border-t border-dashed border-border/45" aria-hidden="true" />
        {data.map((item, i) => {
          const safeValue = Number.isFinite(item.value) ? Math.max(item.value, 0) : 0;
          const pct = (safeValue / maxValue) * 100;
          return (
            <div
              key={`${item.label}-${i}`}
              className="relative z-10 flex flex-1 flex-col items-center justify-end outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
              style={{ height: "100%" }}
              onMouseEnter={() => setHoveredIndex(i)}
              onMouseLeave={() => setHoveredIndex(null)}
              onFocus={() => setHoveredIndex(i)}
              onBlur={() => setHoveredIndex(null)}
              tabIndex={showTooltip ? 0 : undefined}
              role="img"
              aria-label={`${item.label}: ${valueFormatter(item.value)}`}
            >
              {showTooltip && hoveredIndex === i && (
                <div className="absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-sm bg-foreground px-2 py-1 text-[11px] font-medium text-background shadow-md">
                  {valueFormatter(item.value)}
                </div>
              )}
              <div
                className="w-[72%] max-w-24 rounded-t-[2px] transition-opacity hover:opacity-80"
                style={{
                  height: `${pct}%`,
                  minHeight: safeValue > 0 ? 4 : 0,
                  backgroundColor: color,
                  animation: animate ? `barChartGrow 0.4s cubic-bezier(0.16, 1, 0.3, 1) ${i * 0.05}s both` : undefined,
                  transformOrigin: "bottom",
                }}
              />
            </div>
          );
        })}
      </div>
      <div className="mt-2 flex gap-2">
        {data.map((item, i) => (
          <div
            key={`${item.label}-${i}`}
            className="flex-1 truncate text-center text-[11px] text-muted-foreground"
          >
            {item.label}
          </div>
        ))}
      </div>
    </div>
  );
}
