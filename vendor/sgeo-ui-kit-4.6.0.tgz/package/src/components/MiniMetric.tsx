import { cn } from "../utils/cn";

/**
 * Компактный метрика-блок: иконка + подпись + значение.
 */

export interface MiniMetricProps {
  /** Lucide-иконка или любой ReactNode */
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
  /** Короткий kicker/eyebrow над значением */
  kicker?: string;
  /** Подпись */
  label: string;
  /** Значение */
  value: string | number;
  /** Подтекст (например, "за 7 дней") */
  subtext?: string;
  /** Цвет иконки и фона */
  color?: string;
  /** Изменение (+12%, -5%) */
  delta?: string;
  /** Тип изменения */
  deltaType?: "positive" | "negative" | "neutral";
  className?: string;
}

export function MiniMetric({ icon: Icon, kicker, label, value, subtext, color, delta, deltaType, className }: MiniMetricProps) {
  return (
    <div className={cn("grid min-w-0 content-start gap-2 rounded-sm border border-border/70 bg-card px-3 py-3 text-start", className)}>
      <div className="flex min-w-0 items-center gap-2">
        <Icon className="h-4 w-4 shrink-0" style={{ color: color || "hsl(var(--muted-foreground))" }} />
        <span className="min-w-0 truncate text-[9px] font-semibold uppercase tracking-[0.06em] text-muted-foreground">
          {kicker ?? label}
        </span>
      </div>
      <div className="flex items-end justify-between gap-3">
        <span className="text-[1.5rem] font-semibold leading-none tabular-nums text-foreground">{value}</span>
        {delta ? (
          <span
            className={cn(
              "pb-0.5 text-[10px] font-semibold tabular-nums",
              deltaType === "positive" && "text-foreground",
              deltaType === "negative" && "text-[hsl(var(--destructive))]",
              deltaType === "neutral" && "text-foreground/75"
            )}
          >
            {delta}
          </span>
        ) : null}
      </div>
      {kicker || subtext ? (
        <div className="flex min-w-0 items-start justify-between gap-2 text-[10px] leading-snug text-muted-foreground">
          {kicker ? <span className="min-w-0 text-foreground/80">{label}</span> : <span />}
          {subtext ? <span className="shrink-0 text-end">{subtext}</span> : null}
        </div>
      ) : null}
    </div>
  );
}
