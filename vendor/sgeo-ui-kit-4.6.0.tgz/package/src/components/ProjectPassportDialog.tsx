import { type ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "../utils/cn";
import { SourceHealthBadge, type SourceHealthStatus } from "./SourceHealthBadge";

export interface ProjectPassportMetric { label: string; value: ReactNode; }
export interface ProjectPassportDetail { label: string; value: ReactNode; }
export interface ProjectPassportLink { label: string; href: string; external?: boolean; }

export interface ProjectPassportDialogProps {
  open: boolean;
  title: string;
  summary?: string;
  status?: SourceHealthStatus;
  statusLabel?: string;
  metrics?: ProjectPassportMetric[];
  details?: ProjectPassportDetail[];
  links?: ProjectPassportLink[];
  onClose?: () => void;
  className?: string;
}

/** Public-safe object passport. The host owns focus trapping and mutation logic. */
export function ProjectPassportDialog({ open, title, summary, status, statusLabel, metrics, details, links, onClose, className }: ProjectPassportDialogProps) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end bg-foreground/35 p-0 sm:items-center sm:justify-center sm:p-6" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose?.(); }}>
      <section role="dialog" aria-modal="true" aria-labelledby="project-passport-title" className={cn("max-h-[90vh] w-full overflow-y-auto rounded-t-lg border border-border bg-background p-5 shadow-2xl sm:max-w-2xl sm:rounded-lg sm:p-6", className)}>
        <header className="flex items-start justify-between gap-4 border-b border-border pb-4">
          <div className="min-w-0">
            <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">Паспорт объекта</div>
            <h2 id="project-passport-title" className="mt-1 text-xl font-semibold leading-snug text-foreground">{title}</h2>
            {summary ? <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{summary}</p> : null}
          </div>
          {onClose ? <button type="button" onClick={onClose} className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-border text-muted-foreground hover:bg-muted/50 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30" aria-label="Закрыть паспорт"><X className="h-4 w-4" /></button> : null}
        </header>
        {status ? <div className="mt-4"><SourceHealthBadge status={status} label={statusLabel} size="md" /></div> : null}
        {metrics?.length ? <dl className="mt-4 grid gap-2 sm:grid-cols-2">{metrics.map((metric, index) => <div key={`${metric.label}-${index}`} className="rounded-md border border-border bg-card px-3 py-3"><dt className="text-[11px] font-medium uppercase tracking-[0.06em] text-muted-foreground">{metric.label}</dt><dd className="mt-1 text-base font-semibold text-foreground">{metric.value}</dd></div>)}</dl> : null}
        {details?.length ? <dl className="mt-5 divide-y divide-border border-y border-border">{details.map((detail, index) => <div key={`${detail.label}-${index}`} className="grid gap-1 py-3 text-sm sm:grid-cols-[minmax(9rem,0.7fr)_minmax(0,1.3fr)]"><dt className="font-medium text-foreground">{detail.label}</dt><dd className="min-w-0 text-muted-foreground">{detail.value}</dd></div>)}</dl> : null}
        {links?.length ? <footer className="mt-5 flex flex-wrap gap-2">{links.map((link) => <a key={link.href} href={link.href} target={link.external ? "_blank" : undefined} rel={link.external ? "noopener noreferrer" : undefined} className="inline-flex min-h-9 items-center rounded-md border border-border bg-background px-3 text-sm font-medium text-foreground no-underline hover:bg-muted/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30">{link.label}</a>)}</footer> : null}
      </section>
    </div>
  );
}
