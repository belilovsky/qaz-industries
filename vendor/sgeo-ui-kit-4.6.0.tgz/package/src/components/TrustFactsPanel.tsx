import { cn } from "../utils/cn";

export interface TrustFactItem {
  title: string;
  description: string;
}

export interface TrustFactLink {
  label: string;
  href: string;
  ariaLabel?: string;
}

export interface TrustFactsPanelProps {
  title: string;
  summary?: string;
  items: TrustFactItem[];
  links?: TrustFactLink[];
  className?: string;
}

export function TrustFactsPanel({
  title,
  summary,
  items,
  links = [],
  className,
}: TrustFactsPanelProps) {
  return (
    <aside
      className={cn(
        "max-w-[360px] border-t border-border/80 pt-4",
        className
      )}
    >
      <h3 className="font-serif text-[1.15rem] font-semibold leading-tight text-foreground">{title}</h3>
      {summary ? <p className="mt-2 text-sm leading-[1.65] text-muted-foreground">{summary}</p> : null}

      <div className="mt-4 grid gap-2.5">
        {items.map((item, index) => (
          <div
            key={`${item.title}-${index}`}
            className={cn(
              "grid gap-1 border-b border-border/70 pb-2.5",
              index === items.length - 1 && "border-b-0 pb-0"
            )}
          >
            <strong className="text-[13px] font-semibold text-foreground">{item.title}</strong>
            <span className="text-[12px] leading-[1.55] text-muted-foreground">{item.description}</span>
          </div>
        ))}
      </div>

      {links.length ? (
        <div className="mt-4 flex flex-wrap gap-2.5">
          {links.map((link, index) => (
            <a
              key={`${link.label}-${index}`}
              href={link.href}
              aria-label={link.ariaLabel}
              className="text-[13px] font-medium text-primary underline-offset-4 hover:underline"
            >
              {link.label}
            </a>
          ))}
        </div>
      ) : null}
    </aside>
  );
}
