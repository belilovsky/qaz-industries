import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { cn } from "../utils/cn";

/**
 * Toast-уведомления – провайдер, хук useToast, компонент Toast.
 */

export type ToastType = "success" | "error" | "info" | "warning";

export interface ToastItem {
  id: string;
  message: string;
  type: ToastType;
  duration: number;
}

export interface ToastOptions {
  message: string;
  type?: ToastType;
  duration?: number;
}

interface ToastContextValue {
  toast: (options: ToastOptions) => string;
  dismiss: (id: string) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

let toastCounter = 0;

const typeConfig: Record<ToastType, { accent: string }> = {
  success: { accent: "hsl(var(--chart-2))" },
  error: { accent: "hsl(var(--destructive))" },
  warning: { accent: "hsl(var(--chart-3))" },
  info: { accent: "hsl(var(--primary))" },
};

function ToastEntry({
  item,
  onDismiss,
}: {
  item: ToastItem;
  onDismiss: (id: string) => void;
}) {
  const [exiting, setExiting] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    timerRef.current = setTimeout(() => {
      setExiting(true);
    }, item.duration);
    return () => clearTimeout(timerRef.current);
  }, [item.duration]);

  const handleAnimationEnd = () => {
    if (exiting) onDismiss(item.id);
  };

  const handleClose = () => {
    clearTimeout(timerRef.current);
    setExiting(true);
  };

  const cfg = typeConfig[item.type];

  return (
    <div
      role={item.type === "error" || item.type === "warning" ? "alert" : "status"}
      aria-live={item.type === "error" || item.type === "warning" ? "assertive" : "polite"}
      aria-atomic="true"
      className={cn(
        "pointer-events-auto relative flex w-full items-start gap-3 rounded-sm border border-border/70 bg-card px-4 py-3 text-card-foreground shadow-md",
        exiting ? "animate-toastSlideOut" : "animate-toastSlideIn"
      )}
      onAnimationEnd={handleAnimationEnd}
    >
      <span className="mt-0.5 h-2 w-2 flex-shrink-0 rounded-full" style={{ backgroundColor: cfg.accent }} />
      <span className="flex-1 text-sm text-foreground">{item.message}</span>
      <button
        type="button"
        onClick={handleClose}
        className="flex-shrink-0 rounded-sm p-0.5 text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label="Закрыть уведомление"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const toast = useCallback((options: ToastOptions): string => {
    const id = `toast-${++toastCounter}`;
    const item: ToastItem = {
      id,
      message: options.message,
      type: options.type ?? "info",
      duration: options.duration ?? 3000,
    };
    setToasts((prev) => [...prev, item]);
    return id;
  }, []);

  const dismiss = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ toast, dismiss }}>
      {children}
      <div className="pointer-events-none fixed inset-x-4 bottom-4 z-50 flex flex-col items-end gap-2 sm:left-auto sm:w-full sm:max-w-sm">
        {toasts.map((item) => (
          <ToastEntry key={item.id} item={item} onDismiss={dismiss} />
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used within <ToastProvider>");
  return ctx;
}

export function Toast() {
  return null;
}
