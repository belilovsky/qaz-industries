import { cn } from "../utils/cn";
import { DataQualityFlag } from "./DataQualityFlag";

export interface ExportReceiptProps {
  title?: string;
  format: string;
  rows?: number;
  generatedAt: string | number | Date;
  source?: string;
  checksum?: string;
  status?: "ready" | "partial" | "failed";
  note?: string;
  className?: string;
}

const receiptStatus = {
  ready: { severity: "verified", label: "Экспорт готов" },
  partial: { severity: "warning", label: "Экспорт неполный" },
  failed: { severity: "critical", label: "Экспорт не создан" },
} as const;

export function ExportReceipt({
  title = "Квитанция экспорта", format, rows, generatedAt, source, checksum, status = "ready", note, className,
}: ExportReceiptProps) {
  const state = receiptStatus[status];
  const parsedDate = new Date(generatedAt);
  const formattedDate = Number.isFinite(parsedDate.getTime())
    ? new Intl.DateTimeFormat("ru", { dateStyle: "medium", timeStyle: "short" }).format(parsedDate)
    : "время не указано";

  return (
    <section className={cn("rounded-sm border border-border/80 bg-card", className)} aria-label={title}>
      <div className="flex flex-wrap items-center justify-between gap-3 px-3.5 py-3">
        <h3 className="text-[13px] font-semibold text-foreground">{title}</h3>
        <DataQualityFlag severity={state.severity} label={state.label} compact />
      </div>
      <dl className="grid border-t border-border/70 text-[11px] sm:grid-cols-2 lg:grid-cols-4">
        <div className="px-3.5 py-2.5"><dt className="text-muted-foreground">Формат</dt><dd className="mt-0.5 font-mono font-medium uppercase text-foreground">{format}</dd></div>
        <div className="border-t border-border/70 px-3.5 py-2.5 sm:border-s sm:border-t-0"><dt className="text-muted-foreground">Строк</dt><dd className="mt-0.5 font-mono font-medium tabular-nums text-foreground">{rows?.toLocaleString("ru") ?? "–"}</dd></div>
        <div className="border-t border-border/70 px-3.5 py-2.5 lg:border-s lg:border-t-0"><dt className="text-muted-foreground">Создан</dt><dd className="mt-0.5 text-foreground">{formattedDate}</dd></div>
        <div className="border-t border-border/70 px-3.5 py-2.5 sm:border-s lg:border-t-0"><dt className="text-muted-foreground">Источник</dt><dd className="mt-0.5 text-foreground">{source ?? "не указан"}</dd></div>
      </dl>
      {checksum || note ? (
        <div className="grid gap-2 border-t border-border/70 px-3.5 py-2.5 text-[11px] sm:grid-cols-[minmax(0,1fr)_auto]">
          <p className="text-muted-foreground">{note ?? "Параметры экспорта зафиксированы."}</p>
          {checksum ? <code className="break-all text-[10px] text-foreground">sha256:{checksum}</code> : null}
        </div>
      ) : null}
    </section>
  );
}
