import { cn } from "../utils/cn";

export interface InlineAssistantPrompt {
  label: string;
  value?: string;
}

export interface InlineDocumentAssistantPanelProps {
  kicker?: string;
  title: string;
  summary?: string;
  prompts: InlineAssistantPrompt[];
  onPromptClick?: (prompt: InlineAssistantPrompt) => void;
  ctaHref?: string;
  ctaLabel?: string;
  className?: string;
}

export function InlineDocumentAssistantPanel({
  kicker = "Документный помощник",
  title,
  summary,
  prompts,
  onPromptClick,
  ctaHref,
  ctaLabel,
  className,
}: InlineDocumentAssistantPanelProps) {
  return (
    <section
      className={cn(
        "my-7 grid gap-5 rounded-sm border border-border bg-muted/15 px-5 py-5 md:grid-cols-[minmax(0,1fr)_minmax(260px,0.86fr)] md:items-center",
        className
      )}
    >
      <div className="min-w-0">
        <p className="mb-2 text-[0.75rem] font-extrabold uppercase tracking-[0.08em] text-primary">{kicker}</p>
        <h3 className="text-xl font-semibold leading-tight text-foreground">{title}</h3>
        {summary ? <p className="mt-2 text-sm leading-[1.6] text-muted-foreground">{summary}</p> : null}
        {ctaHref && ctaLabel ? (
          <a
            href={ctaHref}
            className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-primary no-underline hover:underline"
          >
            <span>{ctaLabel}</span>
            <span aria-hidden="true">→</span>
          </a>
        ) : null}
      </div>

      <div className="grid gap-2.5">
        {prompts.map((prompt, index) => {
          const button = (
            <button
              type="button"
              className="w-full rounded-sm border border-primary/20 bg-background px-4 py-3 text-start text-sm font-semibold text-foreground transition-[border-color,background-color] duration-150 hover:border-primary/45 hover:bg-muted/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              onClick={onPromptClick ? () => onPromptClick(prompt) : undefined}
            >
              {prompt.label}
            </button>
          );

          if (onPromptClick) {
            return <div key={`${prompt.label}-${index}`}>{button}</div>;
          }

          return (
            <div key={`${prompt.label}-${index}`} data-prompt-value={prompt.value || prompt.label}>
              {button}
            </div>
          );
        })}
      </div>
    </section>
  );
}
