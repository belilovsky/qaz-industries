import React, { useId } from "react";
import { cn } from "../utils/cn";

export interface AdminMediaItem {
  id: string;
  src: string;
  alt: string;
  title: React.ReactNode;
  meta?: React.ReactNode;
  disabled?: boolean;
}

export interface AdminMediaPickerProps {
  items: AdminMediaItem[];
  selectedId?: string;
  onSelect?: (id: string) => void;
  title?: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  emptyMessage?: React.ReactNode;
  className?: string;
}

export function AdminMediaPicker({
  items,
  selectedId,
  onSelect,
  title = "Медиатека",
  description,
  actions,
  emptyMessage = "Медиафайлы не найдены.",
  className,
}: AdminMediaPickerProps) {
  const titleId = useId();

  return (
    <section aria-labelledby={titleId} className={cn("avds-admin-media-picker", className)}>
      <header className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="min-w-0">
          <h3 id={titleId} className="text-sm font-semibold text-foreground">{title}</h3>
          {description ? <div className="mt-1 text-[12px] leading-relaxed text-muted-foreground">{description}</div> : null}
        </div>
        {actions ? <div className="flex shrink-0 flex-wrap gap-2">{actions}</div> : null}
      </header>
      {items.length === 0 ? (
        <div className="border-y border-dashed border-border px-4 py-8 text-center text-[13px] text-muted-foreground">{emptyMessage}</div>
      ) : (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((item) => {
            const selected = selectedId === item.id;
            return (
              <button
                key={item.id}
                type="button"
                disabled={item.disabled}
                aria-pressed={selected}
                onClick={() => onSelect?.(item.id)}
                className={cn(
                  "group min-w-0 border bg-background text-start transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35",
                  selected ? "border-primary ring-1 ring-primary/20" : "border-border/80 hover:border-primary/45",
                  item.disabled && "cursor-not-allowed opacity-45"
                )}
              >
                <div className="aspect-[4/3] overflow-hidden bg-muted/35">
                  <img src={item.src} alt={item.alt} className="size-full object-cover transition-transform duration-200 group-hover:scale-[1.015]" loading="lazy" />
                </div>
                <div className="border-t border-border/70 px-2.5 py-2">
                  <div className="truncate text-[12px] font-medium text-foreground">{item.title}</div>
                  {item.meta ? <div className="mt-1 truncate text-[10px] text-muted-foreground">{item.meta}</div> : null}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
}
