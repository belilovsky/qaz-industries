import type * as React from "react";
import { cn } from "../../utils/cn";

export interface RangeBarProps {
  label: React.ReactNode;
  /** Left edge of the value range (min). */
  min: number;
  /** Right edge of the value range (max). */
  max: number;
  /** Optional midpoint marker (e.g. averaged value). */
  midpoint?: number;
  /** Scale lower bound (default 0). */
  scaleMin?: number;
  /** Scale upper bound (default 100). */
  scaleMax?: number;
  /** Highlight conflict between sources. */
  conflict?: boolean;
  /** Right-hand hint text (defaults to "min-max"). */
  hint?: React.ReactNode;
  className?: string;
}

/**
 * RangeBar visualises a value range [min..max] on a fixed scale
 * [scaleMin..scaleMax]. Used when sources disagree and a single
 * point estimate would hide uncertainty.
 */
export function RangeBar({
  label,
  min,
  max,
  midpoint,
  scaleMin = 0,
  scaleMax = 100,
  conflict = false,
  hint,
  className,
}: RangeBarProps) {
  const safeScaleMin = Number.isFinite(scaleMin) ? scaleMin : 0;
  const safeScaleMax = Number.isFinite(scaleMax) && scaleMax !== safeScaleMin ? scaleMax : safeScaleMin + 100;
  const safeMin = Number.isFinite(min) ? min : safeScaleMin;
  const safeMax = Number.isFinite(max) ? max : safeMin;
  const safeMidpoint = midpoint != null && Number.isFinite(midpoint) ? midpoint : null;
  const span = Math.max(0.0001, safeScaleMax - safeScaleMin);
  const pct = (v: number) =>
    Math.max(0, Math.min(100, ((v - safeScaleMin) / span) * 100));
  const lo = Math.min(safeMin, safeMax);
  const hi = Math.max(safeMin, safeMax);
  const left = pct(lo);
  const right = pct(hi);
  const width = Math.max(0.5, right - left);
  const mid = safeMidpoint == null ? null : pct(safeMidpoint);
  const tone = conflict ? "--color-warning" : "--accent";

  return (
    <div
      className={cn(
        "avds-range-bar grid items-center gap-5 px-3.5 py-2.5 rounded-sm border transition-colors",
        conflict
          ? "bg-[color-mix(in_oklab,var(--color-warning),transparent_92%)] border-[color-mix(in_oklab,var(--color-warning),transparent_60%)]"
          : "bg-muted/40 border-border",
        className,
      )}
      style={{ gridTemplateColumns: "minmax(220px,_320px)_1fr_160px" }}
      role="img"
      aria-label={`${typeof label === "string" ? label : "range"}: ${lo}-${hi}`}
    >
      <div className="flex flex-col gap-0.5 min-w-0">
        <b className="text-foreground font-bold text-[14.5px] leading-tight break-words">
          {label}
        </b>
        {conflict ? (
          <span className="text-[10.5px] uppercase tracking-[0.04em] font-medium text-[var(--color-warning)]">
            Конфликт источников
          </span>
        ) : null}
      </div>
      <div className="relative h-3.5 bg-muted rounded-sm overflow-hidden">
        <div
          className="absolute top-0 bottom-0 rounded-sm transition-[left,width]"
          style={{
            insetInlineStart: `${left}%`,
            width: `${width}%`,
            background: `var(${tone})`,
            transitionDuration: "900ms",
          }}
        />
        {mid != null ? (
          <div
            className="absolute top-[-2px] bottom-[-2px] w-[2px] bg-foreground/80"
            style={{ insetInlineStart: `calc(${mid}% - 1px)` }}
            aria-hidden
          />
        ) : null}
      </div>
      <div className="text-end font-semibold text-[15px] tabular-nums tracking-[-0.01em] font-mono text-foreground">
        {hint ?? `${lo}–${hi}`}
      </div>
    </div>
  );
}
