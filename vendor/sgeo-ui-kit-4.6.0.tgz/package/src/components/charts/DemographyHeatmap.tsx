import type * as React from "react";
import { cn } from "../../utils/cn";

export interface DemographyCell {
  /** Row key (e.g. age bucket "18-24"). */
  row: string;
  /** Column key (e.g. "male" / "female" or platform name). */
  col: string;
  /** Cell value 0..1 (share) or 0..100 (percent). */
  value: number;
  /** Optional override label shown in tooltip / aria. */
  label?: string;
}

export interface DemographyHeatmapProps {
  /** Row order (top to bottom). */
  rows: string[];
  /** Column order (left to right). */
  cols: string[];
  cells: DemographyCell[];
  /** Value scale upper bound; default 100. */
  scaleMax?: number;
  /** Optional heatmap title. */
  title?: React.ReactNode;
  /** Optional caption below the grid. */
  caption?: React.ReactNode;
  className?: string;
}

/**
 * DemographyHeatmap renders a 2D matrix of audience shares.
 * Typical use: age x gender x platform breakdowns from QazLake.
 */
export function DemographyHeatmap({
  rows,
  cols,
  cells,
  scaleMax = 100,
  title,
  caption,
  className,
}: DemographyHeatmapProps) {
  const index = new Map<string, DemographyCell>();
  for (const c of cells) index.set(`${c.row}|${c.col}`, c);
  const safeScaleMax = Number.isFinite(scaleMax) && scaleMax > 0 ? scaleMax : 100;
  const normalizeValue = (value: number) => {
    if (!Number.isFinite(value)) return 0;
    if (safeScaleMax > 1 && value >= 0 && value <= 1) return value * 100;
    return value;
  };

  const intensity = (v: number) => {
    const t = Math.max(0, Math.min(1, normalizeValue(v) / Math.max(0.0001, safeScaleMax)));
    // A restrained alpha range keeps semantic foreground text AA-readable in light and dark themes.
    return 0.08 + 0.34 * t;
  };
  const displayValue = (value: number) => {
    const normalized = normalizeValue(value);
    return Math.abs(normalized) < 10 && !Number.isInteger(normalized)
      ? normalized.toFixed(1)
      : String(Math.round(normalized));
  };

  return (
    <div
      className={cn(
        "avds-demography-heatmap flex flex-col gap-2 p-3.5 rounded-sm border bg-muted/30 border-border",
        className,
      )}
    >
      {title ? (
        <div className="text-foreground font-bold text-[14.5px] leading-tight">
          {title}
        </div>
      ) : null}
      <div
        className="-mx-1 overflow-x-auto px-1 pb-1"
        tabIndex={0}
        role="group"
        aria-label="Прокрутка матрицы по горизонтали"
      >
        <div
          className="grid gap-[2px]"
          role="table"
          aria-label={typeof title === "string" ? title : "Демографическая матрица"}
          style={{
            gridTemplateColumns: `minmax(5.5rem, 8rem) repeat(${cols.length}, minmax(4.75rem, 1fr))`,
            minWidth: `${Math.max(320, 112 + cols.length * 80)}px`,
          }}
        >
        <div role="row" className="contents">
          <div role="columnheader" aria-hidden />
          {cols.map((c) => (
            <div
              key={`h-${c}`}
              className="relative z-10 rounded-sm bg-background px-1 py-1 text-center text-[10.5px] font-semibold uppercase tracking-[0.04em] text-foreground"
              role="columnheader"
            >
              {c}
            </div>
          ))}
        </div>
        {rows.map((r) => (
          <div key={`row-${r}`} role="row" className="contents">
            <div
              className="self-center pe-2 text-[12px] font-medium text-foreground/90"
              role="rowheader"
            >
              {r}
            </div>
            {cols.map((c) => {
              const cell = index.get(`${r}|${c}`);
              const v = cell ? cell.value : 0;
              const alpha = intensity(v);
              const readableValue = cell ? displayValue(v) : "–";
              return (
                <div
                  key={`c-${r}-${c}`}
                  className="relative flex h-9 items-center justify-center rounded-sm font-mono text-[12.5px] tabular-nums text-foreground"
                  role="cell"
                  aria-label={cell?.label ?? `${r} / ${c}: ${readableValue}`}
                  style={{
                    backgroundColor: `hsl(var(--primary) / ${alpha.toFixed(3)})`,
                    color: "hsl(var(--foreground))",
                  }}
                >
                  {readableValue}
                </div>
              );
            })}
          </div>
        ))}
        </div>
      </div>
      {caption ? (
        <div className="text-[11px] text-foreground/75">{caption}</div>
      ) : null}
    </div>
  );
}
