export interface ComponentMeta {
  name: string;
  slug: string;
  category: string;
  lifecycle: "stable" | "experimental" | "deprecated";
  status: "live" | "showcase-only" | "deprecated" | "hidden";
  versionAdded: string;
  loc: number;
  usedBy: string[];
}

export const meta: ComponentMeta = {
  name: "DemographyHeatmap",
  slug: "demography-heatmap",
  category: "charts",
  lifecycle: "experimental",
  status: "live",
  versionAdded: "3.8.0",
  loc: 119,
  usedBy: ["regional-brief"],
};
