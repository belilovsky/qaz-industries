import React from "react";
import { cn } from "../utils/cn";

export interface AdminBulkActionBarProps {
  selectedCount: number;
  totalCount?: number;
  actions: React.ReactNode;
  label?: string;
  onClear?: () => void;
  clearLabel?: string;
  sticky?: boolean;
  className?: string;
}

export function AdminBulkActionBar({
  selectedCount,
  totalCount,
  actions,
  label = "Выбрано",
  onClear,
  clearLabel = "Снять выбор",
  sticky = false,
  className,
}: AdminBulkActionBarProps) {
  return (
    <section
      aria-label="Массовые действия"
      className={cn(
        "avds-admin-bulk-bar flex min-h-11 flex-col gap-2 border-y border-primary/35 bg-primary/[0.055] px-3 py-2 sm:flex-row sm:items-center",
        sticky && "sticky bottom-0 z-20 shadow-[0_-8px_24px_hsl(var(--background)/0.92)]",
        className
      )}
    >
      <div aria-live="polite" className="text-[13px] font-medium text-foreground">
        {label}: <span className="tabular-nums">{selectedCount}</span>
        {totalCount !== undefined ? <span className="font-normal text-foreground/75"> из {totalCount}</span> : null}
      </div>
      <div className="flex min-w-0 flex-wrap items-center gap-2 sm:ms-auto">{actions}</div>
      {onClear ? (
        <button
          type="button"
          className="text-[12px] font-medium text-foreground/75 underline-offset-4 hover:text-foreground hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35"
          onClick={onClear}
        >
          {clearLabel}
        </button>
      ) : null}
    </section>
  );
}
