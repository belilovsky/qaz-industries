import { cn } from "../utils/cn";

export type TrendSparklineTone = "primary" | "success" | "warning" | "danger" | "neutral";

export interface TrendSparklineProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Numeric series in display order. Non-finite values are ignored. */
  data: readonly number[];
  /** Accessible description of the series and period. */
  ariaLabel: string;
  /** Semantic color family. */
  tone?: TrendSparklineTone;
  /** Optional value drawn as a quiet horizontal comparison line. */
  referenceValue?: number;
  /** Fill the area below the line without changing the data encoding. */
  showArea?: boolean;
}

const WIDTH = 100;
const HEIGHT = 32;
const INSET_X = 2;
const INSET_Y = 3;

const toneClassNames: Record<TrendSparklineTone, string> = {
  primary: "text-[hsl(var(--chart-1))]",
  success: "text-[hsl(var(--chart-2))]",
  warning: "text-[hsl(var(--chart-4))]",
  danger: "text-[hsl(var(--destructive))]",
  neutral: "text-muted-foreground",
};

function getScale(values: readonly number[], referenceValue?: number) {
  const domain = referenceValue === undefined ? values : [...values, referenceValue];
  const min = Math.min(...domain);
  const max = Math.max(...domain);
  const span = max - min;

  return {
    x: (index: number) =>
      values.length === 1
        ? WIDTH / 2
        : INSET_X + (index / (values.length - 1)) * (WIDTH - INSET_X * 2),
    y: (value: number) =>
      span === 0
        ? HEIGHT / 2
        : HEIGHT - INSET_Y - ((value - min) / span) * (HEIGHT - INSET_Y * 2),
  };
}

export function TrendSparkline({
  data,
  ariaLabel,
  tone = "primary",
  referenceValue,
  showArea = false,
  className,
  ...props
}: TrendSparklineProps) {
  const values = data.filter(Number.isFinite);

  if (values.length === 0) {
    return (
      <div
        {...props}
        className={cn("flex h-10 min-w-0 items-center text-muted-foreground", className)}
        role="img"
        aria-label={ariaLabel}
        data-state="empty"
      >
        <span className="w-full border-t border-dashed border-border" aria-hidden="true" />
      </div>
    );
  }

  const scale = getScale(values, referenceValue);
  const points = values.map((value, index) => `${scale.x(index)},${scale.y(value)}`).join(" ");
  const firstX = scale.x(0);
  const lastX = scale.x(values.length - 1);
  const lastY = scale.y(values[values.length - 1] ?? 0);
  const areaPath = `M ${firstX} ${HEIGHT - INSET_Y} L ${points.replaceAll(" ", " L ")} L ${lastX} ${HEIGHT - INSET_Y} Z`;

  return (
    <div
      {...props}
      className={cn("h-10 min-w-0", toneClassNames[tone], className)}
      data-state="ready"
      data-count={values.length}
    >
      <svg
        className="block h-full w-full overflow-visible"
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        preserveAspectRatio="none"
        role="img"
        aria-label={ariaLabel}
      >
        <title>{ariaLabel}</title>
        {referenceValue !== undefined ? (
          <line
            x1={INSET_X}
            x2={WIDTH - INSET_X}
            y1={scale.y(referenceValue)}
            y2={scale.y(referenceValue)}
            stroke="hsl(var(--border))"
            strokeDasharray="2 2"
            vectorEffect="non-scaling-stroke"
          />
        ) : null}
        {showArea && values.length > 1 ? (
          <path d={areaPath} fill="currentColor" fillOpacity="0.1" aria-hidden="true" />
        ) : null}
        <polyline
          points={points}
          fill="none"
          stroke="currentColor"
          strokeWidth="1.75"
          strokeLinecap="round"
          strokeLinejoin="round"
          vectorEffect="non-scaling-stroke"
          aria-hidden="true"
        />
        <circle
          cx={lastX}
          cy={lastY}
          r="2"
          fill="hsl(var(--background))"
          stroke="currentColor"
          strokeWidth="1.5"
          vectorEffect="non-scaling-stroke"
          aria-hidden="true"
        />
      </svg>
    </div>
  );
}
