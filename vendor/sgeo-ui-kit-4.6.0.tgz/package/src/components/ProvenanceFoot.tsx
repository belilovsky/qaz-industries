import { cn } from "../utils/cn";
import { SourceBadge } from "./SourceBadge";

export interface ProvenanceFootSource {
  label: string;
  sourceKey?: string;
  href?: string;
}

export interface ProvenanceFootProps {
  sources: ProvenanceFootSource[];
  layerLabel?: string;
  periodLabel?: string;
  registryHref?: string;
  registryLabel?: string;
  note?: string;
  className?: string;
}

function SourceToken({ source }: { source: ProvenanceFootSource }) {
  const token = source.sourceKey ? (
    <SourceBadge source={source.sourceKey} label={source.label} size="sm" />
  ) : (
    <span className="inline-flex rounded-full border border-border/80 bg-background px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
      {source.label}
    </span>
  );

  if (source.href) {
    return (
      <a href={source.href} className="no-underline">
        {token}
      </a>
    );
  }

  return token;
}

export function ProvenanceFoot({
  sources,
  layerLabel,
  periodLabel,
  registryHref,
  registryLabel = "Реестр источников",
  note,
  className,
}: ProvenanceFootProps) {
  return (
    <div className={cn("grid gap-2 text-[12px] leading-relaxed text-muted-foreground", className)}>
      <div className="flex flex-wrap items-center gap-2">
        {sources.map((source, index) => (
          <SourceToken key={`${source.label}-${index}`} source={source} />
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
        {periodLabel ? <span>Период: {periodLabel}</span> : null}
        {layerLabel ? <span>Слой: <code className="rounded bg-muted px-1.5 py-0.5 text-[11px] text-foreground">{layerLabel}</code></span> : null}
        {registryHref ? (
          <a href={registryHref} className="text-primary underline-offset-4 hover:underline">
            {registryLabel}
          </a>
        ) : null}
      </div>
      {note ? <div>{note}</div> : null}
    </div>
  );
}
