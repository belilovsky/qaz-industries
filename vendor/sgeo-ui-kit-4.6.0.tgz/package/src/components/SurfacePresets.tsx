import React from "react";
import { cn } from "../utils/cn";
import { DecisionFeed, type DecisionFeedProps } from "./DecisionFeed";
import { DocumentCard, type DocumentCardProps } from "./DocumentCard";
import { FilterChipRow, type FilterChipRowProps } from "./FilterChipRow";
import { InlineDocumentAssistantPanel, type InlineDocumentAssistantPanelProps } from "./InlineDocumentAssistantPanel";
import { MetricCard, type MetricCardProps } from "./MetricCard";
import { PageHeader } from "./PageHeader";
import { ProvenanceFoot, type ProvenanceFootProps } from "./ProvenanceFoot";
import { ProvenanceTable, type ProvenanceTableProps } from "./ProvenanceTable";
import { PublicSummaryStrip, type PublicSummaryStripProps } from "./PublicSummaryStrip";
import { ReportToolbar, type ReportToolbarProps } from "./ReportToolbar";
import { StatePanel, type StatePanelProps } from "./StatePanel";
import { TrustFactsPanel, type TrustFactsPanelProps } from "./TrustFactsPanel";
import { WorkflowPath, type WorkflowPathProps } from "./WorkflowPath";

export interface OperatorReviewSurfaceProps {
  title: string;
  description?: string;
  metrics: MetricCardProps[];
  toolbar?: ReportToolbarProps;
  workflow: WorkflowPathProps;
  decisions: DecisionFeedProps;
  table?: React.ReactNode;
  state?: StatePanelProps;
  className?: string;
}

export interface EvidenceSummarySurfaceProps {
  title: string;
  description?: string;
  summary: PublicSummaryStripProps;
  provenance: ProvenanceTableProps;
  foot: ProvenanceFootProps;
  facts?: TrustFactsPanelProps;
  className?: string;
}

export interface ContentDigestSurfaceProps {
  title: string;
  description?: string;
  filters?: FilterChipRowProps;
  documents: DocumentCardProps[];
  assistant?: InlineDocumentAssistantPanelProps;
  emptyState?: StatePanelProps;
  className?: string;
}

export function OperatorReviewSurface({
  title,
  description,
  metrics,
  toolbar,
  workflow,
  decisions,
  table,
  state,
  className,
}: OperatorReviewSurfaceProps) {
  return (
    <section className={cn("grid gap-4", className)} aria-label={title}>
      <PageHeader title={title} subtitle={description} density="compact" headingLevel="h2" />

      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
        {metrics.map((metric) => (
          <MetricCard key={metric.label} density="compact" {...metric} />
        ))}
      </div>

      {toolbar ? <ReportToolbar density="compact" {...toolbar} /> : null}

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.15fr)_minmax(320px,0.85fr)]">
        <div className="grid content-start gap-4">
          <WorkflowPath compact {...workflow} />
          {table ? <div className="min-w-0">{table}</div> : null}
        </div>
        <div className="grid content-start gap-3">
          {state ? <StatePanel compact {...state} /> : null}
          <DecisionFeed compact {...decisions} />
        </div>
      </div>
    </section>
  );
}

export function EvidenceSummarySurface({
  title,
  description,
  summary,
  provenance,
  foot,
  facts,
  className,
}: EvidenceSummarySurfaceProps) {
  return (
    <section className={cn("grid gap-4", className)} aria-label={title}>
      <PageHeader title={title} subtitle={description} density="compact" headingLevel="h2" />
      <PublicSummaryStrip compact {...summary} />
      <div className={cn("grid gap-4", facts && "xl:grid-cols-[minmax(0,1fr)_360px]")}>
        <div className="grid min-w-0 content-start gap-3">
          <ProvenanceTable compact {...provenance} />
          <ProvenanceFoot {...foot} />
        </div>
        {facts ? <TrustFactsPanel {...facts} className={cn("max-w-none xl:max-w-[360px]", facts.className)} /> : null}
      </div>
    </section>
  );
}

export function ContentDigestSurface({
  title,
  description,
  filters,
  documents,
  assistant,
  emptyState = {
    title: "Материалы не найдены",
    message: "Измените фильтр или обновите источник.",
    tone: "neutral",
  },
  className,
}: ContentDigestSurfaceProps) {
  return (
    <section className={cn("grid gap-4", className)} aria-label={title}>
      <PageHeader title={title} subtitle={description} density="compact" headingLevel="h2" />
      {filters ? <FilterChipRow {...filters} /> : null}
      {documents.length ? (
        <div className="grid gap-3 lg:grid-cols-2">
          {documents.map((document) => (
            <DocumentCard key={`${document.eyebrow ?? "document"}-${document.title}`} {...document} />
          ))}
        </div>
      ) : (
        <StatePanel compact {...emptyState} />
      )}
      {assistant ? <InlineDocumentAssistantPanel {...assistant} className={cn("my-0", assistant.className)} /> : null}
    </section>
  );
}
