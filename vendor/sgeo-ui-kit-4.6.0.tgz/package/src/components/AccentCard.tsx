import { type CSSProperties, type ReactNode } from "react";
import { cn } from "../utils/cn";

/**
 * Карточка с тонкой акцентной линией для operational и summary-слоёв AV DS 4.
 * Варианты: primary, green, amber, red, neutral, none.
 */

export type AccentVariant = "primary" | "green" | "amber" | "red" | "neutral" | "none";

export interface AccentCardProps {
  /** Цвет акцент-линии */
  variant?: AccentVariant;
  /** Усиленная рамка акцента. Сохранено для обратной совместимости. */
  glow?: boolean;
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
  onClick?: () => void;
}

const accentClass: Record<AccentVariant, string> = {
  primary: "accent-line-primary",
  green: "accent-line-green",
  amber: "accent-line-amber",
  red: "accent-line-red",
  neutral: "accent-line-neutral",
  none: "",
};

const glowClass: Record<AccentVariant, string> = {
  primary: "card-glow-primary",
  green: "card-glow-green",
  amber: "card-glow-amber",
  red: "card-glow-red",
  neutral: "",
  none: "",
};

export function AccentCard({ variant = "none", glow = false, children, className, style, onClick }: AccentCardProps) {
  return (
    <div
      className={cn(
        "relative overflow-visible rounded-sm border border-border/80 bg-card p-4 transition-[border-color,background-color] duration-150 sm:p-5",
        variant !== "none" && accentClass[variant],
        glow && variant !== "none" && glowClass[variant],
        onClick &&
          "cursor-pointer hover:border-foreground/20 hover:bg-muted/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        className
      )}
      style={style}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onClick();
        }
      } : undefined}
    >
      {children}
    </div>
  );
}
