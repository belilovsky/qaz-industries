import React from "react";
import { Loader2 } from "lucide-react";
import { cn } from "../utils/cn";

export type PaginatedListStatus = "idle" | "loading" | "loading-more" | "error";

export interface PaginatedListProps<T> {
  items: T[];
  getItemId: (item: T, index: number) => string | number;
  renderItem: (item: T, index: number) => React.ReactNode;
  hasMore?: boolean;
  onLoadMore?: () => void;
  status?: PaginatedListStatus;
  ariaLabel?: string;
  emptyTitle?: string;
  emptyMessage?: string;
  errorTitle?: string;
  errorMessage?: string;
  loadMoreLabel?: string;
  loadingLabel?: string;
  endLabel?: string;
  totalLabel?: string;
  pageLabel?: string;
  compact?: boolean;
  className?: string;
  listClassName?: string;
  itemClassName?: string;
}

function uniqueItems<T>(
  items: T[],
  getItemId: (item: T, index: number) => string | number
) {
  const seen = new Set<string | number>();

  return items.filter((item, index) => {
    const id = getItemId(item, index);
    if (seen.has(id)) {
      return false;
    }
    seen.add(id);
    return true;
  });
}

export function PaginatedList<T>({
  items,
  getItemId,
  renderItem,
  hasMore = false,
  onLoadMore,
  status = "idle",
  ariaLabel = "Список с разбивкой на страницы",
  emptyTitle = "Нет данных",
  emptyMessage = "Список пуст или фильтр не вернул результатов.",
  errorTitle = "Не удалось загрузить список",
  errorMessage = "Повторите попытку или проверьте источник данных.",
  loadMoreLabel = "Загрузить ещё",
  loadingLabel = "Загрузка списка",
  endLabel = "Все элементы загружены",
  totalLabel,
  pageLabel,
  compact = false,
  className,
  listClassName,
  itemClassName,
}: PaginatedListProps<T>) {
  const dedupedItems = uniqueItems(items, getItemId);
  const isInitialLoading = status === "loading" && dedupedItems.length === 0;
  const isLoadingMore = status === "loading-more";
  const isError = status === "error";
  const canLoadMore = Boolean(hasMore && onLoadMore && !isInitialLoading && !isLoadingMore);

  return (
    <section
      className={cn("rounded-sm border border-border/80 bg-card", compact ? "p-3" : "p-4", className)}
      aria-label={ariaLabel}
    >
      {totalLabel || pageLabel ? (
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-border/70 pb-2">
          <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
            {totalLabel}
          </div>
          {pageLabel ? (
            <div className="text-[11px] text-muted-foreground">{pageLabel}</div>
          ) : null}
        </div>
      ) : null}

      <div aria-live="polite" className="sr-only">
        {isInitialLoading || isLoadingMore ? loadingLabel : `${dedupedItems.length} ${dedupedItems.length === 1 ? "элемент" : dedupedItems.length >= 2 && dedupedItems.length <= 4 ? "элемента" : "элементов"}`}
      </div>

      {isInitialLoading ? (
        <div className="flex min-h-24 items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span>{loadingLabel}</span>
        </div>
      ) : isError && dedupedItems.length === 0 ? (
        <div className="rounded-sm border border-destructive/30 bg-destructive/[0.035] px-3 py-3">
          <div className="text-sm font-semibold text-foreground">{errorTitle}</div>
          <div className="mt-1 text-sm leading-relaxed text-muted-foreground">{errorMessage}</div>
        </div>
      ) : dedupedItems.length === 0 ? (
        <div className="border-y border-border py-3">
          <div className="text-sm font-semibold text-foreground">{emptyTitle}</div>
          <div className="mt-1 text-sm leading-relaxed text-muted-foreground">{emptyMessage}</div>
        </div>
      ) : (
        <div className={cn("grid gap-2", listClassName)}>
          {dedupedItems.map((item, index) => (
            <div key={String(getItemId(item, index))} className={cn("min-w-0", itemClassName)}>
              {renderItem(item, index)}
            </div>
          ))}
        </div>
      )}

      {isError && dedupedItems.length > 0 ? (
        <div className="mt-3 rounded-sm border border-destructive/30 bg-destructive/[0.035] px-3 py-2.5 text-sm text-muted-foreground">
          {errorMessage}
        </div>
      ) : null}

      {dedupedItems.length > 0 ? (
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-border/70 pt-3">
          <div className="text-[11px] text-muted-foreground">
            {hasMore ? "Есть следующий фрагмент" : endLabel}
          </div>
          {hasMore ? (
            <button
              type="button"
              onClick={onLoadMore}
              disabled={!canLoadMore}
              className="inline-flex min-h-8 items-center gap-2 rounded-sm border border-border bg-background px-3 py-1 text-[12px] font-medium text-foreground transition-colors hover:bg-muted/40 disabled:cursor-not-allowed disabled:opacity-55 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
            >
              {isLoadingMore ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
              <span>{isLoadingMore ? loadingLabel : loadMoreLabel}</span>
            </button>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
