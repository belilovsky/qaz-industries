import React, { useId } from "react";
import { Search, X } from "lucide-react";
import { cn } from "../utils/cn";

export interface SearchFieldProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "size" | "value"> {
  value: string;
  onValueChange?: (value: string) => void;
  onClear?: () => void;
  label?: string;
  resultCount?: number;
  statusLabel?: string;
  clearLabel?: string;
  size?: "sm" | "md";
  className?: string;
  inputClassName?: string;
}

export function SearchField({
  value,
  onValueChange,
  onClear,
  label = "Поиск",
  placeholder = "Поиск",
  resultCount,
  statusLabel,
  clearLabel = "Очистить поиск",
  size = "md",
  className,
  inputClassName,
  id,
  ...inputProps
}: SearchFieldProps) {
  const generatedId = useId();
  const inputId = id ?? generatedId;
  const resolvedStatusLabel =
    statusLabel ?? (typeof resultCount === "number" ? `${resultCount} результатов` : undefined);

  return (
    <div className={cn("grid gap-1.5", className)}>
      <label
        htmlFor={inputId}
        className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground"
      >
        {label}
      </label>
      <div
        className={cn(
          "grid grid-cols-[auto_minmax(0,1fr)_auto] items-center rounded-sm border border-border bg-card transition-[border-color,box-shadow]",
          "focus-within:border-primary/50 focus-within:ring-2 focus-within:ring-primary/20",
          size === "sm" ? "min-h-8 px-2" : "min-h-10 px-2.5"
        )}
      >
        <Search className="me-2 h-4 w-4 text-muted-foreground" aria-hidden="true" />
        <input
          {...inputProps}
          id={inputId}
          value={value}
          onChange={(event) => onValueChange?.(event.currentTarget.value)}
          placeholder={placeholder}
          className={cn(
            "min-w-0 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/70",
            size === "sm" ? "h-7" : "h-9",
            inputClassName
          )}
          type="search"
        />
        {value ? (
          <button
            type="button"
            aria-label={clearLabel}
            onClick={() => {
              onClear?.();
              onValueChange?.("");
            }}
            className="inline-flex h-7 w-7 items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-muted/55 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        ) : (
          <span aria-hidden="true" className="h-7 w-7" />
        )}
      </div>
      {resolvedStatusLabel ? (
        <div className="text-[11px] leading-relaxed text-muted-foreground" aria-live="polite">
          {resolvedStatusLabel}
        </div>
      ) : null}
    </div>
  );
}
