import { cn } from "../utils/cn";
import { SourceHealthBadge, type SourceHealthStatus } from "./SourceHealthBadge";

export interface QazLakeOpsRun { id: string; label: string; status: SourceHealthStatus; observedAt?: string; detail?: string; evidence?: string; }
export interface QazLakeOpsListProps { title?: string; summary?: string; runs: QazLakeOpsRun[]; emptyMessage?: string; className?: string; }

/** A public-safe delivery list that makes not-observed states explicit. */
export function QazLakeOpsList({ title = "Запуски доставки данных", summary, runs, emptyMessage = "Запуски не включены в текущий публичный снимок.", className }: QazLakeOpsListProps) {
  return (
    <section className={cn("rounded-lg border border-border bg-card p-4 sm:p-5", className)} aria-label={title} data-testid="qazlake-ops-list">
      <header className="border-b border-border pb-4"><h3 className="text-base font-semibold text-foreground">{title}</h3>{summary ? <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{summary}</p> : null}</header>
      {runs.length ? <ul className="mt-3 divide-y divide-border" aria-label="Запуски QazLake">{runs.map((run) => <li key={run.id} className="flex flex-col gap-2 py-3 sm:flex-row sm:items-start sm:justify-between"><div className="min-w-0"><div className="text-sm font-medium text-foreground">{run.label}</div>{run.detail ? <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{run.detail}</p> : null}{run.observedAt || run.evidence ? <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{[run.observedAt, run.evidence].filter(Boolean).join(" · ")}</p> : null}</div><SourceHealthBadge status={run.status} /></li>)}</ul> : <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{emptyMessage}</p>}
    </section>
  );
}
