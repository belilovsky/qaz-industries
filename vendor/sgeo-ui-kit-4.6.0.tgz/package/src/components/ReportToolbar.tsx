import React, { useId } from "react";
import { cn } from "../utils/cn";

export type ReportToolbarDensity = "default" | "compact";

export interface ReportToolbarProps {
  title?: React.ReactNode;
  description?: React.ReactNode;
  controls?: React.ReactNode;
  actions?: React.ReactNode;
  summary?: React.ReactNode;
  ariaLabel?: string;
  density?: ReportToolbarDensity;
  className?: string;
}

/**
 * A responsive report control row. Data loading, export generation and filter
 * state remain owned by the consumer.
 */
export function ReportToolbar({
  title,
  description,
  controls,
  actions,
  summary,
  ariaLabel = "Управление отчётом",
  density = "default",
  className,
}: ReportToolbarProps) {
  const titleId = useId();
  const hasHeading = Boolean(title || description);

  return (
    <section
      aria-label={title ? undefined : ariaLabel}
      aria-labelledby={title ? titleId : undefined}
      data-density={density}
      className={cn(
        "border-y border-border/80 bg-card/55 px-3 sm:px-4",
        density === "compact" ? "py-2.5" : "py-3.5",
        className
      )}
    >
      {hasHeading ? (
        <div className={cn("min-w-0", controls ? "mb-3" : "mb-0")}>
          {title ? (
            <h2 id={titleId} className="text-sm font-semibold text-foreground">
              {title}
            </h2>
          ) : null}
          {description ? (
            <div className="mt-1 max-w-3xl text-[13px] leading-relaxed text-muted-foreground">
              {description}
            </div>
          ) : null}
        </div>
      ) : null}

      <div
        className={cn(
          "grid min-w-0 gap-3 lg:items-end",
          controls && (summary || actions) && "lg:grid-cols-[minmax(0,1fr)_auto]"
        )}
      >
        {controls ? (
          <div
            data-report-toolbar-controls
            className="flex min-w-0 flex-wrap items-end gap-2.5"
          >
            {controls}
          </div>
        ) : null}

        {summary || actions ? (
          <div className="flex min-w-0 flex-wrap items-center gap-2 lg:justify-end">
            {summary ? (
              <div
                data-report-toolbar-summary
                aria-live="polite"
                className="me-auto text-[12px] leading-relaxed text-muted-foreground lg:me-1"
              >
                {summary}
              </div>
            ) : null}
            {actions ? (
              <div
                data-report-toolbar-actions
                className="flex min-w-0 flex-wrap items-center gap-2"
              >
                {actions}
              </div>
            ) : null}
          </div>
        ) : null}
      </div>
    </section>
  );
}
