import { cn } from "../utils/cn";

/**
 * SVG-радиальный индикатор оценки (0–100).
 */

export interface RadialGaugeProps {
  /** Значение 0–100 */
  value: number;
  /** Размер в px */
  size?: number;
  /** Подпись под числом */
  label?: string;
  /** Цвет дуги (CSS color) */
  color?: string;
  /** Функция определения цвета по значению */
  getColor?: (value: number) => string;
  className?: string;
}

function defaultColor(v: number): string {
  if (v >= 70) return "hsl(var(--chart-2))";
  if (v >= 40) return "hsl(var(--chart-3))";
  return "hsl(var(--destructive))";
}

export function RadialGauge({ value, size = 200, label, color, getColor, className }: RadialGaugeProps) {
  const safeValue = Number.isFinite(value) ? value : 0;
  const pct = Math.min(Math.max(safeValue, 0), 100);
  const resolvedColor = color || (getColor || defaultColor)(pct);
  const strokeWidth = Math.max(6, Math.min(9, size * 0.055));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (pct / 100) * circumference;

  return (
    <div
      className={cn("relative isolate inline-flex items-center justify-center", className)}
      role="meter"
      aria-label={label ?? "Оценка"}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Number(pct.toFixed(1))}
      aria-valuetext={`${label ? `${label}: ` : ""}${pct.toFixed(1)} из 100`}
    >
      <svg width={size} height={size} className="-rotate-90" aria-hidden="true">
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none" stroke="currentColor" strokeWidth={strokeWidth}
          className="text-muted/30 dark:text-muted/20"
        />
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none" stroke={resolvedColor} strokeWidth={strokeWidth}
          strokeLinecap="butt"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{
            transition: "stroke-dashoffset 600ms cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        />
      </svg>
      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center">
        <span
          className="rounded-sm border-t-2 bg-background px-2 py-1 font-semibold leading-none text-foreground tabular-nums shadow-[0_0_0_1px_hsl(var(--border)/0.55)]"
          style={{ borderColor: resolvedColor, fontSize: Math.max(15, Math.min(34, size * 0.2)) }}
        >
          {pct.toFixed(1)}
        </span>
        {label && (
          <span
            className="mt-1 max-w-[72%] truncate rounded-sm bg-background px-1.5 py-0.5 text-center font-medium text-muted-foreground shadow-[0_0_0_1px_hsl(var(--border)/0.45)]"
            style={{ fontSize: Math.max(8, Math.min(11, size * 0.065)) }}
          >
            {label}
          </span>
        )}
      </div>
    </div>
  );
}
