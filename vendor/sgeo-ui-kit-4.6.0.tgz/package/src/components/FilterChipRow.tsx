import { cn } from "../utils/cn";

export interface FilterChipItem {
  value: string;
  label: string;
  count?: number | string;
  disabled?: boolean;
}

export interface FilterChipRowProps {
  chips: FilterChipItem[];
  value: string;
  onChange?: (value: string) => void;
  ariaLabel?: string;
  className?: string;
}

export function FilterChipRow({
  chips,
  value,
  onChange,
  ariaLabel = "Фильтры",
  className,
}: FilterChipRowProps) {
  return (
    <div className={cn("flex flex-wrap gap-2", className)} role="group" aria-label={ariaLabel}>
      {chips.map((chip) => {
        const isActive = chip.value === value;
        return (
          <button
            key={chip.value}
            type="button"
            aria-pressed={isActive}
            disabled={chip.disabled}
            data-filter-chip={chip.value}
            data-state={isActive ? "active" : "inactive"}
            onClick={() => onChange?.(chip.value)}
            className={cn(
              "inline-flex min-h-8 items-center gap-1.5 rounded-sm border px-2.5 py-1 text-[12px] font-medium transition-[background-color,border-color,color] duration-150",
              "border-border bg-card text-muted-foreground",
              "hover:border-border hover:bg-muted/40 hover:text-foreground",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
              isActive && "border-primary/45 bg-primary/[0.06] text-primary",
              chip.disabled && "cursor-not-allowed opacity-55"
            )}
          >
            <span>{chip.label}</span>
            {chip.count !== undefined ? (
              <span className={cn("text-[10px] font-semibold tabular-nums", isActive ? "text-primary" : "text-foreground/75")}>({chip.count})</span>
            ) : null}
          </button>
        );
      })}
    </div>
  );
}
