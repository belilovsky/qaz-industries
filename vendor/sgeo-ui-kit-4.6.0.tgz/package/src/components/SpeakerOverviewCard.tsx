import { cn } from "../utils/cn";

export interface SpeakerOverviewMetric {
  label: string;
  value: string | number;
}

export interface SpeakerOverviewLink {
  label: string;
  href: string;
  ariaLabel?: string;
}

export interface SpeakerOverviewCardProps {
  eyebrow?: string;
  title: string;
  href: string;
  period?: string;
  summary?: string;
  metrics?: SpeakerOverviewMetric[];
  latestLabel?: string;
  latestTitle?: string;
  latestHref?: string;
  latestMeta?: string;
  links?: SpeakerOverviewLink[];
  ctaLabel?: string;
  className?: string;
}

export function SpeakerOverviewCard({
  eyebrow,
  title,
  href,
  period,
  summary,
  metrics = [],
  latestLabel = "Последний материал",
  latestTitle,
  latestHref,
  latestMeta,
  links = [],
  ctaLabel = "Открыть корпус",
  className,
}: SpeakerOverviewCardProps) {
  const latestResolvedHref = latestHref || href;

  return (
    <article
      className={cn(
        "rounded-sm border border-border/80 bg-card px-5 py-5 transition-[border-color,background-color] duration-150 hover:border-foreground/20 hover:bg-muted/15",
        className
      )}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          {eyebrow ? (
            <div className="text-[11px] font-semibold uppercase tracking-[0.09em] text-primary/78">{eyebrow}</div>
          ) : null}
          {period ? <div className="mt-1 text-sm text-muted-foreground">{period}</div> : null}
        </div>
        <a
          href={href}
          aria-label={`Открыть ${title}`}
          className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-border bg-background/80 text-base text-primary no-underline transition-colors hover:border-primary/30 hover:bg-primary/5"
        >
          <span aria-hidden="true">→</span>
        </a>
      </div>

      <h3 className="mt-4 text-xl font-semibold leading-tight text-foreground">
        <a href={href} className="no-underline hover:text-primary">
          {title}
        </a>
      </h3>

      {summary ? <p className="mt-2 text-sm leading-[1.6] text-muted-foreground">{summary}</p> : null}

      {metrics.length ? (
        <dl className="mt-4 flex flex-wrap gap-2.5">
          {metrics.map((metric, index) => (
            <div
              key={`${metric.label}-${index}`}
              className="rounded-full border border-border bg-background/72 px-3 py-1.5"
            >
              <dt className="sr-only">{metric.label}</dt>
              <dd className="flex items-baseline gap-1.5 text-[13px]">
                <strong className="font-semibold text-foreground tabular-nums">{metric.value}</strong>
                <span className="text-muted-foreground">{metric.label}</span>
              </dd>
            </div>
          ))}
        </dl>
      ) : null}

      {latestTitle ? (
        <div className="mt-4 border-y border-border/70 bg-muted/20 px-3 py-3">
          <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">{latestLabel}</div>
          <div className="mt-1.5 text-sm font-semibold leading-snug text-foreground">
            <a href={latestResolvedHref} className="no-underline hover:text-primary">
              {latestTitle}
            </a>
          </div>
          {latestMeta ? <div className="mt-1 text-xs text-muted-foreground">{latestMeta}</div> : null}
        </div>
      ) : null}

      {links.length ? (
        <div className="mt-4 flex flex-wrap gap-2.5">
          {links.map((link, index) => (
            <a
              key={`${link.label}-${index}`}
              href={link.href}
              aria-label={link.ariaLabel}
              className="text-[13px] font-medium text-primary underline-offset-4 hover:underline"
            >
              {link.label}
            </a>
          ))}
        </div>
      ) : null}

      <div className="mt-5">
        <a
          href={href}
          className="inline-flex items-center gap-2 text-sm font-semibold text-foreground no-underline transition-colors hover:text-primary"
        >
          <span>{ctaLabel}</span>
          <span aria-hidden="true">→</span>
        </a>
      </div>
    </article>
  );
}
