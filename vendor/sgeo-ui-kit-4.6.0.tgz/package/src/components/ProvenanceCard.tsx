import { cn } from "../utils/cn";
import { SourcePolicyBadge, type SourcePolicyKind } from "./SourcePolicyBadge";
import { createSoftToneStyles } from "../utils/toneStyles";

/**
 * Компактный блок происхождения данных для фактов, цитат и источников.
 */

export type ProvenanceStatus = "idle" | "draft" | "verified" | "needs_review" | "stale";

export interface ProvenanceItem {
  label: string;
  value?: string;
  note?: string;
  source?: string;
  href?: string;
  confidence?: number | string;
}

export interface ProvenanceCardProps {
  title?: string;
  summary?: string;
  status?: ProvenanceStatus;
  policy?: SourcePolicyKind;
  statusLabels?: Partial<Record<ProvenanceStatus, string>>;
  items: ProvenanceItem[];
  className?: string;
}

const statusLabel: Record<ProvenanceStatus, string> = {
  idle: "Ожидание",
  draft: "Черновик",
  verified: "Проверено",
  needs_review: "Нужна проверка",
  stale: "Устарело",
};

const statusTone: Record<ProvenanceStatus, string> = {
  idle: "hsl(var(--muted-foreground))",
  draft: "hsl(var(--primary))",
  verified: "hsl(var(--chart-2))",
  needs_review: "hsl(var(--chart-3))",
  stale: "hsl(var(--muted-foreground))",
};

export function ProvenanceCard({
  title = "Происхождение данных",
  summary,
  status = "needs_review",
  policy,
  statusLabels,
  items,
  className,
}: ProvenanceCardProps) {
  const resolvedStatusLabels = { ...statusLabel, ...statusLabels };
  const statusStyles = createSoftToneStyles(statusTone[status]);

  return (
    <section className={cn("rounded-sm border border-border bg-card p-5", className)}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold text-foreground">{title}</h3>
          {summary ? <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{summary}</p> : null}
        </div>
        <div className="flex flex-wrap gap-2">
          <span
            className="inline-flex rounded-full border px-2 py-0.5 text-[11px] font-medium"
            style={statusStyles.wrapper}
          >
            {resolvedStatusLabels[status]}
          </span>
          {policy ? <SourcePolicyBadge policy={policy} /> : null}
        </div>
      </div>

      <div className="mt-4 divide-y divide-border/60">
        {items.map((item, index) => (
          <div key={`${item.label}-${index}`} className="grid gap-2 py-3 text-sm sm:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)_auto]">
            <div className="font-medium text-foreground">{item.label}</div>
            <div className="min-w-0 text-muted-foreground">
              {item.href ? (
                <a className="block max-w-full truncate text-primary hover:underline" href={item.href}>
                  {item.value || item.source || item.href}
                </a>
              ) : (
                item.value || item.source || "–"
              )}
              {item.note ? <div className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{item.note}</div> : null}
              {item.source ? <div className="mt-0.5 truncate font-mono text-[11px]">{item.source}</div> : null}
            </div>
            <div className="text-end font-mono text-[11px] text-muted-foreground">{item.confidence ?? "–"}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
