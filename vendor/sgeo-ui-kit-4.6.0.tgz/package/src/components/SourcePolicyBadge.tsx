import { cn } from "../utils/cn";
import { createSoftToneStyles } from "../utils/toneStyles";

/**
 * Метка правил повторного использования источника: yes/attribution/share_alike/review/no.
 */

export type SourcePolicyKind = "yes" | "attribution" | "share_alike" | "review" | "no";

export interface SourcePolicyBadgeProps {
  policy: SourcePolicyKind;
  /** Текст (по умолчанию – короткая метка политики) */
  label?: string;
  size?: "sm" | "md";
  className?: string;
}

const policyConfig: Record<SourcePolicyKind, { accent: string; label: string }> = {
  yes: {
    accent: "hsl(var(--chart-2))",
    label: "Можно",
  },
  attribution: {
    accent: "hsl(var(--primary))",
    label: "Указать источник",
  },
  share_alike: {
    accent: "hsl(var(--chart-4))",
    label: "На тех же условиях",
  },
  review: {
    accent: "hsl(var(--chart-3))",
    label: "Проверка",
  },
  no: {
    accent: "hsl(var(--destructive))",
    label: "Нельзя",
  },
};

export function SourcePolicyBadge({ policy, label, size = "sm", className }: SourcePolicyBadgeProps) {
  const cfg = policyConfig[policy] ?? policyConfig.review;
  const toneStyles = createSoftToneStyles(cfg.accent);

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium tracking-[0.01em]",
        size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs",
        className
      )}
      style={toneStyles.wrapper}
    >
      <span aria-hidden="true" className="h-1.5 w-1.5 flex-shrink-0 rounded-full" style={toneStyles.dot} />
      {label ?? cfg.label}
    </span>
  );
}
