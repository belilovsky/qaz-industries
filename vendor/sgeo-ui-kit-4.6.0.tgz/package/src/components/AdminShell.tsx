import React, { useId } from "react";
import { cn } from "../utils/cn";

export interface AdminNavItem {
  id: string;
  label: string;
  href?: string;
  icon?: React.ReactNode;
  badge?: React.ReactNode;
  active?: boolean;
  disabled?: boolean;
  onSelect?: () => void;
}

export interface AdminShellProps {
  brand: React.ReactNode;
  productLabel?: React.ReactNode;
  navigation: AdminNavItem[];
  children: React.ReactNode;
  account?: React.ReactNode;
  actions?: React.ReactNode;
  footer?: React.ReactNode;
  navigationLabel?: string;
  className?: string;
}

function AdminNavLink({ item, compact = false }: { item: AdminNavItem; compact?: boolean }) {
  const classes = cn(
    "flex min-h-9 items-center gap-2 border-s-2 px-3 py-2 text-[13px] font-medium transition-colors",
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary/35",
    item.active
      ? "border-primary bg-primary/[0.07] text-foreground"
      : "border-transparent text-muted-foreground hover:bg-muted/45 hover:text-foreground",
    item.disabled && "pointer-events-none opacity-45",
    compact && "shrink-0 border-s-0 border-b-2 px-2.5 py-2"
  );
  const content = (
    <>
      {item.icon ? <span className="shrink-0 text-muted-foreground" aria-hidden="true">{item.icon}</span> : null}
      <span className="truncate">{item.label}</span>
      {item.badge ? (
        <span className={cn("ms-auto shrink-0 text-[11px] tabular-nums", item.active ? "text-foreground/75" : "text-muted-foreground")}>
          {item.badge}
        </span>
      ) : null}
    </>
  );

  if (item.href) {
    return (
      <a
        href={item.href}
        aria-current={item.active ? "page" : undefined}
        aria-disabled={item.disabled || undefined}
        tabIndex={item.disabled ? -1 : undefined}
        className={classes}
        onClick={(event) => {
          if (item.disabled) {
            event.preventDefault();
            return;
          }
          item.onSelect?.();
        }}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      type="button"
      disabled={item.disabled}
      aria-current={item.active ? "page" : undefined}
      className={cn(classes, "w-full text-start")}
      onClick={item.onSelect}
    >
      {content}
    </button>
  );
}

/**
 * Framework-neutral admin layout. Routing, authorization and data loading stay
 * with the consumer; the shell only standardizes hierarchy and responsive flow.
 */
export function AdminShell({
  brand,
  productLabel,
  navigation,
  children,
  account,
  actions,
  footer,
  navigationLabel = "Разделы администрирования",
  className,
}: AdminShellProps) {
  return (
    <div className={cn("avds-admin-shell min-h-[32rem] border border-border/80 bg-background text-foreground", className)}>
      <header className="avds-admin-topbar flex min-h-12 items-center gap-3 border-b border-border/80 px-3 sm:px-4">
        <div className="min-w-0 font-semibold">{brand}</div>
        {productLabel ? <div className="hidden min-w-0 truncate border-s border-border ps-3 text-[12px] text-muted-foreground sm:block">{productLabel}</div> : null}
        <div className="ms-auto flex min-w-0 items-center gap-2">
          {actions ? <div className="hidden items-center gap-2 sm:flex">{actions}</div> : null}
          {account ? <div className="min-w-0">{account}</div> : null}
        </div>
      </header>

      <nav aria-label={navigationLabel} className="avds-admin-mobile-nav overflow-x-auto border-b border-border/80 md:hidden">
        <div className="flex min-w-max px-1">
          {navigation.map((item) => <AdminNavLink key={item.id} item={item} compact />)}
        </div>
      </nav>

      <div className="grid min-w-0 md:grid-cols-[13.5rem_minmax(0,1fr)]">
        <aside className="avds-admin-sidebar hidden min-h-[29rem] border-e border-border/80 bg-muted/[0.14] md:flex md:flex-col">
          <nav aria-label={navigationLabel} className="grid gap-0.5 p-2">
            {navigation.map((item) => <AdminNavLink key={item.id} item={item} />)}
          </nav>
          {footer ? <div className="mt-auto border-t border-border/80 p-3 text-[11px] leading-relaxed text-muted-foreground">{footer}</div> : null}
        </aside>
        <main className="avds-admin-main min-w-0 p-3 sm:p-4 lg:p-5">{children}</main>
      </div>
    </div>
  );
}

export interface AdminLoginShellProps {
  brand: React.ReactNode;
  title: React.ReactNode;
  description?: React.ReactNode;
  children: React.ReactNode;
  footer?: React.ReactNode;
  className?: string;
}

export function AdminLoginShell({ brand, title, description, children, footer, className }: AdminLoginShellProps) {
  const titleId = useId();

  return (
    <section
      aria-labelledby={titleId}
      className={cn("avds-admin-login-shell grid min-h-[32rem] place-items-center border border-border/80 bg-muted/[0.16] p-4", className)}
    >
      <div className="w-full max-w-sm border border-border/85 bg-background p-5 shadow-[0_10px_30px_hsl(var(--foreground)/0.07)] sm:p-6">
        <div className="mb-6 text-[13px] font-semibold text-foreground">{brand}</div>
        <h2 id={titleId} className="text-xl font-semibold text-foreground">{title}</h2>
        {description ? <div className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{description}</div> : null}
        <div className="mt-5">{children}</div>
        {footer ? <div className="mt-5 border-t border-border/75 pt-4 text-[11px] leading-relaxed text-muted-foreground">{footer}</div> : null}
      </div>
    </section>
  );
}
