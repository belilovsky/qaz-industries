import React from "react";
import { cn } from "../utils/cn";

export type ChartInsightTone = "neutral" | "accent" | "positive" | "warning" | "critical";

export interface ChartInsightItem {
  label: React.ReactNode;
  value: React.ReactNode;
  note?: React.ReactNode;
  tone?: ChartInsightTone;
  color?: string;
}

export interface ChartInsightTooltipProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "title"> {
  label?: React.ReactNode;
  title?: React.ReactNode;
  items: ChartInsightItem[];
  footer?: React.ReactNode;
  compact?: boolean;
}

const valueToneClassNames: Record<ChartInsightTone, string> = {
  neutral: "text-foreground",
  accent: "text-primary",
  positive: "text-foreground",
  warning: "text-foreground",
  critical: "text-destructive",
};

/** Chart-library-independent content for hover, focus and keyboard summaries. */
export function ChartInsightTooltip({
  label,
  title,
  items,
  footer,
  compact = false,
  className,
  ...props
}: ChartInsightTooltipProps) {
  return (
    <div
      {...props}
      role="tooltip"
      className={cn(
        "min-w-44 max-w-[min(20rem,calc(100vw-2rem))] rounded-sm border border-border bg-popover text-popover-foreground shadow-lg shadow-black/10",
        compact ? "p-2.5" : "p-3",
        className
      )}
    >
      {label ? <div className="text-[11px] font-medium text-muted-foreground">{label}</div> : null}
      {title ? <div className={cn("text-sm font-semibold text-foreground", label ? "mt-1" : "")}>{title}</div> : null}

      <dl className={cn("grid gap-2", label || title ? "mt-2.5" : "")}>
        {items.map((item, index) => (
          <div
            key={`${String(item.label)}-${index}`}
            className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-x-4 gap-y-0.5"
          >
            <dt className="flex min-w-0 items-center gap-2 text-[12px] text-muted-foreground">
              {item.color ? (
                <span
                  aria-hidden="true"
                  className="h-1.5 w-1.5 shrink-0 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
              ) : null}
              <span className="min-w-0 truncate">{item.label}</span>
            </dt>
            <dd
              className={cn(
                "m-0 text-end text-[13px] font-semibold tabular-nums",
                valueToneClassNames[item.tone ?? "neutral"]
              )}
            >
              {item.value}
            </dd>
            {item.note ? (
              <dd className="col-span-2 m-0 text-[11px] leading-relaxed text-muted-foreground/85">
                {item.note}
              </dd>
            ) : null}
          </div>
        ))}
      </dl>

      {footer ? (
        <div className="mt-2.5 border-t border-border/70 pt-2 text-[11px] leading-relaxed text-muted-foreground">
          {footer}
        </div>
      ) : null}
    </div>
  );
}
