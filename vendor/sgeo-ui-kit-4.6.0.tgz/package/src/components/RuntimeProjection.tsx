import { cn } from "../utils/cn";
import { SourceHealthBadge, type SourceHealthStatus } from "./SourceHealthBadge";

export interface RuntimeProjectionItem { id: string; capability: string; claimed: string; observed: string; publicProof: string; status: SourceHealthStatus; }
export interface RuntimeProjectionProps { title?: string; summary?: string; items: RuntimeProjectionItem[]; className?: string; }

/** Разделяет заявленные свойства, наблюдение в рабочей среде и публичное подтверждение. */
export function RuntimeProjection({ title = "Состояние рабочей среды", summary, items, className }: RuntimeProjectionProps) {
  return (
    <section className={cn("rounded-lg border border-border bg-card p-4 sm:p-5", className)} aria-label={title} data-testid="runtime-projection">
      <header className="border-b border-border pb-4"><h3 className="text-base font-semibold text-foreground">{title}</h3>{summary ? <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{summary}</p> : null}</header>
    <ul className="mt-3 divide-y divide-border" aria-label="Состояния рабочей среды">{items.map((item) => <li key={item.id} className="py-3"><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div className="text-sm font-medium text-foreground">{item.capability}</div><SourceHealthBadge status={item.status} /></div><dl className="mt-2 grid gap-2 text-xs sm:grid-cols-3"><div><dt className="text-muted-foreground">Заявлено</dt><dd className="mt-0.5 leading-relaxed text-foreground">{item.claimed}</dd></div><div><dt className="text-muted-foreground">Наблюдается</dt><dd className="mt-0.5 leading-relaxed text-foreground">{item.observed}</dd></div><div><dt className="text-muted-foreground">Публичное подтверждение</dt><dd className="mt-0.5 leading-relaxed text-foreground">{item.publicProof}</dd></div></dl></li>)}</ul>
    </section>
  );
}
