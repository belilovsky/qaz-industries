import React from "react";
import { cn } from "../utils/cn";
import { CollectorRun, type CollectorRunProps } from "./CollectorRun";
import { DataFreshness, type DataFreshnessProps } from "./DataFreshness";
import { DecisionFeed, type DecisionFeedProps } from "./DecisionFeed";
import { EvidenceTrail, type EvidenceTrailProps } from "./EvidenceTrail";
import { FilterChipRow, type FilterChipRowProps } from "./FilterChipRow";
import { MetricCard, type MetricCardProps } from "./MetricCard";
import { PageHeader } from "./PageHeader";
import { ProvenanceFoot, type ProvenanceFootProps } from "./ProvenanceFoot";
import { PublicSummaryStrip, type PublicSummaryStripProps } from "./PublicSummaryStrip";
import { QuickLinksRail, type QuickLinksRailProps } from "./QuickLinksRail";
import { RangeWithFlags, type RangeWithFlagsProps } from "./RangeWithFlags";
import { ReportToolbar, type ReportToolbarProps } from "./ReportToolbar";
import { ServiceStatusCard, type ServiceStatusCardProps } from "./ServiceStatusCard";
import { StatePanel, type StatePanelProps } from "./StatePanel";
import { WorkflowPath, type WorkflowPathProps } from "./WorkflowPath";

export interface AdminWorkspaceSurfaceProps {
  title: string;
  description?: string;
  toolbar?: ReportToolbarProps;
  metrics?: MetricCardProps[];
  primary: React.ReactNode;
  secondary?: React.ReactNode;
  state?: StatePanelProps;
  className?: string;
}

export interface GeoEvidenceSurfaceProps {
  title: string;
  description?: string;
  summary?: PublicSummaryStripProps;
  map: React.ReactNode;
  range: RangeWithFlagsProps;
  evidence?: EvidenceTrailProps;
  foot?: ProvenanceFootProps;
  className?: string;
}

export interface MediaMonitoringSurfaceProps {
  title: string;
  description?: string;
  toolbar?: ReportToolbarProps;
  filters?: FilterChipRowProps;
  freshness?: DataFreshnessProps;
  primary: React.ReactNode;
  collectors?: CollectorRunProps[];
  decisions?: DecisionFeedProps;
  className?: string;
}

export interface IncidentResponseSurfaceProps {
  title: string;
  description?: string;
  services: ServiceStatusCardProps[];
  workflow: WorkflowPathProps;
  decisions: DecisionFeedProps;
  state?: StatePanelProps;
  className?: string;
}

export interface PublicExplainerSurfaceProps {
  title: string;
  description?: string;
  summary: PublicSummaryStripProps;
  lead: React.ReactNode;
  links?: QuickLinksRailProps;
  foot?: ProvenanceFootProps;
  className?: string;
}

export function AdminWorkspaceSurface({
  title,
  description,
  toolbar,
  metrics = [],
  primary,
  secondary,
  state,
  className,
}: AdminWorkspaceSurfaceProps) {
  return (
    <section className={cn("grid gap-4", className)} aria-label={title}>
      <PageHeader title={title} subtitle={description} density="compact" headingLevel="h2" />
      {metrics.length ? (
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
          {metrics.map((metric) => <MetricCard key={metric.label} density="compact" {...metric} />)}
        </div>
      ) : null}
      {toolbar ? <ReportToolbar density="compact" {...toolbar} /> : null}
      <div className={cn("grid min-w-0 gap-4", (secondary || state) && "xl:grid-cols-[minmax(0,1fr)_minmax(280px,0.42fr)]")}>
        <div className="min-w-0">{primary}</div>
        {secondary || state ? (
          <aside className="grid content-start gap-3">
            {state ? <StatePanel compact {...state} /> : null}
            {secondary}
          </aside>
        ) : null}
      </div>
    </section>
  );
}

export function GeoEvidenceSurface({
  title,
  description,
  summary,
  map,
  range,
  evidence,
  foot,
  className,
}: GeoEvidenceSurfaceProps) {
  return (
    <section className={cn("grid gap-4", className)} aria-label={title}>
      <PageHeader title={title} subtitle={description} density="compact" headingLevel="h2" />
      {summary ? <PublicSummaryStrip compact {...summary} /> : null}
      <div className="grid min-w-0 gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(300px,0.4fr)]">
        <div className="min-w-0">{map}</div>
        <aside className="grid content-start gap-3">
          <RangeWithFlags {...range} />
          {evidence ? <EvidenceTrail compact {...evidence} /> : null}
          {foot ? <ProvenanceFoot {...foot} /> : null}
        </aside>
      </div>
    </section>
  );
}

export function MediaMonitoringSurface({
  title,
  description,
  toolbar,
  filters,
  freshness,
  primary,
  collectors = [],
  decisions,
  className,
}: MediaMonitoringSurfaceProps) {
  return (
    <section className={cn("grid gap-4", className)} aria-label={title}>
      <PageHeader
        title={title}
        subtitle={description}
        density="compact"
        headingLevel="h2"
        meta={freshness ? <DataFreshness appearance="badge" {...freshness} /> : undefined}
      />
      {toolbar ? <ReportToolbar density="compact" {...toolbar} /> : null}
      {filters ? <FilterChipRow {...filters} /> : null}
      <div className={cn("grid min-w-0 gap-4", (collectors.length || decisions) && "xl:grid-cols-[minmax(0,1fr)_minmax(300px,0.42fr)]")}>
        <div className="min-w-0">{primary}</div>
        {collectors.length || decisions ? (
          <aside className="grid content-start gap-3">
            {collectors.map((collector) => <CollectorRun key={collector.name} {...collector} />)}
            {decisions ? <DecisionFeed compact {...decisions} /> : null}
          </aside>
        ) : null}
      </div>
    </section>
  );
}

export function IncidentResponseSurface({
  title,
  description,
  services,
  workflow,
  decisions,
  state,
  className,
}: IncidentResponseSurfaceProps) {
  return (
    <section className={cn("grid gap-4", className)} aria-label={title}>
      <PageHeader title={title} subtitle={description} density="compact" headingLevel="h2" />
      {state ? <StatePanel compact {...state} /> : null}
      <div className="grid gap-3 lg:grid-cols-2">{services.map((service) => <ServiceStatusCard key={service.title} {...service} />)}</div>
      <WorkflowPath compact {...workflow} />
      <DecisionFeed compact {...decisions} />
    </section>
  );
}

export function PublicExplainerSurface({
  title,
  description,
  summary,
  lead,
  links,
  foot,
  className,
}: PublicExplainerSurfaceProps) {
  return (
    <section className={cn("grid gap-4", className)} aria-label={title}>
      <PageHeader title={title} subtitle={description} density="compact" headingLevel="h2" />
      <PublicSummaryStrip compact {...summary} />
      <div className="min-w-0">{lead}</div>
      {links ? <QuickLinksRail {...links} /> : null}
      {foot ? <ProvenanceFoot {...foot} /> : null}
    </section>
  );
}
