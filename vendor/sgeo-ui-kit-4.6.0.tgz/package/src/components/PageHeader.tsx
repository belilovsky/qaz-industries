import React from "react";
import { cn } from "../utils/cn";

/**
 * Заголовок страницы – title + subtitle + слот для действий.
 */

export interface PageHeaderProps {
  /** Верхняя поясняющая метка */
  eyebrow?: React.ReactNode;
  /** Заголовок */
  title: string;
  /** Подзаголовок */
  subtitle?: string;
  /** Дополнительный meta-слой под заголовком */
  meta?: React.ReactNode;
  /** Иконка (lucide-react компонент) */
  icon?: React.ReactNode;
  /** Слот для кнопок/действий справа */
  children?: React.ReactNode;
  /** Визуальный тон header */
  tone?: "default" | "accent";
  /** Плотность вертикального ритма */
  density?: "default" | "compact";
  /** Уровень заголовка для вложенных поверхностей */
  headingLevel?: "h1" | "h2";
  className?: string;
}

export function PageHeader({
  eyebrow,
  title,
  subtitle,
  meta,
  icon,
  children,
  tone = "default",
  density = "default",
  headingLevel = "h1",
  className,
}: PageHeaderProps) {
  const isCompact = density === "compact";
  const Heading = headingLevel;

  return (
    <div
      className={cn(
        "flex flex-col items-start border-b border-border/70 pb-3 sm:flex-row sm:flex-wrap sm:items-start sm:justify-between",
        isCompact ? "gap-3 sm:gap-4" : "gap-4 sm:gap-6",
        tone === "accent" && "border-b border-primary/30 pb-4",
        className
      )}
    >
      <div className={cn("flex min-w-0 items-start", isCompact ? "gap-3" : "gap-3 md:gap-4")}>
        {icon && (
          <div
            className={cn(
              "flex shrink-0 items-center justify-center rounded-sm border border-border/70 bg-card/55 text-muted-foreground",
              isCompact ? "h-8 w-8" : "h-9 w-9 md:h-10 md:w-10"
            )}
          >
            {icon}
          </div>
        )}
        <div className="min-w-0 max-w-3xl">
          {eyebrow ? (
            <div className="mb-2 text-[10px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
              {eyebrow}
            </div>
          ) : null}
          <Heading
            className={cn(
              "break-words font-semibold leading-[1.08] text-foreground",
              isCompact ? "text-[1.25rem] md:text-[1.75rem]" : "text-[1.42rem] md:text-[2rem]"
            )}
            style={{ fontFamily: "var(--font-display)" }}
          >
            {title}
          </Heading>
          {subtitle && (
            <p
              className={cn(
                "max-w-[44rem] text-muted-foreground",
                isCompact
                  ? "mt-1 text-[13px] leading-[1.52] md:text-[14px]"
                  : "mt-1.5 text-[13.5px] leading-[1.56] md:mt-2 md:text-[15px] md:leading-[1.58]"
              )}
            >
              {subtitle}
            </p>
          )}
          {meta ? (
            <div className={cn("flex flex-wrap items-center gap-2", isCompact ? "mt-2" : "mt-3")}>{meta}</div>
          ) : null}
        </div>
      </div>
      {children && (
        <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto sm:justify-end">{children}</div>
      )}
    </div>
  );
}
