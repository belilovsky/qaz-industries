import { cn } from "../utils/cn";
import { createSoftToneStyles } from "../utils/toneStyles";

export type DataFreshnessState = "fresh" | "aging" | "stale" | "unknown";

export interface DataFreshnessProps {
  timestamp?: string | number | Date | null;
  now?: string | number | Date;
  freshForMinutes?: number;
  staleAfterMinutes?: number;
  label?: string;
  state?: DataFreshnessState;
  locale?: string;
  appearance?: "badge" | "plain";
  className?: string;
}

const stateConfig: Record<DataFreshnessState, { accent: string; label: string }> = {
  fresh: { accent: "hsl(var(--chart-2))", label: "Свежие данные" },
  aging: { accent: "hsl(var(--chart-3))", label: "Нужно обновление" },
  stale: { accent: "hsl(var(--destructive))", label: "Данные устарели" },
  unknown: { accent: "hsl(var(--muted-foreground))", label: "Свежесть неизвестна" },
};

function toMillis(value: string | number | Date | null | undefined) {
  if (value == null) return null;
  const milliseconds = value instanceof Date ? value.getTime() : new Date(value).getTime();
  return Number.isFinite(milliseconds) ? milliseconds : null;
}

export function getDataFreshnessState(
  timestamp: DataFreshnessProps["timestamp"],
  options?: Pick<DataFreshnessProps, "now" | "freshForMinutes" | "staleAfterMinutes">
): DataFreshnessState {
  const observedAt = toMillis(timestamp);
  const comparedAt = toMillis(options?.now ?? Date.now());
  if (observedAt == null || comparedAt == null) return "unknown";
  const ageMinutes = Math.max(0, (comparedAt - observedAt) / 60_000);
  const freshForMinutes = Math.max(0, options?.freshForMinutes ?? 60);
  const staleAfterMinutes = Math.max(freshForMinutes, options?.staleAfterMinutes ?? 240);
  if (ageMinutes <= freshForMinutes) return "fresh";
  if (ageMinutes < staleAfterMinutes) return "aging";
  return "stale";
}

function formatAge(timestamp: DataFreshnessProps["timestamp"], now: DataFreshnessProps["now"], locale: string) {
  const observedAt = toMillis(timestamp);
  const comparedAt = toMillis(now ?? Date.now());
  if (observedAt == null || comparedAt == null) return "время не указано";
  const minutes = Math.max(0, Math.round((comparedAt - observedAt) / 60_000));
  const formatter = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  if (minutes < 60) return formatter.format(-minutes, "minute");
  const hours = Math.round(minutes / 60);
  if (hours < 48) return formatter.format(-hours, "hour");
  return formatter.format(-Math.round(hours / 24), "day");
}

export function DataFreshness({
  timestamp,
  now,
  freshForMinutes = 60,
  staleAfterMinutes = 240,
  label,
  state,
  locale = "ru",
  appearance = "badge",
  className,
}: DataFreshnessProps) {
  const resolvedState = state ?? getDataFreshnessState(timestamp, { now, freshForMinutes, staleAfterMinutes });
  const config = stateConfig[resolvedState];
  const styles = createSoftToneStyles(config.accent);

  return (
    <span
      className={cn(
        "inline-flex min-w-0 items-center gap-2 text-[11px]",
        appearance === "badge" && "rounded-sm border px-2.5 py-1",
        className
      )}
      data-freshness={resolvedState}
      style={appearance === "badge" ? styles.wrapper : undefined}
    >
      <span className="h-1.5 w-1.5 shrink-0 rounded-full" aria-hidden="true" style={styles.dot} />
      <span className="font-medium text-foreground">{label ?? config.label}</span>
      <span className="text-foreground/80">{formatAge(timestamp, now, locale)}</span>
    </span>
  );
}
