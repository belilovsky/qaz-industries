import { CheckCircle2, CircleAlert, ExternalLink } from "lucide-react";
import { cn } from "../utils/cn";
import { SourceHealthBadge, type SourceHealthStatus } from "./SourceHealthBadge";

export interface LiveLinkReleaseCheck { label: string; href?: string; detail?: string; status: SourceHealthStatus; statusLabel?: string; }
export interface LiveLinkReleaseGateProps { title?: string; summary?: string; checks: LiveLinkReleaseCheck[]; className?: string; }

/** A read-only gate: evidence about a release, never an automatic release control. */
export function LiveLinkReleaseGate({ title = "Публичная проверка выпуска", summary, checks, className }: LiveLinkReleaseGateProps) {
  const failed = checks.filter((check) => check.status === "red").length;
  const pending = checks.filter((check) => ["yellow", "disabled", "unconfigured"].includes(check.status)).length;
  const tone: SourceHealthStatus = failed ? "red" : pending ? "yellow" : "green";
  const verdict = failed ? "Выпуск требует исправления" : pending ? "Выпуск требует ручной проверки" : "Публичные проверки пройдены";
  const Icon = failed ? CircleAlert : CheckCircle2;
  return (
    <section className={cn("rounded-lg border border-border bg-card p-4 sm:p-5", className)} aria-label={title}>
      <header className="flex flex-col gap-3 border-b border-border pb-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0"><h3 className="text-base font-semibold text-foreground">{title}</h3>{summary ? <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{summary}</p> : null}</div>
        <SourceHealthBadge status={tone} label={verdict} size="md" />
      </header>
      <div className="mt-4 flex items-center gap-2 text-sm font-medium text-foreground"><Icon className="h-4 w-4" aria-hidden="true" />{checks.length - failed - pending}/{checks.length} подтверждено автоматически</div>
      <ul className="mt-3 divide-y divide-border border-y border-border">{checks.map((check, index) => <li key={`${check.label}-${index}`} className="flex flex-col gap-2 py-3 sm:flex-row sm:items-center sm:justify-between"><div className="min-w-0"><div className="flex items-center gap-1.5 text-sm font-medium text-foreground">{check.href ? <a href={check.href} className="truncate hover:underline">{check.label}</a> : check.label}{check.href ? <ExternalLink className="h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-hidden="true" /> : null}</div>{check.detail ? <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{check.detail}</p> : null}</div><SourceHealthBadge status={check.status} label={check.statusLabel} /></li>)}</ul>
    </section>
  );
}
