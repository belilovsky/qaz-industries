import { cn } from "../utils/cn";
import { createSoftToneStyles } from "../utils/toneStyles";

/**
 * Метка состояния источника данных: работает, есть замечания, недоступен,
 * отключён или не настроен.
 */

export type SourceHealthStatus = "green" | "yellow" | "red" | "disabled" | "unconfigured";

export interface SourceHealthBadgeProps {
  status: SourceHealthStatus;
  /** Текст (по умолчанию – короткая метка статуса) */
  label?: string;
  size?: "sm" | "md";
  className?: string;
}

const healthConfig: Record<SourceHealthStatus, { accent: string; label: string }> = {
  green: {
    accent: "hsl(var(--chart-2))",
    label: "Работает",
  },
  yellow: {
    accent: "hsl(var(--chart-3))",
    label: "Есть замечания",
  },
  red: {
    accent: "hsl(var(--destructive))",
    label: "Недоступен",
  },
  disabled: {
    accent: "hsl(var(--muted-foreground))",
    label: "Отключён",
  },
  unconfigured: {
    accent: "hsl(var(--muted-foreground))",
    label: "Не настроен",
  },
};

export function SourceHealthBadge({ status, label, size = "sm", className }: SourceHealthBadgeProps) {
  const cfg = healthConfig[status] ?? healthConfig.unconfigured;
  const toneStyles = createSoftToneStyles(cfg.accent);

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium tracking-[0.01em]",
        size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs",
        className
      )}
      style={toneStyles.wrapper}
    >
      <span aria-hidden="true" className="h-1.5 w-1.5 flex-shrink-0 rounded-full" style={toneStyles.dot} />
      {label ?? cfg.label}
    </span>
  );
}
