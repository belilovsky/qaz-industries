import { type ReactNode } from "react";
import { cn } from "../utils/cn";

export type EvidenceUsePolicyStatus = "approved" | "needs_review" | "restricted" | "unknown";

export interface EvidenceUsePolicyPanelProps {
  accessLabel: ReactNode;
  legalBasisLabel: ReactNode;
  reviewStatus: EvidenceUsePolicyStatus;
  reviewLabel?: ReactNode;
  publicAllowed: boolean;
  rightsNote?: ReactNode;
  historyMeta?: ReactNode;
  action?: ReactNode;
  title?: string;
  className?: string;
}

const statusStyle: Record<EvidenceUsePolicyStatus, string> = {
  approved: "border-[hsl(var(--chart-2)/0.4)] bg-[hsl(var(--chart-2)/0.05)] text-foreground",
  needs_review: "border-[hsl(var(--chart-3)/0.45)] bg-[hsl(var(--chart-3)/0.06)] text-foreground",
  restricted: "border-destructive/35 bg-destructive/[0.045] text-foreground",
  unknown: "border-border bg-card text-foreground/85",
};

const defaultStatusLabel: Record<EvidenceUsePolicyStatus, string> = {
  approved: "Проверено",
  needs_review: "Нужна проверка",
  restricted: "Ограничено",
  unknown: "Не определено",
};

export function EvidenceUsePolicyPanel({
  accessLabel,
  legalBasisLabel,
  reviewStatus,
  reviewLabel,
  publicAllowed,
  rightsNote,
  historyMeta,
  action,
  title = "Политика использования",
  className,
}: EvidenceUsePolicyPanelProps) {
  const publicLabel = publicAllowed ? "Разрешено" : "Не разрешено";

  return (
    <section
      className={cn("min-w-0 border border-border bg-card p-4 sm:p-5", className)}
      aria-label={title}
      data-evidence-use-policy={reviewStatus}
      data-public-allowed={publicAllowed ? "true" : "false"}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-foreground">{title}</h3>
          <p className="mt-1 text-[12px] leading-[1.5] text-muted-foreground">
            Основание, редакционная проверка и предел публичного использования.
          </p>
        </div>
        <span className={cn("shrink-0 border px-2 py-1 text-[11px] font-semibold", statusStyle[reviewStatus])}>
          {reviewLabel ?? defaultStatusLabel[reviewStatus]}
        </span>
      </div>

      <dl className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
        <div className="border-t border-border/70 pt-2.5">
          <dt className="text-[11px] text-muted-foreground">Доступ</dt>
          <dd className="mt-1 text-[13px] font-medium text-foreground">{accessLabel}</dd>
        </div>
        <div className="border-t border-border/70 pt-2.5">
          <dt className="text-[11px] text-muted-foreground">Правовое основание</dt>
          <dd className="mt-1 text-[13px] font-medium text-foreground">{legalBasisLabel}</dd>
        </div>
        <div className="border-t border-border/70 pt-2.5">
          <dt className="text-[11px] text-muted-foreground">Проверка</dt>
          <dd className="mt-1 text-[13px] font-medium text-foreground">{reviewLabel ?? defaultStatusLabel[reviewStatus]}</dd>
        </div>
        <div className="border-t border-border/70 pt-2.5">
          <dt className="text-[11px] text-muted-foreground">Публичное использование</dt>
          <dd className="mt-1 text-[13px] font-medium text-foreground">{publicLabel}</dd>
        </div>
      </dl>

      {rightsNote ? <p className="mt-4 text-[12px] leading-[1.55] text-muted-foreground">{rightsNote}</p> : null}
      {historyMeta || action ? (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-border/70 pt-3 text-[12px] leading-[1.45] text-muted-foreground">
          <span>{historyMeta}</span>
          {action ? <span className="shrink-0">{action}</span> : null}
        </div>
      ) : null}
    </section>
  );
}
