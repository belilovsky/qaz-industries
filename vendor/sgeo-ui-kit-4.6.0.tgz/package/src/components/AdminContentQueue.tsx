import React from "react";
import { cn } from "../utils/cn";

export type AdminQueueTone = "neutral" | "info" | "success" | "warning" | "danger";

export interface AdminContentQueueItem {
  id: string;
  title: React.ReactNode;
  href?: string;
  meta?: React.ReactNode;
  status: React.ReactNode;
  statusTone?: AdminQueueTone;
  owner?: React.ReactNode;
  updatedAt?: React.ReactNode;
  schedule?: React.ReactNode;
  selected?: boolean;
  disabled?: boolean;
  actions?: React.ReactNode;
}

export interface AdminContentQueueProps {
  items: AdminContentQueueItem[];
  title?: React.ReactNode;
  description?: React.ReactNode;
  emptyMessage?: React.ReactNode;
  onToggleItem?: (id: string, selected: boolean) => void;
  onToggleAll?: (selected: boolean) => void;
  className?: string;
}

const statusToneClasses: Record<AdminQueueTone, string> = {
  neutral: "border-border bg-muted/35 text-foreground",
  info: "border-primary/25 bg-primary/[0.06] text-foreground",
  success: "border-status-online/30 bg-status-online/[0.08] text-foreground",
  warning: "border-status-away/35 bg-status-away/[0.1] text-foreground",
  danger: "border-destructive/25 bg-destructive/[0.07] text-foreground",
};

const statusDotClasses: Record<AdminQueueTone, string> = {
  neutral: "bg-muted-foreground",
  info: "bg-primary",
  success: "bg-status-online",
  warning: "bg-status-away",
  danger: "bg-destructive",
};

function QueueStatus({ item }: { item: AdminContentQueueItem }) {
  const tone = item.statusTone ?? "neutral";
  return (
    <span className={cn("inline-flex min-h-6 items-center gap-1.5 border px-2 py-0.5 text-[11px] font-semibold", statusToneClasses[tone])}>
      <span aria-hidden="true" className={cn("size-1.5 shrink-0 rounded-full", statusDotClasses[tone])} />
      {item.status}
    </span>
  );
}

function QueueTitle({ item }: { item: AdminContentQueueItem }) {
  if (item.href) {
    return (
      <a href={item.href} className="font-semibold text-foreground underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35">
        {item.title}
      </a>
    );
  }
  return <span className="font-semibold text-foreground">{item.title}</span>;
}

/** Responsive editorial queue with a table on wide screens and a compact list on mobile. */
export function AdminContentQueue({
  items,
  title,
  description,
  emptyMessage = "В очереди пока нет материалов.",
  onToggleItem,
  onToggleAll,
  className,
}: AdminContentQueueProps) {
  const selectable = Boolean(onToggleItem);
  const canToggleAll = selectable && Boolean(onToggleAll);
  const enabledItems = items.filter((item) => !item.disabled);
  const allSelected = enabledItems.length > 0 && enabledItems.every((item) => item.selected);

  return (
    <section className={cn("avds-admin-content-queue min-w-0", className)} aria-label={typeof title === "string" ? title : "Очередь материалов"}>
      {title || description ? (
        <div className="mb-3 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
          <div className="min-w-0">
            {title ? <h3 className="text-sm font-semibold text-foreground">{title}</h3> : null}
            {description ? <div className="mt-1 text-[12px] leading-relaxed text-muted-foreground">{description}</div> : null}
          </div>
          <div className="text-[11px] tabular-nums text-muted-foreground">{items.length} записей</div>
        </div>
      ) : null}

      {items.length === 0 ? (
        <div className="border-y border-dashed border-border px-4 py-8 text-center text-[13px] text-muted-foreground">{emptyMessage}</div>
      ) : (
        <>
          <div className="hidden overflow-x-auto border-y border-border/80 md:block" tabIndex={0} role="group" aria-label="Таблица очереди материалов">
            <table className="w-full min-w-[720px]">
              <thead className="bg-muted/25">
                <tr className="border-b border-border/80">
                  {selectable ? (
                    <th className="w-11 px-3 py-2 text-start">
                      <input
                        type="checkbox"
                        checked={allSelected}
                        disabled={!canToggleAll}
                        aria-label="Выбрать все доступные материалы"
                        onChange={(event) => onToggleAll?.(event.currentTarget.checked)}
                        className="size-4 accent-[hsl(var(--primary))]"
                      />
                    </th>
                  ) : null}
                  <th className="px-3 py-2 text-start text-[10px] font-semibold uppercase text-muted-foreground">Материал</th>
                  <th className="w-32 px-3 py-2 text-start text-[10px] font-semibold uppercase text-muted-foreground">Статус</th>
                  <th className="w-36 px-3 py-2 text-start text-[10px] font-semibold uppercase text-muted-foreground">Ответственный</th>
                  <th className="w-40 px-3 py-2 text-start text-[10px] font-semibold uppercase text-muted-foreground">Изменено</th>
                  <th className="w-24 px-3 py-2 text-end text-[10px] font-semibold uppercase text-muted-foreground">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/65">
                {items.map((item) => (
                  <tr key={item.id} className={cn("align-top transition-colors hover:bg-muted/20", item.selected && "shadow-[inset_2px_0_0_hsl(var(--primary))]", item.disabled && "opacity-50")}>
                    {selectable ? (
                      <td className="px-3 py-3">
                        <input
                          type="checkbox"
                          checked={Boolean(item.selected)}
                          disabled={item.disabled}
                          aria-label={`Выбрать материал ${typeof item.title === "string" ? item.title : item.id}`}
                          onChange={(event) => onToggleItem?.(item.id, event.currentTarget.checked)}
                          className="size-4 accent-[hsl(var(--primary))]"
                        />
                      </td>
                    ) : null}
                    <td className="px-3 py-3 text-[13px] leading-snug">
                      <QueueTitle item={item} />
                      {item.meta ? <div className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{item.meta}</div> : null}
                      {item.schedule ? <div className="mt-1 text-[11px] font-medium text-primary">{item.schedule}</div> : null}
                    </td>
                    <td className="px-3 py-3"><QueueStatus item={item} /></td>
                    <td className="px-3 py-3 text-[12px] text-foreground">{item.owner ?? "Не назначен"}</td>
                    <td className="px-3 py-3 text-[12px] tabular-nums text-muted-foreground">{item.updatedAt ?? "–"}</td>
                    <td className="px-3 py-3 text-end">{item.actions}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <ul className="divide-y divide-border/70 border-y border-border/80 md:hidden">
            {items.map((item) => (
              <li key={item.id} className={cn("px-1 py-3", item.selected && "shadow-[inset_2px_0_0_hsl(var(--primary))]", item.disabled && "opacity-50")}>
                <div className="flex items-start gap-2.5">
                  {selectable ? (
                    <input
                      type="checkbox"
                      checked={Boolean(item.selected)}
                      disabled={item.disabled}
                      aria-label={`Выбрать материал ${typeof item.title === "string" ? item.title : item.id}`}
                      onChange={(event) => onToggleItem?.(item.id, event.currentTarget.checked)}
                      className="mt-0.5 size-4 shrink-0 accent-[hsl(var(--primary))]"
                    />
                  ) : null}
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px] leading-snug"><QueueTitle item={item} /></div>
                    {item.meta ? <div className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{item.meta}</div> : null}
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <QueueStatus item={item} />
                      {item.owner ? <span className="text-[11px] text-muted-foreground">{item.owner}</span> : null}
                      {item.updatedAt ? <span className="text-[11px] tabular-nums text-muted-foreground">{item.updatedAt}</span> : null}
                    </div>
                    {item.schedule ? <div className="mt-2 text-[11px] font-medium text-primary">{item.schedule}</div> : null}
                  </div>
                  {item.actions ? <div className="shrink-0">{item.actions}</div> : null}
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </section>
  );
}
