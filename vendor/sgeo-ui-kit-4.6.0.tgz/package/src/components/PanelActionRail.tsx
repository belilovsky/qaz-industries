import React from "react";
import { cn } from "../utils/cn";

export interface PanelActionRailProps {
  primary: React.ReactNode;
  secondary?: React.ReactNode;
  metadata?: React.ReactNode;
  className?: string;
}

/**
 * Stable compact footer for high-frequency work panels. Product-specific
 * controls remain slots, while spacing and mobile wrapping stay consistent.
 */
export function PanelActionRail({ primary, secondary, metadata, className }: PanelActionRailProps) {
  return (
    <div className={cn("flex min-h-12 flex-wrap items-center justify-between gap-2 border-t border-border/70 bg-muted/[0.12] px-3 py-2 sm:flex-nowrap sm:px-4", className)}>
      <div className="flex min-w-0 items-center gap-1.5">{primary}</div>
      <div className="flex shrink-0 items-center gap-2">{secondary}{metadata}</div>
    </div>
  );
}
