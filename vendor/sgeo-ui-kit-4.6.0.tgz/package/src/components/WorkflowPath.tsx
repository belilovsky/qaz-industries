import { cn } from "../utils/cn";

export type WorkflowPathStatus = "complete" | "current" | "attention" | "pending";

export interface WorkflowPathStep {
  id: string;
  title: string;
  description?: string;
  status: WorkflowPathStatus;
  statusLabel?: string;
  meta?: string;
  disabled?: boolean;
}

export interface WorkflowPathProps {
  steps: WorkflowPathStep[];
  activeId?: string;
  onStepChange?: (id: string) => void;
  ariaLabel?: string;
  compact?: boolean;
  className?: string;
}

const defaultStatusLabels: Record<WorkflowPathStatus, string> = {
  complete: "Готово",
  current: "Текущий этап",
  attention: "Требует внимания",
  pending: "Ожидает",
};

const statusClassNames: Record<WorkflowPathStatus, string> = {
  complete: "border-[hsl(var(--chart-2)/0.35)] bg-[hsl(var(--chart-2)/0.06)]",
  current: "border-primary/50 bg-primary/[0.055]",
  attention: "border-[hsl(var(--chart-3)/0.4)] bg-[hsl(var(--chart-3)/0.07)]",
  pending: "border-border bg-card",
};

const statusTextClassNames: Record<WorkflowPathStatus, string> = {
  complete: "text-foreground",
  current: "text-primary",
  attention: "text-foreground",
  pending: "text-foreground/75",
};

export function WorkflowPath({
  steps,
  activeId,
  onStepChange,
  ariaLabel = "Маршрут работы",
  compact = false,
  className,
}: WorkflowPathProps) {
  return (
    <ol
      aria-label={ariaLabel}
      className={cn(
        "grid min-w-0 gap-2 sm:grid-cols-2 xl:grid-cols-4",
        className
      )}
    >
      {steps.map((step, index) => {
        const isActive = activeId ? step.id === activeId : step.status === "current";
        const statusLabel = step.statusLabel ?? defaultStatusLabels[step.status];
        const content = (
          <>
            <span className="flex min-w-0 items-start justify-between gap-3">
              <span className="flex min-w-0 items-start gap-2.5">
                <span
                  className={cn(
                    "flex h-5 w-5 shrink-0 items-center justify-center border text-[10px] font-semibold tabular-nums",
                    statusClassNames[step.status],
                    statusTextClassNames[step.status]
                  )}
                  aria-hidden="true"
                >
                  {index + 1}
                </span>
                <span className="min-w-0 text-start">
                  <span className="block text-[13px] font-semibold leading-snug text-foreground">{step.title}</span>
                  {step.description ? (
                    <span className="mt-1 block text-[12px] leading-[1.45] text-foreground/75">{step.description}</span>
                  ) : null}
                </span>
              </span>
              <span
                className={cn(
                  "shrink-0 text-[10px] font-medium uppercase tracking-[0.06em]",
                  statusTextClassNames[step.status]
                )}
              >
                {step.meta ?? statusLabel}
              </span>
            </span>
            <span className="sr-only">{statusLabel}</span>
          </>
        );

        const itemClassName = cn(
          "min-w-0 border px-3 py-3 text-start transition-[border-color,background-color] duration-150",
          compact && "px-2.5 py-2.5",
          statusClassNames[step.status],
          isActive && "ring-1 ring-primary/20",
          step.disabled && "cursor-not-allowed opacity-55",
          onStepChange && !step.disabled && "hover:border-foreground/25 hover:bg-muted/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35"
        );

        return (
          <li key={step.id} data-workflow-step={step.id} data-status={step.status} data-active={isActive ? "true" : "false"}>
            {onStepChange ? (
              <button
                type="button"
                className={cn(itemClassName, "w-full")}
                disabled={step.disabled}
                aria-current={isActive ? "step" : undefined}
                onClick={() => onStepChange(step.id)}
              >
                {content}
              </button>
            ) : (
              <div className={itemClassName} aria-current={isActive ? "step" : undefined}>
                {content}
              </div>
            )}
          </li>
        );
      })}
    </ol>
  );
}
