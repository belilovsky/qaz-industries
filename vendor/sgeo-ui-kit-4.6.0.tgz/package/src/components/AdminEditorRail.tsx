import React, { useId } from "react";
import { cn } from "../utils/cn";

export type AdminChecklistStatus = "complete" | "attention" | "blocked" | "pending";

export interface AdminChecklistItem {
  id: string;
  label: React.ReactNode;
  detail?: React.ReactNode;
  status: AdminChecklistStatus;
}

export interface AdminEditorRailProps {
  title?: React.ReactNode;
  status?: React.ReactNode;
  items: AdminChecklistItem[];
  actions?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
}

const markerClasses: Record<AdminChecklistStatus, string> = {
  complete: "border-status-online/40 bg-status-online/15 text-foreground",
  attention: "border-status-away/45 bg-status-away/15 text-foreground",
  blocked: "border-destructive/40 bg-destructive/10 text-foreground",
  pending: "border-border bg-muted/40 text-foreground",
};

const markerLabel: Record<AdminChecklistStatus, string> = {
  complete: "Готово",
  attention: "Нужно проверить",
  blocked: "Заблокировано",
  pending: "Ожидает",
};

/** Compact side rail for publication checks, metadata and primary actions. */
export function AdminEditorRail({ title = "Готовность материала", status, items, actions, children, className }: AdminEditorRailProps) {
  const titleId = useId();

  return (
    <aside aria-labelledby={titleId} className={cn("avds-admin-editor-rail border-y border-border/80 bg-muted/[0.12]", className)}>
      <div className="flex items-center justify-between gap-3 border-b border-border/75 px-3 py-2.5">
        <h3 id={titleId} className="text-[13px] font-semibold text-foreground">{title}</h3>
        {status ? <div className="text-[11px] font-medium text-muted-foreground">{status}</div> : null}
      </div>
      <ol className="divide-y divide-border/65">
        {items.map((item) => (
          <li key={item.id} className="grid grid-cols-[auto_minmax(0,1fr)] gap-2.5 px-3 py-2.5">
            <span className={cn("mt-0.5 inline-flex min-h-5 items-center border px-1.5 text-[9px] font-semibold uppercase", markerClasses[item.status])}>
              {markerLabel[item.status]}
            </span>
            <div className="min-w-0">
              <div className="text-[12px] font-medium leading-snug text-foreground">{item.label}</div>
              {item.detail ? <div className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{item.detail}</div> : null}
            </div>
          </li>
        ))}
      </ol>
      {children ? <div className="border-t border-border/75 px-3 py-3">{children}</div> : null}
      {actions ? <div className="flex flex-wrap gap-2 border-t border-border/75 px-3 py-3">{actions}</div> : null}
    </aside>
  );
}
