import { type ReactNode } from "react";
import { cn } from "../utils/cn";

export interface QuickLinksRailItem {
  label: string;
  href?: string;
  target?: string;
  rel?: string;
  icon?: ReactNode;
  meta?: string;
  active?: boolean;
  ariaLabel?: string;
  onClick?: () => void;
}

export interface QuickLinksRailProps {
  items: QuickLinksRailItem[];
  ariaLabel?: string;
  wrap?: boolean;
  size?: "sm" | "md";
  className?: string;
}

function QuickLinkPill({ item, size = "md" }: { item: QuickLinksRailItem; size?: "sm" | "md" }) {
  const inner = (
    <>
      {item.icon ? <span className="shrink-0 text-muted-foreground">{item.icon}</span> : null}
      <span className="truncate">{item.label}</span>
      {item.meta ? (
        <span
          className={cn(
            "rounded-sm border px-1.5 py-0.5 text-[10px] font-semibold tabular-nums",
            item.active ? "border-border/80 bg-background text-foreground" : "border-border/70 bg-background/80 text-muted-foreground"
          )}
        >
          {item.meta}
        </span>
      ) : null}
    </>
  );

  const pillClassName = cn(
    "inline-flex min-w-0 items-center gap-1.5 rounded-sm border transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
    size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-xs",
    item.active
      ? "border-foreground/25 bg-background text-foreground"
      : "border-border/80 bg-card text-muted-foreground hover:border-border hover:bg-background hover:text-foreground",
    (item.href || item.onClick) && "hover:border-foreground/20 hover:bg-muted/20"
  );

  if (item.href) {
    return (
      <a
        href={item.href}
        target={item.target}
        rel={item.rel}
        aria-label={item.ariaLabel}
        aria-current={item.active ? "page" : undefined}
        className={cn(pillClassName, "no-underline")}
      >
        {inner}
      </a>
    );
  }

  if (item.onClick) {
    return (
      <button
        type="button"
        onClick={item.onClick}
        aria-label={item.ariaLabel}
        aria-pressed={item.active || undefined}
        className={pillClassName}
      >
        {inner}
      </button>
    );
  }

  return <span className={pillClassName}>{inner}</span>;
}

export function QuickLinksRail({
  items,
  ariaLabel = "Быстрые ссылки",
  wrap = false,
  size = "md",
  className,
}: QuickLinksRailProps) {
  return (
    <div
      role="group"
      aria-label={ariaLabel}
      className={cn(
        "flex min-w-0 gap-2 overflow-x-auto pb-1",
        wrap ? "flex-wrap overflow-visible pb-0" : "whitespace-nowrap",
        className
      )}
    >
      {items.map((item, index) => (
        <QuickLinkPill key={`${item.label}-${index}`} item={item} size={size} />
      ))}
    </div>
  );
}
