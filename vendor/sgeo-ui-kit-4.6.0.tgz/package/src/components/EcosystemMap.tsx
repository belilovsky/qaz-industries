import { ArrowRight, Network } from "lucide-react";
import { cn } from "../utils/cn";
import { SourceHealthBadge, type SourceHealthStatus } from "./SourceHealthBadge";

export interface EcosystemMapNode { id: string; label: string; description?: string; layer?: string; href?: string; status?: SourceHealthStatus; statusLabel?: string; }
export interface EcosystemMapLink { from: string; to: string; label?: string; }
export interface EcosystemMapProps { title?: string; summary?: string; nodes: EcosystemMapNode[]; links?: EcosystemMapLink[]; className?: string; }

/** Semantic dependency map that remains readable and usable on narrow screens. */
export function EcosystemMap({ title = "Карта экосистемы", summary, nodes, links = [], className }: EcosystemMapProps) {
  const nodeById = new Map(nodes.map((node) => [node.id, node]));
  return (
    <section className={cn("rounded-lg border border-border bg-card p-4 sm:p-5", className)} aria-label={title} data-testid="ecosystem-map">
      <header className="flex items-start gap-3 border-b border-border pb-4">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-border bg-muted/35 text-muted-foreground"><Network className="h-4 w-4" aria-hidden="true" /></div>
        <div className="min-w-0"><h3 className="text-base font-semibold text-foreground">{title}</h3>{summary ? <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{summary}</p> : null}</div>
      </header>
      <ul className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3" aria-label="Системы экосистемы">
        {nodes.map((node) => {
          const label = <><div className="flex min-w-0 items-start justify-between gap-3"><div className="min-w-0">{node.layer ? <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">{node.layer}</div> : null}<div className="mt-0.5 truncate text-sm font-semibold text-foreground">{node.label}</div></div>{node.status ? <SourceHealthBadge status={node.status} label={node.statusLabel} /> : null}</div>{node.description ? <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{node.description}</p> : null}</>;
          return <li key={node.id} className="min-w-0">{node.href ? <a href={node.href} className="block rounded-md border border-border bg-background p-3 no-underline transition-colors hover:bg-muted/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30">{label}</a> : <div className="rounded-md border border-border bg-background p-3">{label}</div>}</li>;
        })}
      </ul>
      {links.length ? <ul className="mt-4 divide-y divide-border border-y border-border" aria-label="Связи экосистемы">{links.map((link, index) => { const from = nodeById.get(link.from)?.label ?? link.from; const to = nodeById.get(link.to)?.label ?? link.to; return <li key={`${link.from}-${link.to}-${index}`} className="flex flex-col gap-1 py-2.5 text-sm sm:flex-row sm:items-center sm:gap-2"><span className="font-medium text-foreground">{from}</span><ArrowRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" aria-hidden="true" /><span className="font-medium text-foreground">{to}</span>{link.label ? <span className="text-xs text-muted-foreground sm:ml-auto">{link.label}</span> : null}</li>; })}</ul> : null}
    </section>
  );
}
