import { cn } from "../utils/cn";
import { SourceBadge } from "./SourceBadge";

export interface ProvenanceTableRow {
  metric: string;
  source: string;
  sourceKey?: string;
  period?: string;
  value: string;
  note?: string;
  href?: string;
}

export interface ProvenanceTableProps {
  rows: ProvenanceTableRow[];
  className?: string;
  compact?: boolean;
}

function CellValue({ row }: { row: ProvenanceTableRow }) {
  const body = (
    <div className="min-w-0">
      <div className="font-medium text-foreground">{row.value}</div>
      {row.note ? <div className="mt-1 text-[12px] leading-relaxed text-muted-foreground">{row.note}</div> : null}
    </div>
  );

  if (row.href) {
    return (
      <a href={row.href} className="text-primary no-underline hover:underline">
        {body}
      </a>
    );
  }

  return body;
}

export function ProvenanceTable({ rows, className, compact = false }: ProvenanceTableProps) {
  return (
    <div className={cn("overflow-hidden rounded-sm border border-border bg-card", className)}>
      <div className="grid gap-2 p-3 sm:hidden" role="list" aria-label="Сведения о происхождении данных">
        {rows.map((row, index) => (
          <article key={`${row.metric}-${index}`} className="grid gap-2 border-b border-border/70 pb-2 last:border-b-0 last:pb-0" role="listitem">
            <div className="flex min-w-0 items-start justify-between gap-3">
              <span className="min-w-0 text-[12.5px] font-medium text-foreground">{row.metric}</span>
              <CellValue row={row} />
            </div>
            <div className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-muted-foreground">
              {row.sourceKey ? (
                <SourceBadge source={row.sourceKey} label={row.source} size="sm" />
              ) : (
                <span>{row.source}</span>
              )}
              <span>{row.period || "–"}</span>
            </div>
          </article>
        ))}
      </div>
      <div
        className="hidden overflow-x-auto focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35 sm:block"
        tabIndex={0}
        role="group"
        aria-label="Прокручиваемая таблица происхождения данных"
      >
        <table className="min-w-full border-collapse text-start">
          <thead className="bg-muted/35">
            <tr className="text-[11px] uppercase tracking-[0.06em] text-muted-foreground">
              <th className="px-4 py-3 font-medium">Метрика</th>
              <th className="px-4 py-3 font-medium">Источник</th>
              <th className="px-4 py-3 font-medium">Период</th>
              <th className="px-4 py-3 font-medium">Значение</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={`${row.metric}-${index}`} className="border-t border-border/70 align-top">
                <td className={cn("px-4 font-medium text-foreground", compact ? "py-3 text-[12.5px]" : "py-3.5 text-sm")}>
                  {row.metric}
                </td>
                <td className={cn("px-4", compact ? "py-3" : "py-3.5")}>
                  {row.sourceKey ? (
                    <SourceBadge source={row.sourceKey} label={row.source} size="sm" />
                  ) : (
                    <span className="text-[12.5px] text-muted-foreground">{row.source}</span>
                  )}
                </td>
                <td className={cn("px-4 text-[12.5px] text-muted-foreground", compact ? "py-3" : "py-3.5")}>
                  {row.period || "–"}
                </td>
                <td className={cn("px-4", compact ? "py-3" : "py-3.5")}>
                  <CellValue row={row} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
