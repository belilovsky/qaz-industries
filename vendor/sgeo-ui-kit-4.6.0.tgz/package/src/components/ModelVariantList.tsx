import React, { useId } from "react";
import { ChevronDown, Clock3 } from "lucide-react";
import { cn } from "../utils/cn";

export interface ModelVariantListItem {
  id: string;
  label: React.ReactNode;
  content?: React.ReactNode;
  error?: React.ReactNode;
  latencyMs?: number;
  confidence?: number;
  action?: React.ReactNode;
  tone?: "default" | "success" | "warning" | "danger";
}

export interface ModelVariantListProps {
  title: React.ReactNode;
  summary?: React.ReactNode;
  badge?: React.ReactNode;
  icon?: React.ReactNode;
  items: ModelVariantListItem[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  expandLabel?: string;
  collapseLabel?: string;
  emptyMessage?: React.ReactNode;
  className?: string;
}

const toneClassName: Record<NonNullable<ModelVariantListItem["tone"]>, string> = {
  default: "border-border/70 bg-muted/30 text-foreground",
  success: "border-[hsl(var(--chart-2)/0.35)] bg-[hsl(var(--chart-2)/0.1)] text-foreground",
  warning: "border-[hsl(var(--chart-3)/0.4)] bg-[hsl(var(--chart-3)/0.1)] text-foreground",
  danger: "border-destructive/35 bg-destructive/[0.08] text-foreground",
};

/**
 * Compact, controlled disclosure for comparing several model or algorithm
 * outputs without forcing the operator into a separate detail page.
 */
export function ModelVariantList({
  title,
  summary,
  badge,
  icon,
  items,
  open,
  onOpenChange,
  expandLabel = "Показать варианты",
  collapseLabel = "Скрыть варианты",
  emptyMessage = "Варианты пока не получены.",
  className,
}: ModelVariantListProps) {
  const contentId = useId();

  return (
    <section className={cn("min-w-0 overflow-hidden rounded-sm border border-border/80 bg-card", className)}>
      <button
        type="button"
        aria-expanded={open}
        aria-controls={contentId}
        onClick={() => onOpenChange(!open)}
        className="flex w-full items-start gap-3 px-3 py-3 text-start transition-colors hover:bg-muted/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary/35 sm:px-4"
      >
        {icon ? <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center border border-primary/20 bg-primary/[0.08] text-primary">{icon}</span> : null}
        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-semibold text-foreground">{title}</span>
            {badge}
          </span>
          {summary ? <span className="mt-0.5 block text-[11px] leading-4 text-muted-foreground">{summary}</span> : null}
        </span>
        <span className="inline-flex shrink-0 items-center gap-1.5 text-[11px] text-muted-foreground">
          <span className="hidden sm:inline">{open ? collapseLabel : expandLabel}</span>
          <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} aria-hidden="true" />
        </span>
      </button>

      {open ? (
        <div id={contentId} className="grid grid-cols-1 gap-2.5 border-t border-border/65 p-3 sm:grid-cols-2 sm:p-4">
          {items.length === 0 ? (
            <p className="col-span-full border-y border-dashed border-border py-3 text-sm text-muted-foreground">{emptyMessage}</p>
          ) : items.map((item) => (
            <article
              key={item.id}
              className={cn("min-w-0 border border-border/75 bg-background/55 p-3", item.error && "border-destructive/35 bg-destructive/[0.035]")}
              data-model-variant={item.id}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex min-w-0 flex-wrap items-center gap-2">
                  <span className={cn("inline-flex min-h-5 items-center border px-1.5 text-[10px] font-semibold", toneClassName[item.tone ?? "default"])}>{item.label}</span>
                  {item.latencyMs !== undefined && !item.error ? (
                    <span className="inline-flex items-center gap-1 font-mono text-[10px] tabular-nums text-muted-foreground">
                      <Clock3 className="h-3 w-3" aria-hidden="true" />
                      {(item.latencyMs / 1000).toFixed(1)}с
                    </span>
                  ) : null}
                </div>
                <div className="flex shrink-0 items-center gap-1.5">
                  {item.confidence !== undefined && !item.error ? <span className="font-mono text-[10px] tabular-nums text-muted-foreground">{Math.round(item.confidence * 100)}%</span> : null}
                  {item.action}
                </div>
              </div>
              <div className={cn("mt-2 text-[13px] leading-relaxed", item.error ? "text-destructive" : "text-foreground")}>{item.error ?? item.content ?? emptyMessage}</div>
            </article>
          ))}
        </div>
      ) : null}
    </section>
  );
}
