import { type CSSProperties } from "react";
import { cn } from "../utils/cn";

export interface ThemeCoverageLink {
  label: string;
  href: string;
  ariaLabel?: string;
}

export interface ThemeCoverageCardProps {
  code: string;
  title: string;
  countLabel: string;
  accentColor?: string;
  links?: ThemeCoverageLink[];
  linksLabel?: string;
  href?: string;
  summary?: string;
  className?: string;
}

export function ThemeCoverageCard({
  code,
  title,
  countLabel,
  accentColor,
  links = [],
  linksLabel = "Открыть тему",
  href,
  summary,
  className,
}: ThemeCoverageCardProps) {
  const style = accentColor
    ? ({ "--theme-coverage-accent": accentColor, borderTopColor: accentColor } as CSSProperties)
    : undefined;

  const titleNode = href ? (
    <a href={href} className="no-underline hover:text-primary">
      {title}
    </a>
  ) : (
    title
  );

  return (
    <article
      className={cn(
        "relative overflow-hidden rounded-sm border border-t-2 border-border/80 bg-card px-4 py-4 transition-colors duration-150 hover:bg-muted/20",
        className
      )}
      style={style}
    >
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="font-mono text-[11px] font-bold uppercase tracking-[0.1em] text-[var(--theme-coverage-accent,hsl(var(--primary)))]">
                {code}
              </div>
              <h3 className="mt-1 text-[15px] font-semibold leading-tight text-foreground sm:text-base">
                {titleNode}
              </h3>
            </div>
            <div className="shrink-0 whitespace-nowrap text-[11px] font-semibold text-muted-foreground tabular-nums">
              {countLabel}
            </div>
          </div>
          {summary ? <p className="mt-2 text-sm leading-[1.55] text-muted-foreground">{summary}</p> : null}
        </div>
      </div>

      {links.length ? (
        <div className="mt-3.5 border-t border-border/70 pt-3">
          <div className="text-[10px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">
            {linksLabel}
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {links.map((link, index) => (
              <a
                key={`${link.label}-${index}`}
                href={link.href}
                aria-label={link.ariaLabel}
                className="inline-flex min-h-[28px] items-center border-b border-border px-0.5 text-[11px] font-semibold uppercase tracking-[0.05em] text-foreground/88 no-underline transition-colors hover:border-primary hover:text-primary"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      ) : null}
    </article>
  );
}
