import { cn } from "../utils/cn";
import { SourceHealthBadge, type SourceHealthStatus } from "./SourceHealthBadge";

export type ReadinessState = "ready" | "needs_evidence" | "blocked" | "planned";
export interface ReadinessBoardItem { id: string; label: string; description?: string; state: ReadinessState; evidence?: string; consumers?: string; }
export interface ReadinessBoardProps { title?: string; summary?: string; items: ReadinessBoardItem[]; className?: string; }

const stateMeta: Record<ReadinessState, { badge: SourceHealthStatus; label: string }> = {
  ready: { badge: "green", label: "готов" }, needs_evidence: { badge: "yellow", label: "нужны подтверждения" }, blocked: { badge: "red", label: "есть блокер" }, planned: { badge: "disabled", label: "запланирован" },
};

/** A compact evidence board for package adoption and release readiness. */
export function ReadinessBoard({ title = "Готовность компонентов", summary, items, className }: ReadinessBoardProps) {
  const ready = items.filter((item) => item.state === "ready").length;
  return (
    <section className={cn("rounded-lg border border-border bg-card p-4 sm:p-5", className)} aria-label={title} data-testid="readiness-board">
      <header className="flex flex-col gap-3 border-b border-border pb-4 sm:flex-row sm:items-start sm:justify-between"><div className="min-w-0"><h3 className="text-base font-semibold text-foreground">{title}</h3>{summary ? <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{summary}</p> : null}</div><SourceHealthBadge status={ready === items.length ? "green" : "yellow"} label={`${ready}/${items.length} готовы`} size="md" /></header>
      <ul className="mt-3 divide-y divide-border" aria-label="Состояние готовности">{items.map((item) => { const meta = stateMeta[item.state]; return <li key={item.id} className="flex flex-col gap-2 py-3 sm:flex-row sm:items-start sm:justify-between"><div className="min-w-0"><div className="text-sm font-medium text-foreground">{item.label}</div>{item.description ? <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{item.description}</p> : null}{item.evidence || item.consumers ? <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{[item.evidence, item.consumers].filter(Boolean).join(" · ")}</p> : null}</div><SourceHealthBadge status={meta.badge} label={meta.label} /></li>; })}</ul>
    </section>
  );
}
