import { type ReactNode } from "react";
import { cn } from "../utils/cn";

export type EvidencePairReviewStatus = "new" | "confirmed_duplicate" | "related" | "not_duplicate";

export interface EvidencePairReviewSide {
  title: string;
  source?: ReactNode;
  href?: string;
}

export interface EvidencePairReviewCardProps {
  left: EvidencePairReviewSide;
  right: EvidencePairReviewSide;
  reason: ReactNode;
  status: EvidencePairReviewStatus;
  statusLabel?: string;
  reviewedMeta?: ReactNode;
  controls?: ReactNode;
  className?: string;
}

const statusToneClassName: Record<EvidencePairReviewStatus, string> = {
  new: "border-border bg-card",
  confirmed_duplicate: "border-[hsl(var(--chart-3)/0.45)] bg-[hsl(var(--chart-3)/0.05)]",
  related: "border-primary/45 bg-primary/[0.04]",
  not_duplicate: "border-[hsl(var(--chart-2)/0.35)] bg-[hsl(var(--chart-2)/0.04)]",
};

const defaultStatusLabels: Record<EvidencePairReviewStatus, string> = {
  new: "Не разобрано",
  confirmed_duplicate: "Подтверждённый дубль",
  related: "Связанные материалы",
  not_duplicate: "Не дубль",
};

function ReviewSide({ item }: { item: EvidencePairReviewSide }) {
  const titleNode = item.href ? (
    <a href={item.href} className="font-semibold text-primary no-underline hover:underline">
      {item.title}
    </a>
  ) : (
    <span className="font-semibold text-foreground">{item.title}</span>
  );

  return (
    <div className="grid gap-1">
      {titleNode}
      {item.source ? (
        <span className="text-[12px] leading-[1.45] text-foreground/90">{item.source}</span>
      ) : null}
    </div>
  );
}

export function EvidencePairReviewCard({
  left,
  right,
  reason,
  status,
  statusLabel,
  reviewedMeta,
  controls,
  className,
}: EvidencePairReviewCardProps) {
  return (
    <article
      className={cn(
        "grid min-w-0 gap-3 border px-3.5 py-3 sm:grid-cols-[minmax(0,1.1fr)_minmax(10rem,0.7fr)_minmax(0,1fr)_minmax(9rem,0.55fr)]",
        statusToneClassName[status],
        className
      )}
      data-evidence-pair-status={status}
    >
      <div className="grid min-w-0 gap-1.5">
        <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground/80">Материалы</span>
        <div className="grid gap-2">
          <ReviewSide item={left} />
          <ReviewSide item={right} />
        </div>
      </div>

      <div className="grid min-w-0 gap-1.5">
        <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground/80">Причина</span>
        <div className="text-[13px] leading-[1.45] text-foreground">{reason}</div>
      </div>

      <div className="grid min-w-0 gap-1.5">
        <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground/80">Решение</span>
        {controls ? (
          <div className="min-w-0">{controls}</div>
        ) : (
          <span className="inline-flex w-fit items-center border border-border px-2 py-1 text-[12px] font-semibold text-foreground/85">
            {statusLabel ?? defaultStatusLabels[status]}
          </span>
        )}
      </div>

      <div className="grid min-w-0 gap-1.5">
        <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground/80">Проверено</span>
        <div className="text-[12px] leading-[1.45] text-foreground/90">{reviewedMeta ?? "Ожидает решения"}</div>
      </div>
    </article>
  );
}
