import { cn } from "../utils/cn";

export type EvidenceTrailStatus = "verified" | "current" | "warning" | "failed" | "pending";

export interface EvidenceTrailStep {
  id: string;
  label: string;
  detail?: string;
  meta?: string;
  status: EvidenceTrailStatus;
}

export interface EvidenceTrailProps {
  steps: EvidenceTrailStep[];
  ariaLabel?: string;
  compact?: boolean;
  className?: string;
}

const statusDot: Record<EvidenceTrailStatus, string> = {
  verified: "bg-[hsl(var(--chart-2))]",
  current: "bg-primary",
  warning: "bg-[hsl(var(--chart-3))]",
  failed: "bg-destructive",
  pending: "bg-muted-foreground/45",
};

export function EvidenceTrail({ steps, ariaLabel = "Цепочка доказательств", compact = false, className }: EvidenceTrailProps) {
  return (
    <ol aria-label={ariaLabel} className={cn("divide-y divide-border/70 border-y border-border/80", className)}>
      {steps.map((step, index) => (
        <li
          key={step.id}
          className={cn("grid min-w-0 grid-cols-[auto_minmax(0,1fr)_auto] items-start gap-3", compact ? "py-2" : "py-3")}
          data-evidence-step={step.id}
          data-status={step.status}
        >
          <span className="flex h-5 min-w-5 items-center gap-2" aria-hidden="true">
            <span className={cn("h-2 w-2 rounded-full", statusDot[step.status])} />
            <span className="font-mono text-[10px] tabular-nums text-muted-foreground">{String(index + 1).padStart(2, "0")}</span>
          </span>
          <span className="min-w-0">
            <span className="block text-[12px] font-semibold leading-snug text-foreground">{step.label}</span>
            {step.detail ? <span className="mt-0.5 block text-[11px] leading-[1.45] text-muted-foreground">{step.detail}</span> : null}
          </span>
          {step.meta ? <span className="max-w-32 text-end font-mono text-[10px] leading-[1.4] text-muted-foreground">{step.meta}</span> : null}
        </li>
      ))}
    </ol>
  );
}
