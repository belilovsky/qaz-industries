import { type ReactNode } from "react";
import { AccentCard, type AccentVariant } from "./AccentCard";
import { SourceHealthBadge, type SourceHealthStatus } from "./SourceHealthBadge";
import { cn } from "../utils/cn";

export interface ServiceStatusMetric {
  label: string;
  value: ReactNode;
  note?: string;
}

export interface ServiceStatusCardProps {
  title: string;
  status: SourceHealthStatus;
  statusLabel?: string;
  summary?: string;
  metrics?: ServiceStatusMetric[];
  footer?: ReactNode;
  className?: string;
}

const accentByStatus: Record<SourceHealthStatus, AccentVariant> = {
  green: "green",
  yellow: "amber",
  red: "red",
  disabled: "neutral",
  unconfigured: "neutral",
};

export function ServiceStatusCard({
  title,
  status,
  statusLabel,
  summary,
  metrics,
  footer,
  className,
}: ServiceStatusCardProps) {
  return (
    <AccentCard variant={accentByStatus[status]} className={cn("rounded-sm p-4 sm:p-5", className)}>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0">
            <div className="text-lg font-semibold leading-snug text-foreground">{title}</div>
            {summary ? <p className="mt-1 text-sm leading-[1.6] text-muted-foreground">{summary}</p> : null}
          </div>
          <div className="shrink-0">
            <SourceHealthBadge status={status} label={statusLabel} size="md" />
          </div>
        </div>

        {metrics?.length ? (
          <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {metrics.map((metric, index) => (
              <div
                key={`${metric.label}-${index}`}
                className="border-t border-border/70 pt-2.5"
              >
                <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
                  {metric.label}
                </div>
                <div className="mt-1 text-base font-semibold leading-snug text-foreground">{metric.value}</div>
                {metric.note ? (
                  <div className="mt-1 text-[12px] leading-[1.5] text-muted-foreground">{metric.note}</div>
                ) : null}
              </div>
            ))}
          </div>
        ) : null}

        {footer ? <div className="text-[12px] leading-[1.55] text-muted-foreground">{footer}</div> : null}
      </div>
    </AccentCard>
  );
}
