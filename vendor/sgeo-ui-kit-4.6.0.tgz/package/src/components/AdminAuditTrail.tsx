import React, { useId } from "react";
import { cn } from "../utils/cn";

export type AdminAuditTone = "neutral" | "success" | "warning" | "danger";

export interface AdminAuditEntry {
  id: string;
  action: React.ReactNode;
  actor: React.ReactNode;
  occurredAt: React.ReactNode;
  target?: React.ReactNode;
  detail?: React.ReactNode;
  source?: React.ReactNode;
  tone?: AdminAuditTone;
}

export interface AdminAuditTrailProps {
  entries: AdminAuditEntry[];
  title?: React.ReactNode;
  description?: React.ReactNode;
  emptyMessage?: React.ReactNode;
  className?: string;
}

const toneClasses: Record<AdminAuditTone, string> = {
  neutral: "border-border bg-muted/35 text-foreground",
  success: "border-status-online/35 bg-status-online/10 text-foreground",
  warning: "border-status-away/40 bg-status-away/10 text-foreground",
  danger: "border-destructive/35 bg-destructive/10 text-foreground",
};

export function AdminAuditTrail({
  entries,
  title = "Журнал действий",
  description,
  emptyMessage = "Событий за выбранный период нет.",
  className,
}: AdminAuditTrailProps) {
  const titleId = useId();

  return (
    <section aria-labelledby={titleId} className={cn("avds-admin-audit-trail", className)}>
      <div className="mb-3">
        <h3 id={titleId} className="text-sm font-semibold text-foreground">{title}</h3>
        {description ? <div className="mt-1 text-[12px] leading-relaxed text-muted-foreground">{description}</div> : null}
      </div>
      {entries.length === 0 ? (
        <div className="border-y border-dashed border-border px-4 py-7 text-center text-[13px] text-muted-foreground">{emptyMessage}</div>
      ) : (
        <ol className="divide-y divide-border/65 border-y border-border/80">
          {entries.map((entry) => (
            <li key={entry.id} className="grid gap-2 px-2 py-3 sm:grid-cols-[8.5rem_minmax(0,1fr)_10rem] sm:items-start sm:px-3">
              <div className="text-[11px] tabular-nums text-muted-foreground">{entry.occurredAt}</div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={cn("inline-flex min-h-5 items-center border px-1.5 text-[10px] font-semibold", toneClasses[entry.tone ?? "neutral"])}>{entry.action}</span>
                  {entry.target ? <span className="truncate text-[12px] font-medium text-foreground">{entry.target}</span> : null}
                </div>
                {entry.detail ? <div className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground">{entry.detail}</div> : null}
              </div>
              <div className="text-[11px] sm:text-end">
                <div className="font-medium text-foreground">{entry.actor}</div>
                {entry.source ? <div className="mt-1 text-muted-foreground">{entry.source}</div> : null}
              </div>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
