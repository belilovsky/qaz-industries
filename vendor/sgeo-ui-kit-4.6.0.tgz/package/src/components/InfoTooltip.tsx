import { useState, useRef, useCallback, useEffect, type KeyboardEvent, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { cn } from "../utils/cn";

/**
 * Универсальная всплывающая подсказка через Portal (выводится в document.body).
 * Никогда не обрезается overflow:hidden родителей.
 *
 * Два варианта использования:
 *   <InfoTooltip title="…" body="…" />              – body как HTML-строка
 *   <InfoTooltip title="…">…children…</InfoTooltip>  – body как JSX
 */

export interface InfoTooltipProps {
  /** Заголовок всплывающей подсказки */
  title: string;
  /** HTML-строка для содержимого (альтернатива children) */
  body?: string;
  /** Формула или код */
  formula?: string;
  /** Цветовые диапазоны/легенда */
  ranges?: { color: string; label: string }[];
  /** JSX-содержимое (альтернатива body) */
  children?: ReactNode;
  /** Иконка в заголовке */
  icon?: ReactNode;
  /** Дополнительные CSS-классы для панели */
  className?: string;
}

function escapeHtml(html: string): string {
  return html
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function stripDangerousHtml(html: string): string {
  return html
    .replace(/<\s*(script|style|iframe|object|embed|svg|math)[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi, "")
    .replace(/\s+on[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "")
    .replace(/\s+(href|src)\s*=\s*(?:"\s*javascript:[^"]*"|'\s*javascript:[^']*'|\s*javascript:[^\s>]+)/gi, "")
    .replace(/\s+(href|src)\s*=\s*(?:"\s*data:[^"]*"|'\s*data:[^']*'|\s*data:[^\s>]+)/gi, "");
}

const tooltipAllowedTags = new Set(["A", "B", "BR", "CODE", "EM", "I", "LI", "OL", "P", "SPAN", "STRONG", "UL"]);
const tooltipAllowedAttrs = new Set(["href", "rel", "target"]);

function sanitizeBrowserHtml(html: string): string {
  const template = document.createElement("template");
  template.innerHTML = stripDangerousHtml(html);

  const elements = Array.from(template.content.querySelectorAll("*"));
  for (const element of elements) {
    if (!tooltipAllowedTags.has(element.tagName)) {
      element.replaceWith(document.createTextNode(element.textContent || ""));
      continue;
    }

    for (const attr of Array.from(element.attributes)) {
      const name = attr.name.toLowerCase();
      const value = attr.value.trim().toLowerCase();
      if (!tooltipAllowedAttrs.has(name) || value.startsWith("javascript:") || value.startsWith("data:")) {
        element.removeAttribute(attr.name);
      }
    }

    if (element.tagName === "A" && element.getAttribute("target") === "_blank") {
      element.setAttribute("rel", "noopener noreferrer");
    }
  }

  return template.innerHTML;
}

/** @internal */
export function sanitizeTooltipHtml(html: string): string {
  if (typeof window === "undefined" || !window.document) {
    return escapeHtml(stripDangerousHtml(html));
  }

  return sanitizeBrowserHtml(html);
}

export function InfoTooltip({ title, body, formula, ranges, children, icon, className }: InfoTooltipProps) {
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  const reposition = useCallback(() => {
    if (!triggerRef.current) return;
    const rect = triggerRef.current.getBoundingClientRect();
    const panelW = 340;
    let left = rect.left + rect.width / 2 - panelW / 2;
    const top = rect.bottom + 10;
    if (left < 16) left = 16;
    if (left + panelW > window.innerWidth - 16) left = window.innerWidth - 16 - panelW;
    setPos({ top, left });
  }, []);

  const handleEnter = useCallback(() => {
    reposition();
    setOpen(true);
  }, [reposition]);

  const handleLeave = useCallback(() => {
    setOpen(false);
  }, []);

  const handleKeyDown = useCallback((event: KeyboardEvent<HTMLButtonElement>) => {
    if (event.key === "Escape") {
      event.preventDefault();
      setOpen(false);
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    const onScroll = () => setOpen(false);
    window.addEventListener("scroll", onScroll, { passive: true, capture: true });
    return () => window.removeEventListener("scroll", onScroll, true);
  }, [open]);

  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  return (
    <>
      <button
        type="button"
        ref={triggerRef}
        className="info-trigger"
        aria-label={title}
        aria-expanded={open}
        onMouseEnter={handleEnter}
        onFocus={handleEnter}
        onMouseLeave={handleLeave}
        onBlur={handleLeave}
        onKeyDown={handleKeyDown}
      >
        ?
      </button>

      {open &&
        createPortal(
          isMobile ? (
            <>
              <div className="fixed inset-0 z-[999] bg-black/20" onClick={handleLeave} />
              <div
                ref={panelRef}
                className={cn(
                  "fixed bottom-0 left-0 right-0 z-[1000] rounded-t-sm border-t bg-popover p-4 shadow-xl text-popover-foreground animate-in slide-in-from-bottom",
                  className
                )}
                style={{ maxHeight: "50vh", overflowY: "auto" }}
              >
                <PanelContent title={title} body={body} formula={formula} ranges={ranges} icon={icon}>
                  {children}
                </PanelContent>
              </div>
            </>
          ) : (
            <div
              ref={panelRef}
              className={cn(
                "fixed z-[1000] w-[340px] max-w-[calc(100vw-32px)] rounded-sm border bg-popover p-4 shadow-xl text-popover-foreground",
                className
              )}
              style={{
                top: pos?.top ?? -9999,
                left: pos?.left ?? -9999,
                wordWrap: "break-word",
                overflowWrap: "break-word",
              }}
              onMouseEnter={() => setOpen(true)}
              onMouseLeave={handleLeave}
            >
              <div className="absolute -top-[5px] left-1/2 -translate-x-1/2 rotate-45 w-2.5 h-2.5 bg-popover border-l border-t border-border" />
              <PanelContent title={title} body={body} formula={formula} ranges={ranges} icon={icon}>
                {children}
              </PanelContent>
            </div>
          ),
          document.body
        )}
    </>
  );
}

function PanelContent({
  title, body, formula, ranges, children, icon,
}: {
  title: string; body?: string; formula?: string;
  ranges?: { color: string; label: string }[]; children?: ReactNode; icon?: ReactNode;
}) {
  return (
    <>
      <div className="text-xs font-semibold mb-2 pb-2 border-b border-border/60 flex items-center gap-1.5">
        {icon || <span aria-hidden="true" className="inline-flex h-4 w-4 items-center justify-center rounded-full border border-border text-[9px] text-muted-foreground">i</span>} {title}
      </div>
      {body ? (
        <div className="text-[11.5px] leading-relaxed text-muted-foreground" dangerouslySetInnerHTML={{ __html: sanitizeTooltipHtml(body) }} />
      ) : children ? (
        <div className="text-[11.5px] leading-relaxed text-muted-foreground">{children}</div>
      ) : null}
      {formula && (
        <div className="mt-2.5 rounded-sm border border-border/60 bg-muted/50 p-2.5 font-mono text-[10px] text-muted-foreground">
          {formula}
        </div>
      )}
      {ranges && (
        <div className="mt-2.5 flex gap-2.5">
          {ranges.map((r, i) => (
            <div key={i} className="flex items-center gap-1 text-[10px] text-muted-foreground font-medium">
              <span className="w-2 h-2 rounded-sm" style={{ background: r.color }} />
              {r.label}
            </div>
          ))}
        </div>
      )}
    </>
  );
}
