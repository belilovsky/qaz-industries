import { cn } from "../utils/cn";
import { createSoftToneStyles } from "../utils/toneStyles";

export type DataQualitySeverity = "verified" | "info" | "warning" | "critical" | "unknown";

export interface DataQualityFlagProps {
  severity: DataQualitySeverity;
  label: string;
  detail?: string;
  compact?: boolean;
  className?: string;
}

const severityAccent: Record<DataQualitySeverity, string> = {
  verified: "hsl(var(--chart-2))",
  info: "hsl(var(--primary))",
  warning: "hsl(var(--chart-3))",
  critical: "hsl(var(--destructive))",
  unknown: "hsl(var(--muted-foreground))",
};

export function DataQualityFlag({ severity, label, detail, compact = false, className }: DataQualityFlagProps) {
  const styles = createSoftToneStyles(severityAccent[severity]);
  return (
    <div
      className={cn(
        "flex min-w-0 items-start gap-2.5 text-start",
        compact ? "py-0.5" : "rounded-sm border px-3 py-2.5",
        className
      )}
      data-quality={severity}
      role={severity === "critical" ? "alert" : "status"}
      style={compact ? undefined : styles.wrapper}
    >
      <span className="mt-1 h-2 w-2 shrink-0 rounded-full" aria-hidden="true" style={styles.dot} />
      <span className="min-w-0">
        <span className="block text-[12px] font-semibold leading-snug text-foreground">{label}</span>
        {detail ? <span className="mt-0.5 block text-[11px] leading-[1.45] text-foreground/80">{detail}</span> : null}
      </span>
    </div>
  );
}
