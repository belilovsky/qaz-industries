import { useCallback, useEffect, useRef, useState } from "react";
import { Check, Copy } from "lucide-react";
import { cn } from "../utils/cn";

/**
 * Кнопка копирования текста в буфер обмена.
 */

export interface CopyButtonProps {
  /** Текст для копирования */
  text: string;
  /** Текстовая метка рядом с иконкой */
  label?: string;
  size?: "sm" | "md";
  /** Текст при успешном копировании */
  successLabel?: string;
  /** Длительность отображения успеха (мс) */
  successDuration?: number;
  className?: string;
}

export function CopyButton({
  text,
  label,
  size = "md",
  successLabel = "Скопировано",
  successDuration = 1500,
  className,
}: CopyButtonProps) {
  const [copied, setCopied] = useState(false);
  const resetTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (resetTimerRef.current) {
        window.clearTimeout(resetTimerRef.current);
      }
    };
  }, []);

  const handleCopy = useCallback(async () => {
    if (resetTimerRef.current) {
      window.clearTimeout(resetTimerRef.current);
    }

    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
    }
    setCopied(true);
    resetTimerRef.current = window.setTimeout(() => {
      setCopied(false);
      resetTimerRef.current = null;
    }, successDuration);
  }, [text, successDuration]);

  const Icon = copied ? Check : Copy;
  const displayLabel = copied ? successLabel : label;
  const ariaLabel = displayLabel ?? (copied ? successLabel : "Скопировать");

  return (
    <button
      type="button"
      onClick={handleCopy}
      aria-label={ariaLabel}
      className={cn(
        "inline-flex items-center gap-1.5 text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
        size === "sm" ? "h-7 text-xs" : "h-8 text-sm",
        className
      )}
    >
      <Icon className={cn(size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4", copied && "text-primary")} />
      {displayLabel && <span className={cn(copied && "text-primary")}>{displayLabel}</span>}
    </button>
  );
}
