import { type ReactNode } from "react";
import { cn } from "../utils/cn";

export interface OperatorPageShellNavItem {
  id: string;
  label: string;
  href?: string;
  badge?: ReactNode;
  ariaLabel?: string;
}

export interface OperatorPageShellProps {
  eyebrow?: string;
  title: string;
  summary?: string;
  navLabel?: string;
  navItems?: OperatorPageShellNavItem[];
  activeNavId?: string;
  onNavigate?: (id: string) => void;
  actions?: ReactNode;
  alert?: ReactNode;
  children: ReactNode;
  className?: string;
}

/** A calm, keyboard-friendly shell for operational pages with one clear work area. */
export function OperatorPageShell({
  eyebrow,
  title,
  summary,
  navLabel = "Разделы рабочей области",
  navItems,
  activeNavId,
  onNavigate,
  actions,
  alert,
  children,
  className,
}: OperatorPageShellProps) {
  return (
    <main className={cn("mx-auto w-full max-w-7xl px-4 py-5 sm:px-6 sm:py-7", className)}>
      <a
        href="#operator-page-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-background focus:px-3 focus:py-2 focus:text-sm focus:font-medium focus:text-foreground focus:shadow-lg"
      >
        Перейти к содержанию
      </a>
      <header className="border-b border-border pb-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0">
            {eyebrow ? <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">{eyebrow}</div> : null}
            <h1 className="mt-1 text-2xl font-semibold leading-tight text-foreground sm:text-3xl">{title}</h1>
            {summary ? <p className="mt-2 max-w-3xl text-sm leading-relaxed text-muted-foreground">{summary}</p> : null}
          </div>
          {actions ? <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div> : null}
        </div>
        {navItems?.length ? (
          <nav aria-label={navLabel} className="mt-5 flex gap-2 overflow-x-auto pb-1">
            {navItems.map((item) => {
              const active = item.id === activeNavId;
              const classes = cn(
                "inline-flex min-h-9 shrink-0 items-center gap-2 rounded-md border px-3 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
                active ? "border-primary/35 bg-primary/10 text-foreground" : "border-border bg-background text-muted-foreground hover:bg-muted/50 hover:text-foreground"
              );
              const content = <>{item.label}{item.badge ? <span className="text-xs text-muted-foreground">{item.badge}</span> : null}</>;
              return item.href ? (
                <a key={item.id} href={item.href} aria-label={item.ariaLabel} aria-current={active ? "page" : undefined} className={classes}>{content}</a>
              ) : (
                <button key={item.id} type="button" aria-label={item.ariaLabel} aria-pressed={active} className={classes} onClick={() => onNavigate?.(item.id)}>{content}</button>
              );
            })}
          </nav>
        ) : null}
      </header>
      {alert ? <div className="mt-4" aria-live="polite">{alert}</div> : null}
      <div id="operator-page-content" tabIndex={-1} className="mt-6 outline-none">{children}</div>
    </main>
  );
}
