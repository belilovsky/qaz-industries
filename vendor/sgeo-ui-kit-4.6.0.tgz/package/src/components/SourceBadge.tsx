import { cn } from "../utils/cn";
import { createSoftToneStyles } from "../utils/toneStyles";

/**
 * Метка источника – цветная метка для указания происхождения данных
 * в стиле StatusBadge.
 */

export interface SourceBadgeProps {
  source: string;
  size?: "sm" | "md";
  /** Переопределить текст метки (по умолчанию – source с заглавной) */
  label?: string;
  className?: string;
}

interface SourceColor {
  accent: string;
}

export const SOURCE_COLORS: Record<string, SourceColor> = {
  bing: {
    accent: "hsl(var(--primary))",
  },
  wikimedia: {
    accent: "hsl(var(--muted-foreground))",
  },
  unsplash: {
    accent: "hsl(var(--foreground))",
  },
  pixabay: {
    accent: "hsl(var(--chart-2))",
  },
  pexels: {
    accent: "hsl(var(--chart-2))",
  },
  yandex: {
    accent: "hsl(var(--destructive))",
  },
  qazlake: {
    accent: "hsl(var(--chart-1))",
  },
  openverse: {
    accent: "hsl(var(--chart-4))",
  },
  loc: {
    accent: "color-mix(in srgb, hsl(var(--chart-4)) 72%, hsl(var(--primary)))",
  },
  europeana: {
    accent: "hsl(var(--chart-3))",
  },
  pastvu: {
    accent: "hsl(var(--chart-3))",
  },
  dpla: {
    accent: "hsl(var(--chart-4))",
  },
};

const defaultColor: SourceColor = {
  accent: "hsl(var(--muted-foreground))",
};

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export function SourceBadge({ source, size = "md", label, className }: SourceBadgeProps) {
  const cfg = SOURCE_COLORS[source.toLowerCase()] ?? defaultColor;
  const toneStyles = createSoftToneStyles(cfg.accent);

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium tracking-[0.01em]",
        size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs",
        className
      )}
      style={toneStyles.wrapper}
    >
      <span className="h-1.5 w-1.5 flex-shrink-0 rounded-full" style={toneStyles.dot} />
      {label ?? capitalize(source)}
    </span>
  );
}
