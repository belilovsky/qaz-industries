import React, { useId } from "react";
import { cn } from "../utils/cn";

export interface AdminRoleColumn {
  id: string;
  label: React.ReactNode;
  description?: React.ReactNode;
}

export interface AdminPermissionItem {
  id: string;
  label: React.ReactNode;
  description?: React.ReactNode;
}

export interface AdminPermissionGroup {
  id: string;
  label: React.ReactNode;
  permissions: AdminPermissionItem[];
}

export interface AdminRoleMatrixProps {
  roles: AdminRoleColumn[];
  groups: AdminPermissionGroup[];
  value: Record<string, readonly string[]>;
  onChange?: (roleId: string, permissionId: string, enabled: boolean) => void;
  title?: React.ReactNode;
  description?: React.ReactNode;
  readOnly?: boolean;
  className?: string;
}

export function AdminRoleMatrix({
  roles,
  groups,
  value,
  onChange,
  title = "Роли и разрешения",
  description,
  readOnly = false,
  className,
}: AdminRoleMatrixProps) {
  const titleId = useId();

  return (
    <section aria-labelledby={titleId} className={cn("avds-admin-role-matrix min-w-0", className)}>
      <div className="mb-3">
        <h3 id={titleId} className="text-sm font-semibold text-foreground">{title}</h3>
        {description ? <div className="mt-1 max-w-3xl text-[12px] leading-relaxed text-muted-foreground">{description}</div> : null}
      </div>
      <div className="overflow-x-auto border-y border-border/80" tabIndex={0} role="group" aria-label="Матрица ролей и разрешений">
        <table className="w-full min-w-[640px]">
          <thead>
            <tr className="border-b border-border/80 bg-muted/25">
              <th className="min-w-64 px-3 py-2.5 text-start text-[10px] font-semibold uppercase text-muted-foreground">Разрешение</th>
              {roles.map((role) => (
                <th key={role.id} className="min-w-28 px-3 py-2.5 text-center align-bottom">
                  <div className="text-[11px] font-semibold text-foreground">{role.label}</div>
                  {role.description ? <div className="mt-1 text-[10px] font-normal leading-snug text-muted-foreground">{role.description}</div> : null}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {groups.map((group) => (
              <React.Fragment key={group.id}>
                <tr className="border-y border-border/70 bg-muted/[0.12]">
                  <th colSpan={roles.length + 1} className="px-3 py-2 text-start text-[10px] font-semibold uppercase text-muted-foreground">{group.label}</th>
                </tr>
                {group.permissions.map((permission) => (
                  <tr key={permission.id} className="border-b border-border/55 last:border-b-0 hover:bg-muted/15">
                    <th scope="row" className="px-3 py-2.5 text-start">
                      <div className="text-[12px] font-medium text-foreground">{permission.label}</div>
                      {permission.description ? <div className="mt-0.5 text-[10px] font-normal leading-relaxed text-muted-foreground">{permission.description}</div> : null}
                    </th>
                    {roles.map((role) => {
                      const checked = value[role.id]?.includes(permission.id) ?? false;
                      return (
                        <td key={role.id} className="px-3 py-2.5 text-center">
                          <input
                            type="checkbox"
                            checked={checked}
                            disabled={readOnly || !onChange}
                            aria-label={`${typeof role.label === "string" ? role.label : role.id}: ${typeof permission.label === "string" ? permission.label : permission.id}`}
                            onChange={(event) => onChange?.(role.id, permission.id, event.currentTarget.checked)}
                            className="size-4 accent-[hsl(var(--primary))] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35"
                          />
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
