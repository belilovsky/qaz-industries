import { type ReactNode } from "react";
import { Search, X } from "lucide-react";
import { cn } from "../utils/cn";

export interface CommandPaletteItem { id: string; label: string; description?: string; href?: string; meta?: ReactNode; disabled?: boolean; }
export interface CommandPaletteGroup { label: string; items: CommandPaletteItem[]; }
export interface CommandPaletteProps { open: boolean; query: string; groups: CommandPaletteGroup[]; placeholder?: string; emptyMessage?: string; onQueryChange?: (query: string) => void; onSelect?: (item: CommandPaletteItem) => void; onClose?: () => void; className?: string; }

/** Search overlay for navigational work, not a mutation command runner. */
export function CommandPalette({ open, query, groups, placeholder = "Найти проект, страницу или компонент", emptyMessage = "Ничего не найдено. Уточните запрос.", onQueryChange, onSelect, onClose, className }: CommandPaletteProps) {
  if (!open) return null;
  const items = groups.flatMap((group) => group.items);
  return (
    <div className="fixed inset-0 z-50 bg-foreground/35 p-4 sm:p-8" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose?.(); }}>
      <section role="dialog" aria-modal="true" aria-labelledby="command-palette-title" className={cn("mx-auto mt-[8vh] w-full max-w-2xl overflow-hidden rounded-lg border border-border bg-background shadow-2xl", className)}>
        <header className="flex items-center gap-3 border-b border-border px-4 py-3">
          <Search className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
          <label className="sr-only" htmlFor="command-palette-query">{placeholder}</label>
          <input id="command-palette-query" value={query} onChange={(event) => onQueryChange?.(event.target.value)} placeholder={placeholder} autoComplete="off" className="min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground" />
          {onClose ? <button type="button" onClick={onClose} className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted/50 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30" aria-label="Закрыть поиск"><X className="h-4 w-4" /></button> : null}
        </header>
        <h2 id="command-palette-title" className="sr-only">Поиск по рабочей области</h2>
        <div className="max-h-[65vh] overflow-y-auto p-2">
          {items.length ? groups.filter((group) => group.items.length).map((group) => <section key={group.label} className="py-2"><h3 className="px-2 pb-1 text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">{group.label}</h3><div className="grid gap-1">{group.items.map((item) => {
            const content = <><span className="min-w-0"><span className="block truncate text-sm font-medium text-foreground">{item.label}</span>{item.description ? <span className="mt-0.5 block truncate text-xs text-muted-foreground">{item.description}</span> : null}</span>{item.meta ? <span className="shrink-0 text-xs text-muted-foreground">{item.meta}</span> : null}</>;
            const classes = "flex min-h-11 w-full items-center justify-between gap-4 rounded-md px-3 py-2 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 disabled:cursor-not-allowed disabled:opacity-50";
            return item.href ? <a key={item.id} href={item.href} className={cn(classes, item.disabled && "pointer-events-none")} aria-disabled={item.disabled || undefined} onClick={() => onSelect?.(item)}>{content}</a> : <button key={item.id} type="button" disabled={item.disabled} className={classes} onClick={() => onSelect?.(item)}>{content}</button>;
          })}</div></section>) : <div className="px-3 py-8 text-center text-sm text-muted-foreground">{emptyMessage}</div>}
        </div>
      </section>
    </div>
  );
}
