import "./RangeWithFlags.css";
import { cn } from "../utils/cn";

/**
 * RangeWithFlags – визуализация диапазона значений из нескольких источников
 * с выводом флагов противоречивых данных (measure_mismatch / scope_mismatch / bns_pending).
 *
 * Предназначен для отрисовки результатов QazLake `/api/v1/digital-audience/ranges`,
 * где по одному срезу может быть несколько source_id с разными value.
 */
export type RangeFlag = "measure_mismatch" | "scope_mismatch" | "bns_pending" | string;

export interface RangeWithFlagsProps {
  /** Заголовок среза (напр. "Проникновение интернета, KZ") */
  label: string;
  /** Минимум в выборке */
  valueMin: number;
  /** Максимум в выборке */
  valueMax: number;
  /** Максимум шкалы */
  scaleMax?: number;
  /** Единица измерения (напр. "%", "млн") */
  unit?: string;
  /** Список source_id из QazLake */
  sources: string[];
  /** Список флагов противоречий */
  flags?: RangeFlag[];
  /** Метка времени последнего обновления */
  lastUpdated?: string;
  className?: string;
}

const FLAG_LABEL: Record<string, { ru: string; tone: string }> = {
  measure_mismatch: { ru: "Разные меры", tone: "hsl(var(--chart-3))" },
  scope_mismatch: { ru: "Разный охват", tone: "hsl(var(--primary))" },
  bns_pending: { ru: "БНС ожидается", tone: "hsl(var(--chart-4))" },
};

function fmt(n: number, unit?: string): string {
  if (!isFinite(n)) return "–";
  const v = Math.abs(n) >= 100 ? n.toFixed(0) : n.toFixed(1);
  return unit ? `${v}${unit === "%" ? "%" : " " + unit}` : v;
}

export function RangeWithFlags(props: RangeWithFlagsProps): JSX.Element {
  const {
    label,
    valueMin,
    valueMax,
    scaleMax,
    unit,
    sources,
    flags = [],
    lastUpdated,
    className,
  } = props;

  const max = scaleMax ?? Math.max(valueMax * 1.2, 100);
  const leftPct = Math.max(0, Math.min(100, (valueMin / max) * 100));
  const widthPct = Math.max(0.5, ((valueMax - valueMin) / max) * 100);
  const isPoint = valueMin === valueMax;
  const conflict = flags.length > 0;

  return (
    <div
      className={cn(
        "avds-range-with-flags",
        conflict && "avds-range-with-flags--conflict",
        className,
      )}
      data-conflict={conflict ? "1" : "0"}
      role="group"
      aria-label={label}
    >
      <div className="avds-range-with-flags__head">
        <b className="avds-range-with-flags__label">{label}</b>
        <div className="avds-range-with-flags__flags">
          {flags.map((f) => {
            const meta = FLAG_LABEL[f] ?? { ru: f, tone: "hsl(var(--muted-foreground))" };
            return (
              <span
                key={f}
                className="avds-range-with-flags__flag"
                style={{ borderColor: meta.tone }}
                title={f}
              >
                {meta.ru}
              </span>
            );
          })}
        </div>
      </div>

      <div className="avds-range-with-flags__track" aria-hidden="true">
        <div
          className="avds-range-with-flags__fill"
          style={{ insetInlineStart: `${leftPct}%`, width: `${widthPct}%` }}
        />
      </div>

      <div className="avds-range-with-flags__hint">
        {isPoint
          ? fmt(valueMin, unit)
          : `${fmt(valueMin, unit)} – ${fmt(valueMax, unit)}`}
        <span className="avds-range-with-flags__sources">
          {" · "}
          {sources.length === 0 ? "qazlake" : sources.join(" + ")}
        </span>
        {lastUpdated && (
          <span className="avds-range-with-flags__ts">
            {" · "}
            {lastUpdated}
          </span>
        )}
      </div>
    </div>
  );
}

export default RangeWithFlags;
