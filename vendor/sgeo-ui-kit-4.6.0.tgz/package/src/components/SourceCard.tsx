import { cn } from "../utils/cn";
import { SourceBadge } from "./SourceBadge";
import { SourceHealthBadge, type SourceHealthStatus } from "./SourceHealthBadge";
import { SourcePolicyBadge, type SourcePolicyKind } from "./SourcePolicyBadge";

/**
 * Карточка источника данных: происхождение, состояние, правила использования и краткие сведения.
 */

export interface SourceCardProps {
  name: string;
  sourceId?: string;
  sourceType?: string;
  category?: string;
  url?: string;
  attribution?: string;
  healthStatus?: SourceHealthStatus;
  policy?: SourcePolicyKind;
  piiRisk?: "low" | "medium" | "high" | "review" | string;
  lastUpdated?: string;
  itemCount?: number | string;
  description?: string;
  compact?: boolean;
  metaItems?: SourceCardMetaItem[];
  labels?: Partial<{
    pii: string;
    items: string;
    updated: string;
    attribution: string;
    requiredAttribution: string;
  }>;
  piiRiskLabels?: Record<string, string>;
  className?: string;
}

export interface SourceCardMetaItem {
  label: string;
  value?: React.ReactNode;
  note?: React.ReactNode;
}

const piiClass: Record<string, string> = {
  low: "text-foreground",
  medium: "text-foreground",
  high: "text-destructive",
  review: "text-foreground",
};

export function SourceCard({
  name,
  sourceId,
  sourceType,
  category,
  url,
  attribution,
  healthStatus,
  policy,
  piiRisk,
  lastUpdated,
  itemCount,
  description,
  compact = false,
  metaItems,
  labels,
  piiRiskLabels,
  className,
}: SourceCardProps) {
  const sourceKey = sourceType || category || sourceId || "source";
  const piiKey = (piiRisk || "").toLowerCase();
  const resolvedLabels = {
    pii: "Персональные данные",
    items: "Элементы",
    updated: "Обновлено",
    attribution: "Указание источника",
    requiredAttribution: "нужно указать",
    ...labels,
  };
  const resolvedPiiRisk = piiRisk
    ? piiRiskLabels?.[piiKey] || piiRisk
    : piiRiskLabels?.review || "нужна проверка";
  const resolvedMetaItems = metaItems || [
    { label: resolvedLabels.pii, value: resolvedPiiRisk },
    { label: resolvedLabels.items, value: itemCount ?? "–" },
    { label: resolvedLabels.updated, value: lastUpdated || "–" },
    { label: resolvedLabels.attribution, value: attribution || resolvedLabels.requiredAttribution },
  ];

  return (
    <article className={cn("rounded-sm border border-border/80 bg-card", compact ? "p-4" : "p-5", className)}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="truncate text-sm font-semibold text-foreground">{name}</h3>
            {sourceKey ? <SourceBadge source={sourceKey} size="sm" label={sourceType || category || sourceId} /> : null}
          </div>
          {sourceId ? <div className="mt-1 font-mono text-[11px] text-foreground/75">{sourceId}</div> : null}
        </div>
        <div className="flex flex-wrap gap-2">
          {healthStatus ? <SourceHealthBadge status={healthStatus} /> : null}
          {policy ? <SourcePolicyBadge policy={policy} /> : null}
        </div>
      </div>

      {description ? <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{description}</p> : null}

      <dl className={cn("grid gap-2 text-xs", compact ? "mt-4 grid-cols-2" : "mt-5 grid-cols-2 sm:grid-cols-4")}>
        {resolvedMetaItems.map((item, index) => {
          const isPiiSlot = !metaItems && index === 0;
          return (
            <div key={`${item.label}-${index}`} className="border-t border-border/70 pt-2.5">
              <dt className="text-[11px] text-foreground/75">{item.label}</dt>
              <dd
                className={cn(
                  "mt-1 font-medium text-foreground",
                  !metaItems && index === 1 && "tabular-nums",
                  isPiiSlot && (piiClass[piiKey] || "text-foreground")
                )}
                title={typeof item.value === "string" ? item.value : undefined}
              >
                {item.value ?? "–"}
                {item.note ? <span className="mt-1 block text-[11px] leading-relaxed text-foreground/75">{item.note}</span> : null}
              </dd>
            </div>
          );
        })}
      </dl>

      {url ? (
        <a className="mt-4 inline-flex text-xs font-medium text-primary underline-offset-4 hover:underline" href={url}>
          {url}
        </a>
      ) : null}
    </article>
  );
}
