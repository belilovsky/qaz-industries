import React, { useId } from "react";
import { cn } from "../utils/cn";

export interface AdminSettingItem {
  id: string;
  label: React.ReactNode;
  description?: React.ReactNode;
  value?: React.ReactNode;
  control?: React.ReactNode;
  status?: React.ReactNode;
  disabled?: boolean;
}

export interface AdminSettingsGroupProps {
  title: React.ReactNode;
  description?: React.ReactNode;
  items: AdminSettingItem[];
  actions?: React.ReactNode;
  className?: string;
}

export function AdminSettingsGroup({ title, description, items, actions, className }: AdminSettingsGroupProps) {
  const titleId = useId();

  return (
    <section aria-labelledby={titleId} className={cn("avds-admin-settings-group border-y border-border/80", className)}>
      <header className="flex flex-col gap-2 bg-muted/[0.16] px-3 py-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h3 id={titleId} className="text-sm font-semibold text-foreground">{title}</h3>
          {description ? <div className="mt-1 max-w-3xl text-[12px] leading-relaxed text-muted-foreground">{description}</div> : null}
        </div>
        {actions ? <div className="flex shrink-0 flex-wrap gap-2">{actions}</div> : null}
      </header>
      <div className="divide-y divide-border/65">
        {items.map((item) => (
          <div
            key={item.id}
            aria-disabled={item.disabled || undefined}
            className={cn(
              "avds-admin-setting-row grid gap-2 px-3 py-3 sm:grid-cols-[minmax(0,1fr)_minmax(12rem,0.7fr)] sm:items-center",
              item.disabled && "bg-muted/[0.12]"
            )}
          >
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <div className="text-[13px] font-medium text-foreground">{item.label}</div>
                {item.status ? <div className="text-[10px] font-semibold uppercase text-muted-foreground">{item.status}</div> : null}
              </div>
              {item.description ? <div className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{item.description}</div> : null}
            </div>
            <div className="flex min-w-0 items-center gap-2 sm:justify-end">
              {item.value ? <div className="min-w-0 truncate text-[12px] font-medium text-foreground">{item.value}</div> : null}
              {item.control ? <div className="shrink-0">{item.control}</div> : null}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
