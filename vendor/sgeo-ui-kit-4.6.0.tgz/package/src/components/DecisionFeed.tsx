import React from "react";
import { cn } from "../utils/cn";

export type DecisionFeedPriority = "critical" | "high" | "normal";

export interface DecisionFeedItem {
  id: string;
  title: string;
  signal: React.ReactNode;
  action: React.ReactNode;
  priority: DecisionFeedPriority;
  lane?: React.ReactNode;
  evidence?: React.ReactNode[];
  href?: string;
  disabled?: boolean;
}

export interface DecisionFeedProps {
  items: DecisionFeedItem[];
  ariaLabel?: string;
  selectedId?: string;
  onItemSelect?: (id: string) => void;
  priorityLabels?: Partial<Record<DecisionFeedPriority, string>>;
  signalLabel?: string;
  actionLabel?: string;
  emptyTitle?: string;
  emptyMessage?: string;
  compact?: boolean;
  className?: string;
}

const defaultPriorityLabels: Record<DecisionFeedPriority, string> = {
  critical: "Критично",
  high: "Высокий приоритет",
  normal: "Обычный приоритет",
};

const priorityClassNames: Record<DecisionFeedPriority, string> = {
  critical: "border-destructive/45 bg-destructive/[0.035]",
  high: "border-[hsl(var(--chart-3)/0.45)] bg-[hsl(var(--chart-3)/0.045)]",
  normal: "border-border/85 bg-card",
};

const priorityTextClassNames: Record<DecisionFeedPriority, string> = {
  critical: "text-destructive",
  high: "text-foreground",
  normal: "text-foreground/75",
};

const priorityDotClassNames: Record<DecisionFeedPriority, string> = {
  critical: "bg-destructive",
  high: "bg-[hsl(var(--chart-3))]",
  normal: "bg-muted-foreground/45",
};

export function DecisionFeed({
  items,
  ariaLabel = "Лента решений",
  selectedId,
  onItemSelect,
  priorityLabels,
  signalLabel = "Сигнал",
  actionLabel = "Следующий шаг",
  emptyTitle = "Решений пока нет",
  emptyMessage = "Новые действия появятся после обновления источников и правил продукта.",
  compact = false,
  className,
}: DecisionFeedProps) {
  const resolvedPriorityLabels = { ...defaultPriorityLabels, ...priorityLabels };

  if (items.length === 0) {
    return (
      <section aria-label={ariaLabel} className={cn("border-y border-border py-3", className)}>
        <div className="text-sm font-semibold text-foreground">{emptyTitle}</div>
        <div className="mt-1 text-sm leading-relaxed text-muted-foreground">{emptyMessage}</div>
      </section>
    );
  }

  return (
    <section aria-label={ariaLabel} className={className}>
      <ol className="grid gap-2">
        {items.map((item) => {
          const isSelected = selectedId === item.id;
          const itemClassName = cn(
            "block w-full min-w-0 border text-start transition-[border-color,background-color,box-shadow]",
            compact ? "px-3 py-2.5" : "px-3.5 py-3.5",
            priorityClassNames[item.priority],
            isSelected && "ring-1 ring-primary/25",
            (item.href || onItemSelect) && !item.disabled &&
              "hover:border-foreground/25 hover:bg-muted/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35",
            item.disabled && "cursor-not-allowed opacity-55"
          );

          const content = (
            <>
              <div className="flex min-w-0 items-start justify-between gap-3">
                <div className="flex min-w-0 items-start gap-2">
                  <span className={cn("mt-1 h-2 w-2 shrink-0 rounded-full", priorityDotClassNames[item.priority])} aria-hidden="true" />
                  <div className="min-w-0">
                  <div className="text-[13px] font-semibold leading-snug text-foreground">{item.title}</div>
                  {item.lane ? (
                    <div className="mt-0.5 text-[11px] text-foreground/75">{item.lane}</div>
                  ) : null}
                  </div>
                </div>
                <div
                  className={cn(
                    "shrink-0 text-[11px] font-semibold",
                    priorityTextClassNames[item.priority]
                  )}
                >
                  {resolvedPriorityLabels[item.priority]}
                </div>
              </div>

              <div className="mt-3 grid gap-2 sm:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
                <div className="min-w-0">
                  <div className="text-[11px] font-medium text-foreground/75">{signalLabel}</div>
                  <div className="mt-0.5 text-[13px] font-semibold leading-snug text-foreground">{item.signal}</div>
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] font-medium text-foreground/75">{actionLabel}</div>
                  <div className="mt-0.5 text-[13px] leading-relaxed text-foreground/88">{item.action}</div>
                </div>
              </div>

              {item.evidence?.length ? (
                <ul className="mt-2.5 flex flex-wrap gap-x-3 gap-y-1 border-t border-border/65 pt-2 text-[11px] text-foreground/75">
                  {item.evidence.map((evidence, index) => (
                    <li key={`${item.id}-evidence-${index}`} className="before:me-1.5 before:content-['·']">
                      {evidence}
                    </li>
                  ))}
                </ul>
              ) : null}
            </>
          );

          return (
            <li key={item.id} data-decision-id={item.id} data-priority={item.priority}>
              {item.href ? (
                <a
                  href={item.href}
                  aria-current={isSelected ? "true" : undefined}
                  aria-disabled={item.disabled || undefined}
                  tabIndex={item.disabled ? -1 : undefined}
                  className={itemClassName}
                  onClick={item.disabled ? (event) => event.preventDefault() : undefined}
                >
                  {content}
                </a>
              ) : onItemSelect ? (
                <button
                  type="button"
                  disabled={item.disabled}
                  aria-pressed={isSelected}
                  className={itemClassName}
                  onClick={() => onItemSelect(item.id)}
                >
                  {content}
                </button>
              ) : (
                <article className={itemClassName} aria-current={isSelected ? "true" : undefined}>
                  {content}
                </article>
              )}
            </li>
          );
        })}
      </ol>
    </section>
  );
}
