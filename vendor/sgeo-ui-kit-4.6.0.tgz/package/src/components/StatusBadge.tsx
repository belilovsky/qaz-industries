import { cn } from "../utils/cn";
import { createSoftToneStyles } from "../utils/toneStyles";

/**
 * Метка статуса – completed/running/pending/failed/error
 */

export type StatusType = "completed" | "running" | "pending" | "failed" | "error";

export interface StatusBadgeProps {
  status: StatusType;
  /** Текст (по умолчанию – русское название статуса) */
  label?: string;
  size?: "sm" | "md";
  className?: string;
}

const statusConfig: Record<StatusType, { accent: string; dotClassName?: string; label: string }> = {
  completed: {
    accent: "hsl(var(--chart-2))",
    label: "Готово",
  },
  running: {
    accent: "hsl(var(--primary))",
    dotClassName: "animate-pulse",
    label: "В процессе",
  },
  pending: {
    accent: "hsl(var(--chart-3))",
    label: "Ожидание",
  },
  failed: {
    accent: "hsl(var(--destructive))",
    label: "Ошибка",
  },
  error: {
    accent: "hsl(var(--destructive))",
    label: "Ошибка",
  },
};

export function StatusBadge({ status, label, size = "sm", className }: StatusBadgeProps) {
  const cfg = statusConfig[status] || statusConfig.pending;
  const toneStyles = createSoftToneStyles(cfg.accent);

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border font-medium tracking-[0.01em]",
        size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs",
        className
      )}
      style={toneStyles.wrapper}
    >
      <span
        className={cn("h-1.5 w-1.5 flex-shrink-0 rounded-full motion-reduce:animate-none", cfg.dotClassName)}
        style={toneStyles.dot}
      />
      {label || cfg.label}
    </span>
  );
}
