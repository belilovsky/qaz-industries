import { cn } from "../utils/cn";

export interface ComparisonBarRowProps {
  label: string;
  value: number;
  maxValue: number;
  valueLabel: string;
  note?: string;
  href?: string;
  emphasis?: "default" | "focus";
  className?: string;
}

function clampPercent(value: number, maxValue: number): number {
  if (!Number.isFinite(value) || !Number.isFinite(maxValue) || maxValue <= 0) {
    return 0;
  }

  return Math.max(0, Math.min(100, (value / maxValue) * 100));
}

export function ComparisonBarRow({
  label,
  value,
  maxValue,
  valueLabel,
  note,
  href,
  emphasis = "default",
  className,
}: ComparisonBarRowProps) {
  const width = `${Math.max(6, clampPercent(value, maxValue))}%`;

  const content = (
    <>
      <div className="min-w-0">
        <div className="truncate text-sm font-semibold text-foreground">{label}</div>
        {note ? <div className="mt-1 text-[12px] leading-relaxed text-foreground/75">{note}</div> : null}
      </div>
      <div className="h-2.5 overflow-hidden rounded-full bg-muted/80">
        <div
          className={cn(
            "h-full rounded-full transition-[width,background-color] duration-200",
            emphasis === "focus" ? "bg-chart-3" : "bg-primary"
          )}
          style={{ width }}
        />
      </div>
      <div className="text-end text-[12.5px] font-semibold tabular-nums text-foreground">{valueLabel}</div>
    </>
  );

  const rowClassName = cn(
    "grid min-w-0 items-center gap-3 rounded-sm border px-3.5 py-3",
    note ? "grid-cols-[minmax(120px,0.95fr)_minmax(92px,1fr)_auto]" : "grid-cols-[minmax(120px,0.95fr)_minmax(92px,1fr)_auto]",
    emphasis === "focus"
      ? "border-[hsl(var(--chart-3)/0.45)] bg-[hsl(var(--chart-3)/0.08)]"
      : "border-border bg-card",
    href && "transition-[border-color,background-color] duration-150 hover:border-foreground/20 hover:bg-muted/20",
    className
  );

  if (href) {
    return (
      <a href={href} className={cn(rowClassName, "no-underline")}>
        {content}
      </a>
    );
  }

  return <div className={rowClassName}>{content}</div>;
}
