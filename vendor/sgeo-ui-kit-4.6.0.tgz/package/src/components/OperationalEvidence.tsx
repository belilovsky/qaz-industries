import React from "react";
import { cn } from "../utils/cn";
import { DataQualityFlag, type DataQualitySeverity } from "./DataQualityFlag";

export type EvidenceCoverageStatus = "exact" | "context" | "unknown" | "unavailable";

export interface EvidenceCoverageStateProps {
  status: EvidenceCoverageStatus;
  label: string;
  detail?: string;
  count?: number;
  className?: string;
}

const coverageSeverity: Record<EvidenceCoverageStatus, DataQualitySeverity> = {
  exact: "verified",
  context: "info",
  unknown: "unknown",
  unavailable: "warning",
};

export function EvidenceCoverageState({ status, label, detail, count, className }: EvidenceCoverageStateProps) {
  const countLabel = typeof count === "number"
    ? `${count} ${count === 1 ? "элемент" : count >= 2 && count <= 4 ? "элемента" : "элементов"}`
    : undefined;
  return (
    <div className={cn("min-w-0", className)} data-evidence-coverage={status}>
      <DataQualityFlag
        compact
        severity={coverageSeverity[status]}
        label={label}
        detail={[countLabel, detail].filter(Boolean).join(" · ") || undefined}
      />
    </div>
  );
}

export interface MethodDisclosureItem {
  label: string;
  value: React.ReactNode;
}

export interface MethodDisclosureProps {
  title?: string;
  items: MethodDisclosureItem[];
  href?: string;
  linkLabel?: string;
  className?: string;
}

export function MethodDisclosure({
  title = "Методика",
  items,
  href,
  linkLabel = "Полная методика",
  className,
}: MethodDisclosureProps) {
  return (
    <section className={cn("min-w-0 border-t border-border pt-3", className)} aria-label={title}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-[12px] font-semibold leading-snug text-foreground">{title}</h3>
        {href ? (
          <a className="text-[12px] font-medium text-primary underline-offset-4 hover:underline" href={href}>
            {linkLabel}
          </a>
        ) : null}
      </div>
      <dl className="mt-2 grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
        {items.map((item) => (
          <div className="grid min-w-0 grid-cols-[minmax(6rem,0.45fr)_minmax(0,1fr)] gap-2" key={item.label}>
            <dt className="text-[11px] leading-snug text-muted-foreground">{item.label}</dt>
            <dd className="min-w-0 break-words text-[11px] font-medium leading-snug text-foreground">{item.value}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

/**
 * Нейтральная полоса для короткого объяснения правила: норма, запрет и явно
 * зафиксированное исключение. Семантика самих правил всегда остаётся у продукта.
 */
export type RuleStatus = "norm" | "prohibited" | "exception" | "context";

export interface RuleStatusItem {
  status: RuleStatus;
  label: string;
  value: React.ReactNode;
  detail?: React.ReactNode;
}

export interface RuleStatusStripProps {
  title?: string;
  items: RuleStatusItem[];
  className?: string;
}

const ruleStatusTone: Record<RuleStatus, DataQualitySeverity> = {
  norm: "verified",
  prohibited: "critical",
  exception: "info",
  context: "unknown",
};

export function RuleStatusStrip({ title = "Правило", items, className }: RuleStatusStripProps) {
  return (
    <section className={cn("min-w-0", className)} aria-label={title} data-rule-status-strip="true">
      <h3 className="sr-only">{title}</h3>
      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {items.map((item) => (
          <article className="grid min-w-0 gap-2 border border-border bg-card p-3" data-rule-status={item.status} key={`${item.status}-${item.label}`}>
            <DataQualityFlag compact severity={ruleStatusTone[item.status]} label={item.label} />
            <div className="min-w-0 text-base font-semibold leading-tight text-foreground">{item.value}</div>
            {item.detail ? <p className="text-[12px] leading-relaxed text-muted-foreground">{item.detail}</p> : null}
          </article>
        ))}
      </div>
    </section>
  );
}

/**
 * Набор независимых временных меток. Он не вычисляет свежесть сам и потому
 * подходит для разных доменов без скрытых порогов и интерпретаций.
 */
export type FreshnessLedgerState = "fresh" | "aging" | "stale" | "unknown";

export interface FreshnessLedgerItem {
  label: string;
  value: React.ReactNode;
  detail?: React.ReactNode;
  state?: FreshnessLedgerState;
}

export interface FreshnessLedgerProps {
  title?: string;
  items: FreshnessLedgerItem[];
  className?: string;
}

const freshnessLedgerTone: Record<FreshnessLedgerState, DataQualitySeverity> = {
  fresh: "verified",
  aging: "warning",
  stale: "critical",
  unknown: "unknown",
};

export function FreshnessLedger({ title = "Актуальность", items, className }: FreshnessLedgerProps) {
  return (
    <section className={cn("min-w-0", className)} aria-label={title} data-freshness-ledger="true">
      <h3 className="sr-only">{title}</h3>
      <dl className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {items.map((item) => {
          const state = item.state ?? "unknown";
          return (
            <div className="grid min-w-0 gap-1 border border-border bg-card p-3" data-freshness-ledger-state={state} key={`${item.label}-${state}`}>
              <dt><DataQualityFlag compact severity={freshnessLedgerTone[state]} label={item.label} /></dt>
              <dd className="min-w-0 font-mono text-sm font-semibold tabular-nums text-foreground">{item.value}</dd>
              {item.detail ? <dd className="text-[12px] leading-relaxed text-muted-foreground">{item.detail}</dd> : null}
            </div>
          );
        })}
      </dl>
    </section>
  );
}

export type InspectionPriority = "high" | "medium" | "low";

export interface InspectionPrioritySummaryProps {
  priority: InspectionPriority;
  score?: number | null;
  counts: Record<InspectionPriority, number>;
  reasons?: string[];
  methodHref?: string;
  disclaimer?: string;
  className?: string;
}

const priorityLabels: Record<InspectionPriority, string> = { high: "Высокий", medium: "Средний", low: "Низкий" };

export function InspectionPrioritySummary({
  priority,
  score,
  counts,
  reasons = [],
  methodHref,
  disclaimer = "Приоритет в рабочей очереди, а не оценка.",
  className,
}: InspectionPrioritySummaryProps) {
  return (
    <section className={cn("min-w-0", className)} aria-label="Приоритет проверки" data-priority={priority}>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] font-medium text-muted-foreground">Приоритет проверки</p>
          <p className="mt-0.5 text-lg font-semibold leading-none text-foreground">{priorityLabels[priority]}</p>
        </div>
        {typeof score === "number" ? (
          <p className="text-end text-[11px] text-muted-foreground">
            Оценка <strong className="block text-base font-semibold text-foreground">{score}</strong>
          </p>
        ) : null}
      </div>
      <dl className="mt-3 grid grid-cols-3 divide-x divide-border border-y border-border py-2">
        {(["high", "medium", "low"] as const).map((band) => (
          <div className="px-2 first:ps-0 last:pe-0" key={band}>
            <dt className="text-[10px] uppercase leading-none text-muted-foreground">{priorityLabels[band]}</dt>
            <dd className="mt-1 text-sm font-semibold tabular-nums text-foreground">{counts[band]}</dd>
          </div>
        ))}
      </dl>
      {reasons.length ? (
        <ul className="mt-3 space-y-1 text-[12px] leading-relaxed text-foreground/85">
          {reasons.map((reason) => <li key={reason}>• {reason}</li>)}
        </ul>
      ) : null}
      <p className="mt-3 text-[10px] leading-relaxed text-muted-foreground">
        {disclaimer}{methodHref ? <> <a className="font-medium text-primary underline-offset-4 hover:underline" href={methodHref}>Методика</a></> : null}
      </p>
    </section>
  );
}

export interface DataQualityDimension {
  id: string;
  label: string;
  severity: DataQualitySeverity;
  detail?: string;
}

export interface DataQualityScorecardProps {
  title?: string;
  dimensions: DataQualityDimension[];
  className?: string;
}

export function DataQualityScorecard({ title = "Качество данных", dimensions, className }: DataQualityScorecardProps) {
  return (
    <section className={cn("min-w-0", className)} aria-label={title}>
      <h3 className="text-[12px] font-semibold leading-snug text-foreground">{title}</h3>
      <div className="mt-2 grid gap-2 sm:grid-cols-2">
        {dimensions.map((dimension) => (
          <DataQualityFlag
            key={dimension.id}
            severity={dimension.severity}
            label={dimension.label}
            detail={dimension.detail}
          />
        ))}
      </div>
    </section>
  );
}

export interface CoverageMatrixCell {
  columnId: string;
  status: EvidenceCoverageStatus;
  label: string;
}

export interface CoverageMatrixRow {
  id: string;
  label: string;
  cells: CoverageMatrixCell[];
}

export interface CoverageMatrixProps {
  caption: string;
  columns: Array<{ id: string; label: string }>;
  rows: CoverageMatrixRow[];
  className?: string;
}

export function CoverageMatrix({ caption, columns, rows, className }: CoverageMatrixProps) {
  return (
    <div
      className={cn("max-w-full overflow-x-auto focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35", className)}
      tabIndex={0}
      role="group"
      aria-label={caption}
    >
      <table className="w-full min-w-[36rem] border-collapse text-start text-[11px]">
        <caption className="sr-only">{caption}</caption>
        <thead>
          <tr className="border-b border-border text-muted-foreground">
            <th className="px-2 py-2 text-start font-medium" scope="col">Объект</th>
            {columns.map((column) => <th className="px-2 py-2 text-start font-medium" key={column.id} scope="col">{column.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr className="border-b border-border/70 last:border-b-0" key={row.id}>
              <th className="px-2 py-2 text-start font-semibold text-foreground" scope="row">{row.label}</th>
              {columns.map((column) => {
                const cell = row.cells.find((candidate) => candidate.columnId === column.id);
                return (
                  <td className="px-2 py-2" data-coverage={cell?.status ?? "unknown"} key={column.id}>
                    {cell?.label ?? "Неизвестно"}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export interface ReleaseProofProps {
  releaseId: string;
  sourceRevision: string;
  rollbackRevision?: string;
  status: "ready" | "deployed" | "failed" | "unknown";
  artifactCount?: number;
  checks?: string[];
  verifiedAt?: string;
  className?: string;
}

export function ReleaseProof({
  releaseId,
  sourceRevision,
  rollbackRevision,
  status,
  artifactCount,
  checks = [],
  verifiedAt,
  className,
}: ReleaseProofProps) {
  return (
    <section className={cn("min-w-0", className)} aria-label="Подтверждение выпуска" data-release-status={status}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-[12px] font-semibold text-foreground">Выпуск {releaseId}</h3>
        <span className="text-[11px] font-medium text-muted-foreground">{status}</span>
      </div>
      <dl className="mt-2 grid gap-1 text-[11px] sm:grid-cols-2">
        <div><dt className="inline text-muted-foreground">Исходный код: </dt><dd className="inline font-mono text-foreground">{sourceRevision}</dd></div>
        {rollbackRevision ? <div><dt className="inline text-muted-foreground">Резервная версия: </dt><dd className="inline font-mono text-foreground">{rollbackRevision}</dd></div> : null}
        {typeof artifactCount === "number" ? <div><dt className="inline text-muted-foreground">Материалы: </dt><dd className="inline text-foreground">{artifactCount}</dd></div> : null}
        {verifiedAt ? <div><dt className="inline text-muted-foreground">Проверено: </dt><dd className="inline text-foreground">{verifiedAt}</dd></div> : null}
      </dl>
      {checks.length ? <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">Проверки: {checks.join(", ")}</p> : null}
    </section>
  );
}

export interface PolicyChangeReceiptProps {
  policy: string;
  currentVersion: string;
  proposedVersion?: string;
  status: "pending" | "approved" | "rejected" | "active";
  evidence?: string;
  actor?: string;
  className?: string;
}

export function PolicyChangeReceipt({ policy, currentVersion, proposedVersion, status, evidence, actor, className }: PolicyChangeReceiptProps) {
  return (
    <section className={cn("min-w-0 border-s-2 border-primary ps-3", className)} aria-label="Изменение правила" data-policy-status={status}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-[12px] font-semibold text-foreground">{policy}</h3>
        <span className="text-[11px] font-medium text-muted-foreground">{status}</span>
      </div>
      <p className="mt-1 text-[11px] text-foreground">
        {currentVersion}{proposedVersion ? ` → ${proposedVersion}` : ""}
      </p>
      {evidence ? <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">{evidence}</p> : null}
      {actor ? <p className="mt-1 text-[10px] text-muted-foreground">Ответственный: {actor}</p> : null}
    </section>
  );
}

export interface MapLayerToggle {
  id: string;
  label: string;
  enabled: boolean;
  available?: boolean;
  count?: number;
}

export interface MapLayerToggleGroupProps {
  label: string;
  layers: MapLayerToggle[];
  onToggle?: (id: string, enabled: boolean) => void;
  className?: string;
}

export function MapLayerToggleGroup({ label, layers, onToggle, className }: MapLayerToggleGroupProps) {
  return (
    <div className={cn("flex flex-wrap gap-1.5", className)} role="group" aria-label={label}>
      {layers.map((layer) => {
        const available = layer.available !== false;
        return (
          <button
            aria-pressed={layer.enabled}
            className="min-h-9 rounded-sm border border-border px-2.5 py-1.5 text-[11px] font-medium text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 disabled:cursor-not-allowed disabled:opacity-50"
            data-state={layer.enabled ? "active" : "inactive"}
            disabled={!available}
            key={layer.id}
            onClick={() => onToggle?.(layer.id, !layer.enabled)}
            type="button"
          >
            {layer.label}{typeof layer.count === "number" ? ` (${layer.count})` : ""}
          </button>
        );
      })}
    </div>
  );
}
