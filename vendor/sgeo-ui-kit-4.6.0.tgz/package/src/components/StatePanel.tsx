import type { LucideIcon } from "lucide-react";
import { AlertCircle, CheckCircle2, Inbox, Info, TriangleAlert } from "lucide-react";
import { AccentCard, type AccentVariant } from "./AccentCard";
import { cn } from "../utils/cn";

export type StatePanelTone = "neutral" | "info" | "success" | "warning" | "danger" | "error";

export interface StatePanelAction {
  label: string;
  href?: string;
  onClick?: () => void;
}

export interface StatePanelProps {
  title: string;
  message?: string;
  tone?: StatePanelTone;
  icon?: LucideIcon;
  compact?: boolean;
  action?: StatePanelAction;
  className?: string;
}

const iconByTone: Record<StatePanelTone, LucideIcon> = {
  neutral: Inbox,
  info: Info,
  success: CheckCircle2,
  warning: TriangleAlert,
  danger: AlertCircle,
  error: AlertCircle,
};

const accentByTone: Record<StatePanelTone, AccentVariant> = {
  neutral: "neutral",
  info: "primary",
  success: "green",
  warning: "amber",
  danger: "red",
  error: "red",
};

export function StatePanel({
  title,
  message,
  tone = "neutral",
  icon,
  compact = false,
  action,
  className,
}: StatePanelProps) {
  const Icon = icon ?? iconByTone[tone];
  const actionNode = action?.href ? (
    <a
      href={action.href}
      className="inline-flex min-h-8 items-center justify-center rounded-sm border border-border bg-background px-3 py-1 text-[12px] font-medium text-foreground no-underline transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
    >
      {action.label}
    </a>
  ) : action?.onClick ? (
    <button
      type="button"
      onClick={action.onClick}
      className="inline-flex min-h-8 items-center justify-center rounded-sm border border-border bg-background px-3 py-1 text-[12px] font-medium text-foreground transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
    >
      {action.label}
    </button>
  ) : null;

  return (
    <AccentCard
      variant={accentByTone[tone]}
      className={cn("rounded-sm", compact ? "px-3.5 py-3" : "px-4 py-4 sm:px-5", className)}
    >
      <div className={cn("flex items-start", compact ? "gap-3" : "gap-4")}>
        <div className="flex h-7 w-7 shrink-0 items-center justify-center text-muted-foreground">
          <Icon className="h-4.5 w-4.5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className={cn("font-semibold leading-snug text-foreground", compact ? "text-[15px]" : "text-base sm:text-lg")}>{title}</div>
          {message ? (
            <p className={cn("mt-1 text-muted-foreground", compact ? "text-[12px] leading-[1.55]" : "text-sm leading-[1.62]")}>{message}</p>
          ) : null}
          {actionNode ? <div className="mt-3">{actionNode}</div> : null}
        </div>
      </div>
    </AccentCard>
  );
}
