import { type ReactNode } from "react";
import { AccentCard } from "./AccentCard";
import { cn } from "../utils/cn";

export interface DocumentCardMetaItem {
  label?: string;
  value: ReactNode;
}

export interface DocumentCardProps {
  eyebrow?: string;
  title: string;
  href?: string;
  summary?: string;
  quote?: string;
  metaItems?: DocumentCardMetaItem[];
  footer?: ReactNode;
  className?: string;
}

function DocumentCardMeta({ items }: { items: DocumentCardMetaItem[] }) {
  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] leading-[1.45] text-muted-foreground">
      {items.map((item, index) => (
        <div key={`${String(item.label)}-${index}`} className="inline-flex items-center gap-1.5">
          {item.label ? <span className="text-muted-foreground/80">{item.label}</span> : null}
          <span className="font-medium text-foreground/88">{item.value}</span>
        </div>
      ))}
    </div>
  );
}

export function DocumentCard({
  eyebrow,
  title,
  href,
  summary,
  quote,
  metaItems,
  footer,
  className,
}: DocumentCardProps) {
  const titleNode = href ? (
    <a
      href={href}
      className="inline-flex items-start rounded-sm text-foreground no-underline transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
    >
      {title}
    </a>
  ) : (
    title
  );

  return (
    <AccentCard variant="none" className={cn("rounded-sm p-4 sm:p-5", className)}>
      <div className="flex flex-col gap-3">
        {eyebrow || metaItems?.length ? (
          <div className="flex flex-col gap-2">
            {eyebrow ? (
              <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
                {eyebrow}
              </div>
            ) : null}
            {metaItems?.length ? <DocumentCardMeta items={metaItems} /> : null}
          </div>
        ) : null}

        <div className="text-lg font-semibold leading-snug text-foreground sm:text-[1.18rem]">{titleNode}</div>

        {summary ? <p className="text-sm leading-[1.62] text-muted-foreground">{summary}</p> : null}

        {quote ? (
          <blockquote className="rounded-sm bg-muted/35 px-3.5 py-3 text-[14px] leading-[1.62] text-foreground/92">
            {quote}
          </blockquote>
        ) : null}

        {footer ? <div className="pt-1 text-[12px] leading-[1.5] text-muted-foreground">{footer}</div> : null}
      </div>
    </AccentCard>
  );
}
