import React from "react";
import { cn } from "../utils/cn";

export type MetricCardDensity = "default" | "compact";

export interface MetricCardProps {
  /** Дополнительная иконка или акцентный знак */
  icon?: React.ReactNode;
  /** Подпись метрики */
  label: string;
  /** Основное значение */
  value: string | number;
  /** Поясняющий текст ниже */
  subtext?: string;
  /** Выравнивание содержимого */
  align?: "start" | "center";
  /** Тихий или акцентный тон */
  tone?: "default" | "accent";
  /** Плотность вторичного фактологического ряда */
  density?: MetricCardDensity;
  className?: string;
}

export function MetricCard({
  icon,
  label,
  value,
  subtext,
  align = "start",
  tone = "default",
  density = "default",
  className,
}: MetricCardProps) {
  const isCentered = align === "center";
  const isCompact = density === "compact";

  return (
    <section
      data-density={density}
      className={cn(
        "grid rounded-sm border border-border/80 bg-card",
        isCompact ? "gap-1.5 px-3 py-3" : "gap-2 px-4 py-4",
        tone === "accent" && "border-primary/25 bg-[hsl(var(--primary))/0.025]",
        isCentered ? "justify-items-center text-center" : "justify-items-start text-start",
        className
      )}
    >
      <div className={cn("flex items-center", isCompact ? "gap-1.5" : "gap-2", isCentered && "justify-center")}>
        {icon ? <span className="text-muted-foreground">{icon}</span> : null}
        <span className="text-[10px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">{label}</span>
      </div>
      <strong className={cn("font-semibold leading-none text-foreground", isCompact ? "text-xl" : "text-[1.625rem]")}>{value}</strong>
      {subtext ? (
        <span className={cn("text-muted-foreground", isCompact ? "text-[11px] leading-[1.4]" : "text-[12.5px] leading-[1.45]")}>{subtext}</span>
      ) : null}
    </section>
  );
}
