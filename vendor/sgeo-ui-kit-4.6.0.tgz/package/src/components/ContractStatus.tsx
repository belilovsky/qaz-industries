import { cn } from "../utils/cn";
import { DataFreshness } from "./DataFreshness";
import { DataQualityFlag, type DataQualitySeverity } from "./DataQualityFlag";

export type ContractConnectivity = "connected" | "degraded" | "offline" | "unknown";
export type ContractAdoption = "live" | "staging" | "documented" | "unknown";

export interface ContractStatusProps {
  name: string;
  connectivity: ContractConnectivity;
  adoption?: ContractAdoption;
  version?: string;
  schemaVersion?: string;
  updatedAt?: string | number | Date | null;
  now?: string | number | Date;
  issues?: string[];
  className?: string;
}

const connectivityLabel: Record<ContractConnectivity, string> = {
  connected: "Контракт доступен",
  degraded: "Доступ ограничен",
  offline: "Контракт недоступен",
  unknown: "Состояние неизвестно",
};
const connectivityQuality: Record<ContractConnectivity, DataQualitySeverity> = {
  connected: "verified", degraded: "warning", offline: "critical", unknown: "unknown",
};
const adoptionLabel: Record<ContractAdoption, string> = {
  live: "используется в рабочей среде",
  staging: "проверяется в испытательной среде",
  documented: "контракт описан, внедрение не подтверждено",
  unknown: "статус внедрения не указан",
};

export function ContractStatus({
  name, connectivity, adoption = "unknown", version, schemaVersion, updatedAt, now, issues = [], className,
}: ContractStatusProps) {
  return (
    <section className={cn("min-w-0 rounded-sm border border-border/80 bg-card", className)} aria-label={`${name}: состояние контракта`}>
      <div className="flex flex-wrap items-start justify-between gap-3 px-3.5 py-3">
        <div className="min-w-0">
          <h3 className="text-[13px] font-semibold leading-snug text-foreground">{name}</h3>
          <p className="mt-0.5 text-[11px] leading-[1.45] text-muted-foreground">{adoptionLabel[adoption]}</p>
        </div>
        <DataQualityFlag severity={connectivityQuality[connectivity]} label={connectivityLabel[connectivity]} compact />
      </div>
      <dl className="grid border-t border-border/70 text-[11px] sm:grid-cols-3">
        <div className="px-3.5 py-2.5"><dt className="text-muted-foreground">Версия</dt><dd className="mt-0.5 font-mono font-medium text-foreground">{version ?? "не указана"}</dd></div>
        <div className="border-t border-border/70 px-3.5 py-2.5 sm:border-s sm:border-t-0"><dt className="text-muted-foreground">Схема</dt><dd className="mt-0.5 break-all font-mono font-medium text-foreground">{schemaVersion ?? "не указана"}</dd></div>
        <div className="border-t border-border/70 px-3.5 py-2.5 sm:border-s sm:border-t-0"><dt className="mb-1 text-muted-foreground">Проверено</dt><dd><DataFreshness timestamp={updatedAt} now={now} freshForMinutes={360} staleAfterMinutes={1_440} appearance="plain" /></dd></div>
      </dl>
      {issues.length > 0 ? <ul className="space-y-1 border-t border-border/70 px-3.5 py-2.5 text-[11px] leading-[1.45] text-muted-foreground">{issues.map((issue) => <li key={issue}>• {issue}</li>)}</ul> : null}
    </section>
  );
}
