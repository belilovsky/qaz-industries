import { cn } from "../utils/cn";

export interface CompactCompareRow {
  label: string;
  value: number;
  valueLabel: string;
  href?: string;
  ariaLabel?: string;
}

export interface CompactCompareCardProps {
  eyebrow?: string;
  title: string;
  summary?: string;
  rows: CompactCompareRow[];
  footerNote?: string;
  className?: string;
}

function CompareRow({ row, maxValue }: { row: CompactCompareRow; maxValue: number }) {
  const width = `${Math.max(8, (row.value / maxValue) * 100)}%`;

  const content = (
    <>
      <span className="truncate text-foreground/92">{row.label}</span>
      <span className="h-2 overflow-hidden rounded-full bg-muted/70" aria-hidden="true">
        <i
          className="block h-full rounded-full bg-primary"
          style={{ width }}
        />
      </span>
      <strong className="text-end text-[12px] font-semibold text-primary">{row.valueLabel}</strong>
    </>
  );

  const rowClassName = cn(
    "grid grid-cols-[minmax(84px,0.95fr)_minmax(72px,1fr)_auto] items-center gap-2 text-[12px]",
    row.href
      ? "rounded-sm px-1 py-1 transition-colors hover:bg-muted/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      : ""
  );

  if (row.href) {
    return (
      <a href={row.href} aria-label={row.ariaLabel} className={cn(rowClassName, "no-underline")}>
        {content}
      </a>
    );
  }

  return <div className={rowClassName}>{content}</div>;
}

export function CompactCompareCard({
  eyebrow = "сравнение",
  title,
  summary,
  rows,
  footerNote,
  className,
}: CompactCompareCardProps) {
  const maxValue = Math.max(...rows.map((row) => row.value), 1);

  return (
    <section
      className={cn(
        "min-w-0 rounded-sm border border-border bg-card px-4 py-4 sm:px-5",
        className
      )}
    >
      <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">{eyebrow}</div>
      <h3 className="mt-2 text-lg font-semibold leading-tight text-foreground">{title}</h3>
      {summary ? <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{summary}</p> : null}
      <div className="mt-4 grid gap-2.5">
        {rows.map((row, index) => (
          <CompareRow key={`${row.label}-${index}`} row={row} maxValue={maxValue} />
        ))}
      </div>
      {footerNote ? <div className="mt-3 text-[12px] leading-relaxed text-muted-foreground">{footerNote}</div> : null}
    </section>
  );
}
