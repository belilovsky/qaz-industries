import React from "react";
import { cn } from "../utils/cn";
import { DataQualityFlag, type DataQualitySeverity } from "./DataQualityFlag";

export type CollectorRunStatus = "queued" | "running" | "completed" | "partial" | "failed";

export interface CollectorRunProps {
  name: string;
  status: CollectorRunStatus;
  processed?: number;
  total?: number;
  startedAt?: string;
  duration?: string;
  detail?: string;
  action?: React.ReactNode;
  className?: string;
}

const runStatus: Record<CollectorRunStatus, { severity: DataQualitySeverity; label: string }> = {
  queued: { severity: "unknown", label: "В очереди" },
  running: { severity: "info", label: "Выполняется" },
  completed: { severity: "verified", label: "Завершён" },
  partial: { severity: "warning", label: "Завершён частично" },
  failed: { severity: "critical", label: "Ошибка" },
};

export function CollectorRun({ name, status, processed, total, startedAt, duration, detail, action, className }: CollectorRunProps) {
  const state = runStatus[status];
  const safeTotal = total && total > 0 ? total : null;
  const completion = safeTotal == null ? null : Math.min(100, Math.max(0, ((processed ?? 0) / safeTotal) * 100));

  return (
    <section className={cn("rounded-sm border border-border/80 bg-card px-3.5 py-3", className)} aria-label={`${name}: запуск коллектора`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="text-[13px] font-semibold leading-snug text-foreground">{name}</h3>
          {detail ? <p className="mt-0.5 text-[11px] leading-[1.45] text-muted-foreground">{detail}</p> : null}
        </div>
        <DataQualityFlag severity={state.severity} label={state.label} compact />
      </div>
      <div className="mt-3 grid items-end gap-3 sm:grid-cols-[minmax(0,1fr)_auto]">
        <div className="min-w-0">
          <div className="flex items-center justify-between gap-3 font-mono text-[10px] tabular-nums text-muted-foreground">
            <span>{processed?.toLocaleString("ru") ?? "–"}{safeTotal ? ` / ${safeTotal.toLocaleString("ru")}` : ""}</span>
            <span>{completion == null ? "без общего объёма" : `${Math.round(completion)}%`}</span>
          </div>
          {completion != null ? (
            <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-muted" aria-label={`Выполнено ${Math.round(completion)}%`} role="progressbar" aria-valuenow={Math.round(completion)} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-full bg-primary transition-[width]" style={{ width: `${completion}%` }} />
            </div>
          ) : null}
          {startedAt || duration ? <p className="mt-2 text-[10px] text-muted-foreground">{[startedAt, duration].filter(Boolean).join(" · ")}</p> : null}
        </div>
        {action ? <div className="shrink-0">{action}</div> : null}
      </div>
    </section>
  );
}
