import { cn } from "../utils/cn";

/**
 * Стилизованная таблица данных в базовом operational-слое AV DS 4.
 * Заголовки: text-[11px] uppercase tracking-wider font-semibold
 */

export interface DataTableColumn<T> {
  /** Уникальный ключ колонки */
  key: string;
  /** Заголовок */
  header: string;
  /** Выравнивание */
  align?: "left" | "center" | "right";
  /** Ширина CSS */
  width?: string;
  /** Пользовательская отрисовка ячейки */
  render?: (row: T, index: number) => React.ReactNode;
  /** Ключ для доступа к данным (по умолчанию = key) */
  accessor?: keyof T;
}

export interface DataTableProps<T> {
  columns: DataTableColumn<T>[];
  data: T[];
  /** Сообщение при пустом массиве */
  emptyMessage?: string;
  /** CSS-классы для обёртки */
  className?: string;
  /** Клик по строке */
  onRowClick?: (row: T, index: number) => void;
  /** Компактный режим */
  compact?: boolean;
}

function getCellValue<T extends object>(row: T, column: DataTableColumn<T>): unknown {
  return Reflect.get(row, column.accessor ?? column.key);
}

export function DataTable<T extends object>({
  columns,
  data,
  emptyMessage = "Нет данных",
  className,
  onRowClick,
  compact = false,
}: DataTableProps<T>) {
  const alignMap = { left: "text-start", center: "text-center", right: "text-end" };

  return (
    <div
      className={cn("overflow-x-auto rounded-sm border border-border/80 bg-card focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35", className)}
      tabIndex={0}
      role="group"
      aria-label="Прокручиваемая таблица данных"
    >
      <table className="w-full">
        <thead>
          <tr className="border-b border-border bg-muted/20">
            {columns.map((col) => (
              <th
                key={col.key}
                className={cn(
                  "text-[11px] font-semibold uppercase tracking-[0.08em] text-muted-foreground",
                  compact ? "px-3 py-2" : "px-4 py-3",
                  alignMap[col.align || "left"]
                )}
                style={col.width ? { width: col.width } : undefined}
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border/50">
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="text-center py-8 text-sm text-muted-foreground">
                {emptyMessage}
              </td>
            </tr>
          ) : (
            data.map((row, idx) => (
              <tr
                key={idx}
                className={cn(
                  "transition-colors odd:bg-background/40",
                  onRowClick && "cursor-pointer hover:bg-muted/20"
                )}
                onClick={() => onRowClick?.(row, idx)}
              >
                {columns.map((col) => (
                  <td
                    key={col.key}
                    className={cn(
                      "text-sm text-foreground",
                      compact ? "px-3 py-2" : "px-4 py-3",
                      alignMap[col.align || "left"]
                    )}
                  >
                    {col.render
                      ? col.render(row, idx)
                      : String(getCellValue(row, col) ?? "–")}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
