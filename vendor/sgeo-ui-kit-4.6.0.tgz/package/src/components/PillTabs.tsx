import React from "react";
import { cn } from "../utils/cn";

/**
 * Pill-табы для навигационного слоя AV DS 4
 * Компактный сегментированный ряд с явным активным состоянием.
 */

export interface PillTab {
  value: string;
  label: string;
  icon?: React.ReactNode;
  count?: number;
  href?: string;
  target?: string;
  rel?: string;
  ariaLabel?: string;
}

export interface PillTabsProps {
  tabs: PillTab[];
  value: string;
  onChange?: (value: string) => void;
  /** Дополнительные CSS-классы для контейнера */
  className?: string;
  /** Размер табов */
  size?: "sm" | "md";
  /** Поведение контейнера на узких экранах */
  overflow?: "wrap" | "scroll";
}

export function PillTabs({ tabs, value, onChange, className, size = "md", overflow = "wrap" }: PillTabsProps) {
  return (
    <div
      className={cn(
        "inline-flex gap-0.5 rounded-sm border border-border/80 bg-muted/35 p-0.5",
        overflow === "wrap" ? "flex-wrap" : "max-w-full flex-nowrap overflow-x-auto overscroll-x-contain whitespace-nowrap scrollbar-none [-ms-overflow-style:none] [scrollbar-width:none]",
        className
      )}
    >
      {tabs.map((tab) => (
        tab.href ? (
          <a
            key={tab.value}
            href={tab.href}
            target={tab.target}
            rel={tab.rel}
            aria-label={tab.ariaLabel}
            aria-current={value === tab.value ? "page" : undefined}
            className={cn(
              "inline-flex items-center gap-1.5 whitespace-nowrap rounded-sm border border-transparent font-medium transition-[background-color,border-color,color] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
              size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-xs",
              value === tab.value
                ? "border-border/70 bg-background text-foreground"
                : "text-foreground/75 hover:bg-background/70 hover:text-foreground"
            )}
          >
            {tab.icon}
            {tab.label}
            {tab.count !== undefined && (
              <span
                className={cn(
                  "min-w-[18px] rounded-full px-1.5 py-0.5 text-center text-[10px] font-semibold tabular-nums",
                  value === tab.value ? "bg-muted text-foreground" : "bg-background/80 text-muted-foreground"
                )}
              >
                {tab.count}
              </span>
            )}
          </a>
        ) : (
          <button
            key={tab.value}
            type="button"
            onClick={() => onChange?.(tab.value)}
            aria-label={tab.ariaLabel}
            className={cn(
              "inline-flex items-center gap-1.5 whitespace-nowrap rounded-sm border border-transparent font-medium transition-[background-color,border-color,color] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
              size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-xs",
              value === tab.value
                ? "border-border/70 bg-background text-foreground"
                : "text-foreground/75 hover:bg-background/70 hover:text-foreground"
            )}
          >
            {tab.icon}
            {tab.label}
            {tab.count !== undefined && (
              <span
                className={cn(
                  "min-w-[18px] rounded-full px-1.5 py-0.5 text-center text-[10px] font-semibold tabular-nums",
                  value === tab.value ? "bg-muted text-foreground" : "bg-background/80 text-muted-foreground"
                )}
              >
                {tab.count}
              </span>
            )}
          </button>
        )
      ))}
    </div>
  );
}
