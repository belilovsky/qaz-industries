import { cn } from "../utils/cn";

/**
 * Горизонтальный индикатор оценки с анимацией (0–100).
 */

export interface ScoreBarProps {
  /** Значение 0–100 */
  value: number;
  /** Максимум (по умолчанию 100) */
  max?: number;
  /** Цвет полосы (CSS color) */
  color?: string;
  /** Функция определения цвета */
  getColor?: (value: number) => string;
  /** Анимировать появление */
  animate?: boolean;
  /** Подпись слева */
  label?: string;
  /** Показать числовое значение */
  showValue?: boolean;
  /** Форматирование отображаемого значения справа */
  valueFormatter?: (value: number, max: number) => string;
  className?: string;
}

function defaultColor(v: number): string {
  if (v >= 70) return "hsl(var(--chart-2))";
  if (v >= 40) return "hsl(var(--chart-3))";
  return "hsl(var(--destructive))";
}

export function ScoreBar({
  value, max = 100, color, getColor, animate = true, label, showValue = true, valueFormatter, className,
}: ScoreBarProps) {
  const safeValue = Number.isFinite(value) ? value : 0;
  const safeMax = Number.isFinite(max) && max > 0 ? max : 100;
  const pct = Number.isFinite(value) && Number.isFinite(max) && max > 0
    ? Math.max(0, Math.min((safeValue / safeMax) * 100, 100))
    : 0;
  const resolvedColor = color || (getColor || defaultColor)(pct);
  const displayValue = valueFormatter ? valueFormatter(safeValue, safeMax) : String(Math.round(safeValue));

  return (
    <div
      className={cn("flex items-center gap-3", className)}
      role="meter"
      aria-label={label ?? "Оценка"}
      aria-valuemin={0}
      aria-valuemax={safeMax}
      aria-valuenow={Math.max(0, Math.min(safeValue, safeMax))}
      aria-valuetext={displayValue}
    >
      {label && (
        <span className="min-w-[80px] whitespace-nowrap text-[11px] font-medium tracking-[0.01em] text-muted-foreground">{label}</span>
      )}
      <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted/80">
        <div
          className={cn("h-full rounded-full", animate && "animate-barGrow")}
          style={{
            width: `${pct}%`,
            background: resolvedColor,
            transformOrigin: "left",
          }}
        />
      </div>
      {showValue && (
        <span className="min-w-[32px] text-end text-[11px] font-semibold tabular-nums text-foreground">
          {displayValue}
        </span>
      )}
    </div>
  );
}
