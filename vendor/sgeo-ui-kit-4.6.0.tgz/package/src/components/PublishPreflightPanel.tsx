import { type ReactNode } from "react";
import { cn } from "../utils/cn";

export type PublishPreflightStatus = "ready" | "blocked" | "published";

export interface PublishPreflightCheck {
  id: string;
  name: string;
  ok: boolean;
  detail?: string;
}

export interface PublishPreflightMetric {
  label: string;
  value: ReactNode;
  note?: string;
}

export interface PublishPreflightPanelProps {
  title?: string;
  status: PublishPreflightStatus;
  statusLabel?: string;
  summary?: ReactNode;
  metrics?: PublishPreflightMetric[];
  checks: PublishPreflightCheck[];
  className?: string;
}

const panelToneClassName: Record<PublishPreflightStatus, string> = {
  ready: "border-[hsl(var(--chart-2)/0.35)] bg-[hsl(var(--chart-2)/0.05)]",
  blocked: "border-[hsl(var(--chart-3)/0.4)] bg-[hsl(var(--chart-3)/0.06)]",
  published: "border-primary/45 bg-primary/[0.05]",
};

const badgeToneClassName: Record<PublishPreflightStatus, string> = {
  ready: "border-[hsl(var(--chart-2)/0.35)] bg-[hsl(var(--chart-2)/0.12)] text-foreground",
  blocked: "border-[hsl(var(--chart-3)/0.45)] bg-[hsl(var(--chart-3)/0.12)] text-foreground",
  published: "border-primary/45 bg-primary/[0.1] text-primary",
};

const defaultStatusLabels: Record<PublishPreflightStatus, string> = {
  ready: "Готово к публикации",
  blocked: "Есть блокирующие проверки",
  published: "Уже опубликовано",
};

export function PublishPreflightPanel({
  title = "Предпроверка публикации",
  status,
  statusLabel,
  summary,
  metrics,
  checks,
  className,
}: PublishPreflightPanelProps) {
  return (
    <section
      className={cn("min-w-0 border p-4 sm:p-5", panelToneClassName[status], className)}
      data-publish-preflight={status}
    >
      <div className="flex min-w-0 flex-col gap-4">
        <div className="flex min-w-0 flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0">
            <div className="text-lg font-semibold leading-snug text-foreground">{title}</div>
            {summary ? <div className="mt-1 text-sm leading-[1.6] text-foreground/90">{summary}</div> : null}
          </div>
          <span
            className={cn(
              "inline-flex shrink-0 items-center border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.06em]",
              badgeToneClassName[status]
            )}
          >
            {statusLabel ?? defaultStatusLabels[status]}
          </span>
        </div>

        {metrics?.length ? (
          <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
            {metrics.map((metric, index) => (
              <div key={`${metric.label}-${index}`} className="min-w-0 border-t border-border/70 pt-2.5">
                <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-foreground/80">
                  {metric.label}
                </div>
                <div className="mt-1 text-base font-semibold leading-snug text-foreground">{metric.value}</div>
                {metric.note ? (
                  <div className="mt-1 text-[12px] leading-[1.5] text-foreground/90">{metric.note}</div>
                ) : null}
              </div>
            ))}
          </div>
        ) : null}

        <ol className="grid gap-2 border-t border-border/70 pt-3">
          {checks.map((check) => (
            <li
              key={check.id}
              className="grid min-w-0 grid-cols-[auto_minmax(0,1fr)] gap-3 border-b border-border/60 py-2 last:border-b-0 last:pb-0"
              data-preflight-check={check.id}
              data-ok={check.ok ? "true" : "false"}
            >
              <span
                className={cn(
                  "inline-flex h-5 w-5 items-center justify-center border text-[11px] font-semibold",
                  check.ok
                    ? "border-[hsl(var(--chart-2)/0.35)] bg-[hsl(var(--chart-2)/0.12)] text-foreground"
                    : "border-[hsl(var(--chart-3)/0.45)] bg-[hsl(var(--chart-3)/0.12)] text-foreground"
                )}
                aria-hidden="true"
              >
                {check.ok ? "✓" : "!"}
              </span>
              <span className="min-w-0">
                <span className="block text-[13px] font-semibold leading-snug text-foreground">{check.name}</span>
                {check.detail ? (
                  <span className="mt-0.5 block text-[12px] leading-[1.45] text-foreground/90">{check.detail}</span>
                ) : null}
              </span>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
