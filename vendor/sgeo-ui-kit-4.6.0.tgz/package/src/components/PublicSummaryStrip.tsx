import { cn } from "../utils/cn";

export interface PublicSummaryItem {
  eyebrow?: string;
  title: string;
  description?: string;
  href?: string;
  target?: string;
  rel?: string;
  ariaLabel?: string;
}

export interface PublicSummaryStripProps {
  items: PublicSummaryItem[];
  columns?: 2 | 3 | 4;
  compact?: boolean;
  className?: string;
  cardClassName?: string;
}

function SummaryCard({ item, className, compact = false }: { item: PublicSummaryItem; className?: string; compact?: boolean }) {
  const content = (
    <>
      {item.eyebrow ? (
        <div className="text-[11px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
          {item.eyebrow}
        </div>
      ) : null}
      <div className={cn("mt-1.5 text-base font-semibold leading-tight text-foreground", compact ? "sm:text-[17px]" : "sm:text-lg")}>
        {item.title}
      </div>
      {item.description ? (
        <p className="mt-auto pt-2 text-[13px] leading-[1.5] text-muted-foreground">
          {item.description}
        </p>
      ) : null}
    </>
  );

  const baseClassName = cn(
    "relative flex min-w-0 flex-col border-t-2 border-x border-b border-x-border/80 border-b-border/80 border-t-primary/45 bg-card px-4 py-3.5 transition-colors duration-150",
    compact ? "min-h-[104px]" : "min-h-[116px]",
    item.href && "hover:bg-muted/25",
    className
  );

  if (item.href) {
    return (
      <a
        href={item.href}
        target={item.target}
        rel={item.rel}
        aria-label={item.ariaLabel}
        className={cn(baseClassName, "no-underline")}
      >
        {content}
      </a>
    );
  }

  return <article className={baseClassName}>{content}</article>;
}

export function PublicSummaryStrip({
  items,
  columns = 4,
  compact = false,
  className,
  cardClassName,
}: PublicSummaryStripProps) {
  const columnsClassName =
    columns === 2
      ? "sm:grid-cols-2"
      : columns === 3
        ? "sm:grid-cols-2 xl:grid-cols-3"
        : "sm:grid-cols-2 xl:grid-cols-4";

  return (
    <div className={cn("grid grid-cols-1 gap-3", columnsClassName, className)}>
      {items.map((item, index) => (
        <SummaryCard
          key={`${item.title}-${index}`}
          item={item}
          compact={compact}
          className={cardClassName}
        />
      ))}
    </div>
  );
}
