export type RankedSearchTier = 0 | 1 | 2 | 3;

export interface RankedSearchItem {
  title?: string;
  excerpt?: string;
  page?: string;
  category?: string;
  kind?: string;
  searchText?: string;
  primaryTerms?: string[];
  secondaryTerms?: string[];
  keywords?: string[];
}

export interface RankedSearchOptions {
  locale?: string;
  minimumTokenLength?: number;
  kindWeights?: Record<string, number>;
  pageWeights?: Record<string, number>;
}

export type RankedSearchResult<T> = T & {
  score: number;
  tier: RankedSearchTier;
};

const defaultKindWeights: Record<string, number> = {
  published: 3,
  detail: 2,
  collection: 1,
  index: 0,
};

function normalizeSearchValue(value: unknown, locale = "ru-RU") {
  return String(value ?? "")
    .normalize("NFKC")
    .trim()
    .toLocaleLowerCase(locale)
    .replace(/\s+/g, " ");
}

function terms(value: unknown) {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
}

function kindWeight(item: RankedSearchItem, options: RankedSearchOptions) {
  const weights = options.kindWeights ?? defaultKindWeights;
  return weights[item.kind ?? "index"] ?? 0;
}

function pageWeight(item: RankedSearchItem, options: RankedSearchOptions) {
  const weights = options.pageWeights ?? {};
  const page = item.page ?? "";
  return Object.prototype.hasOwnProperty.call(weights, page) ? weights[page] ?? 999 : 999;
}

function matchTier(
  item: RankedSearchItem,
  normalizedQuery: string,
  tokens: string[],
  options: RankedSearchOptions
): RankedSearchTier {
  const locale = options.locale;
  const title = normalizeSearchValue(item.title, locale);
  const excerpt = normalizeSearchValue(item.excerpt, locale);
  const page = normalizeSearchValue(item.page, locale);
  const category = normalizeSearchValue(item.category, locale);
  const primary = normalizeSearchValue([...terms(item.primaryTerms), title].join(" "), locale);
  const secondary = normalizeSearchValue([...terms(item.secondaryTerms), ...terms(item.keywords)].join(" "), locale);

  if ([title, excerpt, page, category].some((value) => value.includes(normalizedQuery))) {
    return 3;
  }
  if (tokens.length > 0 && tokens.every((token) => primary.includes(token))) {
    return 2;
  }
  if (tokens.length > 0 && tokens.every((token) => secondary.includes(token))) {
    return 1;
  }
  return 0;
}

function scoreItem(
  item: RankedSearchItem,
  normalizedQuery: string,
  tokens: string[],
  tier: RankedSearchTier,
  options: RankedSearchOptions
) {
  if (!normalizedQuery) return 1;

  const locale = options.locale;
  const title = normalizeSearchValue(item.title, locale);
  const excerpt = normalizeSearchValue(item.excerpt, locale);
  const page = normalizeSearchValue(item.page, locale);
  const category = normalizeSearchValue(item.category, locale);
  const searchText = normalizeSearchValue(
    item.searchText ?? [item.title, item.excerpt, item.page, item.category, ...terms(item.keywords)].join(" "),
    locale
  );
  const matchedTokens = tokens.filter((token) => searchText.includes(token));
  if (matchedTokens.length === 0) return 0;

  let score = matchedTokens.length * 12 + tier * 30;
  if (title === normalizedQuery) score += 140;
  if (title.startsWith(normalizedQuery)) score += 80;
  if (title.includes(normalizedQuery)) score += 60;
  if (page === normalizedQuery) score += 120;
  if (page.includes(normalizedQuery) || category.includes(normalizedQuery)) score += 25;
  if (excerpt.includes(normalizedQuery)) score += 18;
  if (searchText.includes(normalizedQuery)) score += 12;
  score += kindWeight(item, options) * 6;

  matchedTokens.forEach((token) => {
    if (title.includes(token)) score += 14;
    else if (page.includes(token) || category.includes(token)) score += 8;
    else if (excerpt.includes(token)) score += 5;
    else score += 3;
  });

  if (matchedTokens.length === tokens.length && tokens.length > 1) score += 20;
  return score;
}

function compareRankedItems<T extends RankedSearchItem>(
  left: RankedSearchResult<T>,
  right: RankedSearchResult<T>,
  options: RankedSearchOptions
) {
  if (right.score !== left.score) return right.score - left.score;

  const kindDifference = kindWeight(right, options) - kindWeight(left, options);
  if (kindDifference !== 0) return kindDifference;

  const pageDifference = pageWeight(left, options) - pageWeight(right, options);
  if (pageDifference !== 0) return pageDifference;

  return String(left.title ?? "").localeCompare(String(right.title ?? ""), options.locale ?? "ru");
}

export function rankSearchItems<T extends RankedSearchItem>(
  items: T[],
  query: string,
  suppliedOptions: RankedSearchOptions = {}
): RankedSearchResult<T>[] {
  const options = suppliedOptions;
  const normalizedQuery = normalizeSearchValue(query, options.locale);
  const source = Array.isArray(items) ? items : [];

  if (!normalizedQuery) {
    return source
      .map((item) => ({ ...item, score: 1, tier: 0 as RankedSearchTier }))
      .sort((left, right) => compareRankedItems(left, right, options));
  }

  const minimumTokenLength = Number.isInteger(options.minimumTokenLength) ? Number(options.minimumTokenLength) : 1;
  const tokens = normalizedQuery.split(" ").filter((token) => token.length >= minimumTokenLength);
  const ranked = source
    .map((item) => {
      const tier = matchTier(item, normalizedQuery, tokens, options);
      return {
        ...item,
        tier,
        score: scoreItem(item, normalizedQuery, tokens, tier, options),
      };
    })
    .filter((item) => item.score > 0 && item.tier > 0);
  const highestTier = ranked.reduce((highest, item) => Math.max(highest, item.tier), 0);

  return ranked
    .filter((item) => highestTier < 2 || item.tier >= 2)
    .sort((left, right) => compareRankedItems(left, right, options));
}
