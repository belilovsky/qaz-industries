import type { CSSProperties } from "react";

export interface SoftToneStyles {
  wrapper: CSSProperties;
  dot: CSSProperties;
}

export function createSoftToneStyles(accent: string): SoftToneStyles {
  return {
    wrapper: {
      borderColor: `color-mix(in srgb, ${accent} 26%, hsl(var(--border)))`,
      backgroundColor: `color-mix(in srgb, ${accent} 10%, hsl(var(--card)))`,
      color: "hsl(var(--foreground))",
    },
    dot: {
      backgroundColor: accent,
      boxShadow: "0 0 0 2px hsl(var(--background))",
    },
  };
}
