# @sgeo/ui-kit changelog

## 4.6.0 - Unified AVDS release identity

- Aligned the framework-neutral UI package with the AVDS 4.6.0 system and
  showcase release identity.
- Preserved the 4.5.1 token, admin CSS and component contracts byte-for-byte;
  this release changes package identity without inventing API or visual drift.
- Kept consumer adoption evidence separate from a footer or version marker.

## 4.5.1 - Compact trend visualization

- Added the dependency-free `TrendSparkline` primitive for compact temporal
  context in metric rows, tables, and operational monitoring.
- Added accessible series descriptions, semantic tones, an optional reference
  line, and a restrained area layer.
- Non-finite values are ignored, empty data remains explicitly empty, and
  constant series render without invented amplitude.
- Added a production showcase route, generated Storybook story, responsive
  route contract, focused tests, and a documented QazLake/Taskqueue adoption
  path.

## 4.5.0 - Administration primitives

- Added `AdminShell`, `AdminLoginShell`, `AdminContentQueue`,
  `AdminBulkActionBar`, `AdminEditorRail`, `AdminMediaPicker`,
  `AdminRoleMatrix`, `AdminAuditTrail` and `AdminSettingsGroup`.
- Normalized repeated admin patterns from Total, KOZ, ORTCOM, FBRK and CMNT
  without moving domain CRUD, auth, RBAC, storage or mutations into AV DS.
- Added a framework-neutral `@sgeo/ui-kit/admin/admin.css` contract for Jinja,
  SSR, Vue and other non-React consumers.
- Expanded the showcase with seven real admin sections, nine component routes,
  generated Storybook stories and desktop/mobile/accessibility gates.

## 4.4.0 - Reusable product surfaces

- Added compact operational evidence primitives extracted from QazRegion:
  `EvidenceCoverageState`, `MethodDisclosure`, `InspectionPrioritySummary`,
  `DataQualityScorecard`, `CoverageMatrix`, `ReleaseProof`,
  `PolicyChangeReceipt` and `MapLayerToggleGroup`.
- Added eight package-level surfaces for operator review, admin workspaces,
  media monitoring, incident response, geographic evidence, public evidence,
  public explainers and content digests.
- Kept all data, actions, maps, tables, collectors and business rules in the
  consumer through typed composition props and `ReactNode` slots.
- Added a dedicated desktop/mobile/axe smoke manifest for every surface and an
  evidence-based ownership board that distinguishes candidates from live
  consumer adoption.

## 4.3.3 - QazStack asset evidence presentation

- Added dependency-free presentation adapters for QazStack 1.39
  `AssetEvidence`, `AssetResolution`, `AssetTimeline` and `AssetQuality`
  contracts.
- Added a byte-identical canonical golden fixture and focused adapter tests
  without adding validation, network requests or product decisions to the UI
  package.
- Expanded the release drift gate from five to eleven public QazStack schemas
  while keeping control-plane and legacy source paths private.
- Added progressively disclosed asset quality and evidence examples to the
  existing operational trust showcase routes.

## 4.3.2 - Operational trust layer and restrained status hierarchy

- Added `DataFreshness`, `DataQualityFlag`, `ContractStatus`, `EvidenceTrail`,
  `ExportReceipt` and `CollectorRun` as presentation-only operational primitives.
- Added validated QazStack and QazLake showcase adapters without moving product
  queries, scoring, authorization or workflow ownership into the UI package.
- Added dependency-free presentation adapters for QazStack consumer,
  `SourceOccurrence`, `MediaArtifact` and evidence-manifest contracts.
- Replaced decorative vertical status rails with top rules, status markers and
  typographic hierarchy across the shared component surface.
- Added mobile page-overflow verification and incremental checkpoint artifacts
  to the route smoke runner.

## 4.3.1 - Accessibility gate and operational component hardening

- Added repeatable desktop/mobile axe smoke for the full AV DS showcase route set.
- Added a generated JSON design-token export at `@sgeo/ui-kit/tokens/avds.tokens.json`.
- Fixed contrast-sensitive text in operational metrics, evidence cards, workflow rows and chart tooltips.
- Made horizontally scrollable table regions keyboard-focusable on mobile.
- Corrected `DemographyHeatmap` ARIA table structure and `Progress` accessible value semantics.

## 4.3.0 - Product primitive harvest

- Added `ReportToolbar` for responsive report filters, summaries and actions.
- Added chart-library-independent `ChartInsightTooltip` content.
- Added ordered `DecisionFeed` presentation for operational next actions.
- Preserved product ownership of queries, exports, ranking, thresholds, RBAC
  and action authorization.

## 4.2.0 - Public and operational language

- Normalized the AV DS 4 package surface for public explainers, evidence,
  operational status, data navigation and responsive consumer use.
- Added the current typography, theme, density and reduced-radius contracts.

## 1.2.0

- Added `RangeWithFlags` and its CSS for QazLake digital-audience ranges.

## 1.1.0 - AVDS charts: RangeBar + DemographyHeatmap

- `RangeBar` – выравнивает диапазоны величин (показывает разброс источников).
- `DemographyHeatmap` – тепловая карта соцдем (пол/возраст).
- Оба компонента экспортируются из `src/index.ts` и используются в region.qdev.run digital-audience widget.

## 1.0.0

- Базовый набор AVDS-компонентов.
