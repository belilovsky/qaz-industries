# @sgeo/ui-kit

Библиотека AVDS 4 с техническим именем `@sgeo/ui-kit` – набор интерфейсных компонентов для рабочих панелей, публичных объяснений и приложений, где важна проверяемость.

## Системные документы

- [Модель компонентов AVDS 4](../../docs/AVDS4_COMPONENT_MODEL.md)
- [Правила включения в AVDS 4](../../docs/AVDS4_ABSORPTION_RULES.md)
- [Проверка перед выпуском AVDS 4](../../docs/AVDS4_RELEASE_CHECKLIST.md)
- [Административные примитивы AVDS 4](../../docs/AVDS4_ADMIN_PRIMITIVES.md)
- [План разделения изменений AVDS 4](../../docs/avds-commit-split-plan-2026-06-30-current.md)

## Семейства компонентов

- `Навигация`: `PageHeader`, `PillTabs`
- `Рабочие и операционные панели`: `AccentCard`, `MiniMetric`, `TrendSparkline`, `ScoreBar`, `RadialGauge`, `DataTable`, `BarChart`, `RangeBar`, `DemographyHeatmap`, `ChartInsightTooltip`, `DecisionFeed`, `StatusBadge`, `ServiceStatusCard`, `DataFreshness`, `DataQualityFlag`, `ContractStatus`, `CollectorRun`
- `Данные и рабочие процессы`: `ReportToolbar`, `FilterChipRow`, `PaginatedList`, `SearchField`, `WorkflowPath`
- `Публичные объяснения`: `MetricCard`, `DocumentCard`, `PublicSummaryStrip`, `QuickLinksRail`, `CompactCompareCard`, `ComparisonBarRow`, `SpeakerOverviewCard`, `ThemeCoverageCard`, `TrustFactsPanel`, `InlineDocumentAssistantPanel`
- `Подтверждения и происхождение данных`: `SourceBadge`, `SourceHealthBadge`, `SourcePolicyBadge`, `SourceCard`, `ProvenanceCard`, `RangeWithFlags`, `ProvenanceFoot`, `ProvenanceTable`, `EvidenceTrail`, `ExportReceipt`
- `Администрирование`: `AdminShell`, `AdminLoginShell`, `AdminContentQueue`, `AdminBulkActionBar`, `AdminEditorRail`, `AdminMediaPicker`, `AdminRoleMatrix`, `AdminAuditTrail`, `AdminSettingsGroup`

## Установка

```bash
# В монорепо – workspace-зависимость
"@sgeo/ui-kit": "file:./packages/ui-kit"

# Или npm link для других проектов
cd packages/ui-kit && npm link
cd ../my-project && npm link @sgeo/ui-kit
```

## Подключение

### 1. CSS-токены и анимации

В главном CSS-файле проекта (index.css):

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

/* Дизайн-токены: цвета, тени, шрифты (light + dark) */
@import '@sgeo/ui-kit/tokens/variables.css';

/* Анимации: fadeInUp, barGrow, stagger, accent-lines и т.д. */
@import '@sgeo/ui-kit/animations/animations.css';
```

### 2. Готовый набор Tailwind

В `tailwind.config.ts`:

```ts
import { sgeoPreset } from '@sgeo/ui-kit/tokens/tailwind-preset';

export default {
  presets: [sgeoPreset],
  content: [
    "./src/**/*.{ts,tsx}",
    "./packages/ui-kit/src/**/*.{ts,tsx}",
  ],
  plugins: [require("tailwindcss-animate"), require("@tailwindcss/typography")],
} satisfies Config;
```

## Компоненты

### Administration 4.5.0

Девять управляемых примитивов нормализуют повторяющиеся решения из Total, KOZ,
ORTCOM, FBRK и CMNT: оболочку и вход, очередь материалов, массовые действия,
панель редактора, выбор медиа, матрицу ролей, журнал аудита и настройки.
Маршруты, вход, CSRF, RBAC, хранение и изменения остаются у потребителя.

Для Jinja, SSR и Vue доступен отдельный framework-neutral контракт:

```css
@import '@sgeo/ui-kit/tokens/variables.css';
@import '@sgeo/ui-kit/admin/admin.css';
```

Полная граница ответственности и rollout gates описаны в
[`AVDS4_ADMIN_PRIMITIVES.md`](../../docs/AVDS4_ADMIN_PRIMITIVES.md).

### Reusable product surfaces 4.4.0

Восемь наборов поверхностей собирают повторяющийся экранный ритм без нового
прикладного каркаса: `OperatorReviewSurface`, `AdminWorkspaceSurface`,
`MediaMonitoringSurface`, `IncidentResponseSurface`, `GeoEvidenceSurface`,
`EvidenceSummarySurface`, `PublicExplainerSurface` и `ContentDigestSurface`.

Каждая поверхность отвечает только за адаптивную компоновку и доступность.
Таблица, карта, данные, действия, RBAC, запросы и бизнес-решения остаются во
владении потребителя:

```tsx
import { AdminWorkspaceSurface } from '@sgeo/ui-kit';

<AdminWorkspaceSurface
  title="Модерация"
  metrics={metrics}
  toolbar={toolbar}
  primary={<DataTable columns={columns} data={rows} />}
  state={reviewState}
/>
```

### Operational trust 4.3.3 - QazStack и QazLake

Шесть небольших компонентов визуализируют контракт, свежесть, качество,
происхождение и результат выгрузки. Они не обращаются к QazStack или QazLake
самостоятельно: потребитель передаёт уже проверенные данные и сохраняет у себя
сетевой жизненный цикл, права, политику свежести и бизнес-решения.

Вместо декоративных цветных полос компоненты используют спокойную иерархию:
короткий статусный маркер, верхнюю разделительную линию и явную подпись.

QazStack остаётся владельцем схем и проверки. AVDS экспортирует только
тонкие адаптеры представления, чтобы один и тот же проверенный пакет данных можно
было показать через существующие компоненты без дублирования UI:

```tsx
import {
  EvidenceTrail,
  DataQualityFlag,
  ProvenanceCard,
  qazStackAssetEvidenceToProvenance,
  qazStackAssetQualityToFlags,
  qazStackEvidenceManifestToTrail,
  qazStackSourceOccurrenceToProvenance,
} from '@sgeo/ui-kit';

<EvidenceTrail steps={qazStackEvidenceManifestToTrail(manifest)} />
<ProvenanceCard
  title="SourceOccurrence"
  status="draft"
  items={qazStackSourceOccurrenceToProvenance(occurrence)}
/>
```

QazStack 1.39 asset-контракты используют те же presentation primitives:

```tsx
<ProvenanceCard items={qazStackAssetEvidenceToProvenance(evidence)} />
{qazStackAssetQualityToFlags(quality).map((flag) => (
  <DataQualityFlag key={flag.label} {...flag} />
))}
```

Адаптеры не валидируют внешний JSON и не делают сетевых запросов. На вход им
нужно передавать пакет данных, уже проверенный канонической схемой QazStack.

### Product harvest 4.3 – рабочие решения из продуктов

`ReportToolbar`, `ChartInsightTooltip` и `DecisionFeed` нормализуют уже
проверенные решения из Taskqueue, QazStack, SGEO и PSSR. Компоненты отвечают
только за представление и доступность: загрузка данных, экспорт, ранжирование,
права и продуктовые действия остаются у потребителя.

```tsx
import {
  ChartInsightTooltip,
  DecisionFeed,
  ReportToolbar,
} from '@sgeo/ui-kit';

<ReportToolbar
  title="Отчёт по задачам"
  controls={<PeriodControls />}
  summary="128 записей"
  actions={<ExportButton />}
/>

<ChartInsightTooltip
  label="12 июля"
  items={[
    { label: "Выполнено", value: 84, tone: "positive" },
    { label: "Просрочено", value: 7, tone: "critical" },
  ]}
/>

<DecisionFeed
  items={decisions}
  selectedId={selectedDecisionId}
  onItemSelect={setSelectedDecisionId}
/>
```

### PillTabs – вкладки

```tsx
import { PillTabs } from '@sgeo/ui-kit';

<PillTabs
  tabs={[
    { value: "all", label: "Все" },
    { value: "gov", label: "Гос. сайты", count: 42 },
    { value: "media", label: "СМИ", count: 18 },
  ]}
  value={activeTab}
  onChange={setActiveTab}
/>
```

Поддерживает и ссылочный режим:

```tsx
<PillTabs
  tabs={[
    { value: "overview", label: "Обзор", href: "/consumer-health" },
    { value: "sources", label: "Источники", href: "/sources", ariaLabel: "Открыть реестр источников" },
  ]}
  value="sources"
  overflow="scroll"
/>
```

### AccentCard – карточка с акцентной линией

```tsx
import { AccentCard } from '@sgeo/ui-kit';

<AccentCard variant="primary" glow>
  <h3>Показатель</h3>
  <p className="text-3xl font-bold">84,110</p>
</AccentCard>
```

Варианты: `primary` | `green` | `amber` | `red` | `neutral` | `none`

### DataTable – Таблица данных

```tsx
import { DataTable } from '@sgeo/ui-kit';

<DataTable
  columns={[
    { key: "name", header: "Название" },
    { key: "score", header: "Оценка", align: "center" },
    { key: "status", header: "Статус", render: (row) => <StatusBadge status={row.status} /> },
  ]}
  data={items}
  onRowClick={(row) => navigate(`/detail/${row.id}`)}
/>
```

### StatusBadge – метка статуса

```tsx
import { StatusBadge } from '@sgeo/ui-kit';

<StatusBadge status="completed" />
<StatusBadge status="running" label="Аудит" />
<StatusBadge status="failed" size="md" />
```

Статусы: `completed` | `running` | `pending` | `failed` | `error`

### SourceBadge / SourceHealthBadge / SourcePolicyBadge – источники и правила использования

```tsx
import { SourceBadge, SourceHealthBadge, SourcePolicyBadge } from '@sgeo/ui-kit';

<SourceBadge source="qazlake" />
<SourceHealthBadge status="yellow" label="Есть замечания" />
<SourcePolicyBadge policy="attribution" />
```

Состояние: `green` | `yellow` | `red` | `disabled` | `unconfigured`<br>
Правила: `yes` | `attribution` | `share_alike` | `review` | `no`

### SourceCard / ProvenanceCard – Источник и происхождение фактов

```tsx
import { SourceCard, ProvenanceCard } from '@sgeo/ui-kit';

<SourceCard
  name="QazLake media"
  sourceId="qazlake.media"
  healthStatus="green"
  policy="review"
  labels={{ items: "Записей", updated: "Обновлено" }}
  piiRiskLabels={{ review: "проверить" }}
/>
<ProvenanceCard
  status="verified"
  policy="attribution"
  statusLabels={{ needs_review: "Проверить" }}
  items={[{ label: "Документ", href: "https://example.org/doc.pdf", confidence: "вручную" }]}
/>
```

### InfoTooltip – всплывающая подсказка (Portal)

```tsx
import { InfoTooltip } from '@sgeo/ui-kit';

<InfoTooltip
  title="Оценка видимости в поиске"
  body="Комплексная оценка видимости сайта в поисковых системах на основе искусственного интеллекта."
  formula="GVS = Σ(pillar_i × weight_i) / Σ(weight_i)"
  ranges={[
    { color: "#059669", label: "70+ Хорошо" },
    { color: "#d97706", label: "40-69 Средне" },
    { color: "#dc2626", label: "<40 Плохо" },
  ]}
/>
```

### RadialGauge – Круговой индикатор

```tsx
import { RadialGauge } from '@sgeo/ui-kit';

<RadialGauge value={73.5} size={180} label="Оценка видимости" />
```

### MiniMetric – Компактная метрика

```tsx
import { MiniMetric } from '@sgeo/ui-kit';
import { BarChart3 } from 'lucide-react';

<MiniMetric icon={BarChart3} label="Тестов" value="84,110" color="#2563eb" />
```

### TrendSparkline – Компактная временная динамика

```tsx
import { TrendSparkline } from '@sgeo/ui-kit';

<TrendSparkline
  data={[18, 21, 19, 26, 31, 35]}
  ariaLabel="Публикации за шесть часов: рост с 18 до 35"
  tone="success"
  referenceValue={24}
  showArea
/>
```

`TrendSparkline` показывает форму изменения рядом с точным значением. Для
сравнения категорий, распределений и подробного анализа используйте полноценный
график с осями и легендой.

### MetricCard – Спокойная публичная метрика

```tsx
import { MetricCard } from '@sgeo/ui-kit';
import { FileText } from 'lucide-react';

<MetricCard
  label="Статьи"
  value="96"
  subtext="Полный текст доступен онлайн с якорями"
  icon={<FileText className="h-4 w-4" />}
  density="compact"
/>
```

`density="compact"` оставляет `MetricCard` вторичной фактологической
поддержкой: он уместен в коротком боковом или нижнем ряду, но не заменяет
`MiniMetric` в слое часто обновляемых операционных показателей.

### DocumentCard – Читаемая карточка материала

```tsx
import { DocumentCard } from '@sgeo/ui-kit';

<DocumentCard
  eyebrow="сводка"
  title="Новый инфраструктурный план"
  href="/documents/infra-plan"
  summary="Короткий смысловой lead без мусора."
  quote="Ключевой фокус – транзит и модернизация сетей."
  metaItems={[
    { value: "Inform.kz" },
    { value: "WS" },
    { value: "30 июня 2026" },
  ]}
/>
```

### FilterChipRow – рабочие фильтры с количеством результатов

```tsx
import { FilterChipRow } from '@sgeo/ui-kit';

<FilterChipRow
  ariaLabel="Проблемы покрытия"
  value="freshness"
  chips={[
    { value: "all", label: "Все", count: 883 },
    { value: "freshness", label: "Свежесть", count: 716 },
    { value: "history", label: "История", count: 60 },
  ]}
/>
```

### ServiceStatusCard – Операционный статус с контекстом

```tsx
import { ServiceStatusCard } from '@sgeo/ui-kit';

<ServiceStatusCard
  title="Telegram stream"
  status="green"
  statusLabel="active"
  summary="Поток идёт без idle-окна."
  metrics={[
    { label: "eligible", value: "131" },
    { label: "delivered", value: "131", note: "за последний час" },
  ]}
/>
```

### StatePanel – пустое, неполное или ошибочное состояние

```tsx
import { StatePanel } from '@sgeo/ui-kit';

<StatePanel
  title="Нет данных за период"
  message="Выберите другой диапазон или обновите источник."
  tone="warning"
  action={{ label: "Обновить", href: "/admin/source-coverage" }}
/>
```

### ComparisonBarRow / ProvenanceFoot / ProvenanceTable – язык публичных данных

```tsx
import { ComparisonBarRow, ProvenanceFoot, ProvenanceTable } from '@sgeo/ui-kit';

<ComparisonBarRow
  label="TikTok (18+)"
  value={7800000}
  maxValue={20000000}
  valueLabel="7.8 млн"
  emphasis="focus"
/>

<ProvenanceFoot
  sources={[{ label: "DataReportal" }, { label: "NapoleonCat" }, { label: "BNS" }]}
  periodLabel="май 2026"
  layerLabel="digital_audience.kz.monthly"
  registryHref="/data/digital_audience/sources.kz.2026-05.json"
/>

<ProvenanceTable
  rows={[
    { metric: "Instagram reach", source: "NapoleonCat", period: "2026-05", value: "12.4-13.2 млн" },
  ]}
/>
```

### SpeakerOverviewCard – Обзор корпуса или публичной сущности

```tsx
import { SpeakerOverviewCard } from '@sgeo/ui-kit';

<SpeakerOverviewCard
  eyebrow="корпус"
  title="Касым-Жомарт Токаев"
  href="/tokaev"
  period="2019-..."
  summary="Корпус для просмотра решений, приоритетов и политического языка."
  metrics={[
    { label: "документов", value: 124 },
    { label: "тезисов", value: 942 },
  ]}
  latestTitle="Выступление на расширенном заседании"
  latestHref="/documents/1"
  latestMeta="30 июня 2026"
  links={[
    { label: "Хронология", href: "/tokaev/timeline" },
    { label: "Тезисы", href: "/tokaev/atoms" },
  ]}
/>
```

### ThemeCoverageCard – Тема с межкорпусной навигацией

```tsx
import { ThemeCoverageCard } from '@sgeo/ui-kit';

<ThemeCoverageCard
  code="03"
  title="Экономический рост"
  href="/themes/03"
  countLabel="128 тезисов"
  accentColor="#1f6feb"
  linksLabel="Открыть тему в корпусах"
  links={[
    { label: "Токаев", href: "/tokaev/evolution?theme=03" },
    { label: "Ашимбаев", href: "/ashimbayev/evolution?theme=03" },
  ]}
/>
```

### TrustFactsPanel – контекстный публичный блок-справка

```tsx
import { TrustFactsPanel } from '@sgeo/ui-kit';

<TrustFactsPanel
  title="Как читать Qaz.Vision"
  summary="Главная показывает общий контур будущего через документы."
  items={[
    { title: "Актуальность данных", description: "Последнее подтвержденное событие: 30 июня 2026" },
    { title: "3 корпуса", description: "Отдельные страницы по каждому спикеру" },
  ]}
  links={[
    { label: "Методология", href: "/methodology" },
    { label: "Источники", href: "/sources" },
  ]}
/>
```

### InlineDocumentAssistantPanel – Вход в RAG по конкретному документу

```tsx
import { InlineDocumentAssistantPanel } from '@sgeo/ui-kit';

<InlineDocumentAssistantPanel
  title="Спросить по этому документу"
  summary="Откроется чат по материалам корпуса с проверяемыми источниками."
  prompts={[
    { label: "Кратко объяснить", value: "Кратко объясни документ" },
    { label: "Ключевые тезисы", value: "Какие ключевые тезисы есть в документе?" },
  ]}
  ctaHref="/assistant"
  ctaLabel="Открыть полный ассистент"
/>
```

### PublicSummaryStrip – Верхний обзорный слой

```tsx
import { PublicSummaryStrip } from '@sgeo/ui-kit';

<PublicSummaryStrip
  columns={4}
  items={[
    { eyebrow: "охват", title: "20 регионов", description: "17 областей и 3 города" },
    { eyebrow: "сигнал", title: "2 184 источника", description: "Публичный справочный слой" },
  ]}
/>
```

### QuickLinksRail – ряд быстрых публичных переходов

```tsx
import { QuickLinksRail } from '@sgeo/ui-kit';
import { ArrowUpRight } from 'lucide-react';

<QuickLinksRail
  ariaLabel="Основные маршруты"
  items={[
    { label: "Akorda", href: "https://www.akorda.kz", icon: <ArrowUpRight className="h-3.5 w-3.5" />, ariaLabel: "Открыть Akorda" },
    { label: "eGov", href: "https://egov.kz", meta: "24/7" },
    { label: "Карта", active: true },
  ]}
/>
```

### CompactCompareCard – Лёгкое top-N сравнение

```tsx
import { CompactCompareCard } from '@sgeo/ui-kit';

<CompactCompareCard
  title="Население"
  summary="Пять самых населённых регионов"
  rows={[
    { label: "Алматы", value: 2286500, valueLabel: "2.29 млн" },
    { label: "Туркестанская", value: 2142000, valueLabel: "2.14 млн" },
  ]}
  footerNote="Сравнение без перегруженной графики"
/>
```

### ScoreBar – Горизонтальная шкала

```tsx
import { ScoreBar } from '@sgeo/ui-kit';

<ScoreBar value={65} label="Schema.org" />
```

### PageHeader – Заголовок страницы

```tsx
import { PageHeader } from '@sgeo/ui-kit';
import { LayoutDashboard } from 'lucide-react';

<PageHeader
  eyebrow="пользовательский экран"
  title="Рабочая панель"
  subtitle="Обзор видимости"
  meta={<span className="rounded-full border border-border px-2 py-1 text-xs">обновлено 5 минут назад</span>}
  icon={<LayoutDashboard className="w-5 h-5 text-primary" />}
>
  <Button>Обновить</Button>
</PageHeader>
```

Дополнительно:

- `tone="accent"` – мягкая акцентная поверхность для consumer/public header
- `density="compact"` – более плотный вертикальный ритм для внутренних экранов и вложенных хедеров

## CSS-утилиты

| Класс | Описание |
|-------|----------|
| `.animate-fadeInUp` | Появление снизу (0.5s) |
| `.animate-fadeIn` | Плавное появление (0.4s) |
| `.animate-barGrow` | Рост полосы слева (0.8s) |
| `.animate-livePulse` | Пульсация (бесконечно) |
| `.stagger-1` … `.stagger-8` | Задержки анимации (0.05s шаг) |
| `.accent-line-primary` | Акцентная линия сверху (синяя) |
| `.accent-line-green` | Акцентная линия (зелёная) |
| `.accent-line-amber` | Акцентная линия (янтарная) |
| `.accent-line-red` | Акцентная линия (красная) |
| `.card-glow-primary` | Тихая акцентная обводка для legacy `glow`-prop |
| `.info-trigger` | Кнопка «?» для всплывающей подсказки |
| `.status-strip` | Горизонтальная полоса статусов |
| `.rank-num` | Числовая метка позиции |
| `.tabular-nums` | Моноширинные цифры |

## Дизайн-токены

### Цвета
- Primary: `hsl(210 70% 42%)` – #1e40af (deep blue)
- Chart palette: 5 цветов через `--chart-1` … `--chart-5`

### Шрифты
- Body: IBM Plex Sans
- Display: IBM Plex Sans / theme-aware `--font-display`
- Serif/editorial: IBM Plex Serif
- Mono: IBM Plex Mono
- Основной шрифт рабочих панелей: `--font-dashboard` -> `Arial, "Helvetica Neue", Helvetica, sans-serif`

### Радиусы
- lg: 9px, md: 6px, sm: 3px

## Лицензия

Внутренний пакет AVDS.
